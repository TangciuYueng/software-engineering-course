import {createRouter, createWebHistory} from 'vue-router'

const routerHistory = createWebHistory()

import Test from '@/views/test.vue'

import TechPage from '@/views/TechPage/TechPage.vue'
import FarmManagement from '@/views/TechPage/FarmManagement.vue'
import FieldManagement from '@/views/TechPage/FieldManagement.vue'
import ToolManagement from '@/views/TechPage/ToolManagement.vue'
import WarehouseManagement from '@/views/TechPage/WarehouseManagement.vue'
import InformationStatistic from '@/views/TechPage/InformationStatistic.vue'



import Login from '@/views/Login/index.vue'

const router = createRouter({
history: routerHistory,

//在这里声明路由规则
routes: [
  { path: '/', redirect: '/login' },
  { 
    path: '/techpage', component: TechPage, 
    children: [
      { path: '/farmmanagement', component: FarmManagement },
      { path: '/fieldmanagement', component: FieldManagement }, 
      { path: '/toolmanagement', component: ToolManagement }, 
      { path: '/warehousemanagement', component: WarehouseManagement }, 

      { path: '/informationstatistic', component: InformationStatistic }, 
    ], props: true
  },
  { 
    path: '/login', component: Login, 
  }
]

})

export default router;



