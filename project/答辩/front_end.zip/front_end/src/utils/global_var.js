/*全局变量*/
export default{
    identity:-1,//身份   -1为默认，1为销售部，2为技术部，3为买家
    farmid: -1,
    fieldid: -1
}