import store from '@/store'
import axios from 'axios'


const service = axios.create({
  // baseURL: process.env.VUE_APP_BASE_API, // url = base url + request url
  // baseURL:'https://localhost:8080/',
  baseURL: 'http://58.87.89.170:8081',  //这个应该是把后端部署了
  // withCredentials: true, // send cookies when cross-domain requests
  timeout: 100000,  // request timeout
  // withCredentials: true//携带cookie
  async: true,
  crossDomain: true,
})

//暴露出去
export default service