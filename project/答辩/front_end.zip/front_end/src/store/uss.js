import { login } from '@/api/login'
import { defineStore } from "pinia";
import { toRaw } from '@vue/reactivity'
import { ref } from 'vue'



const useUserStore2 = defineStore("token", {
  state: () => {
    return {
      token:{}
    };
  },
  getters: {
    
  },
  actions: {
    increment() {
       this.count++
    },
    async loadUserList(params){
        const res = await login(params)
        this.token=res.data[0]
        console.log('uss')
        console.log(this.token)
    },
    clearUserInfo() {
      this.token={}
    }
  },
//持久化存储重点---开启
//这个时候数据默认是存在localStorage
  persist: {
    enabled: true,	//开启
    storage:localStorage,	//修改存储位置
    key:'token',	//设置存储的key
    paths: ['token'],//指定要长久化的字段
  },
});
 
export default useUserStore2;


