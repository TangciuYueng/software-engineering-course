<template>
  <div id = 'app'>    
     <router-view></router-view>
  </div>
</template>

<style>
/* 全局样式，去除body的边框 */
body {
  margin: 0;
  padding: 0;
  border: 0;
}
</style>