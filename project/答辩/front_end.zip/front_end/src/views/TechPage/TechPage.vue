<template>
  <el-backtop :right="25" :bottom="100" />
  <div id="techpage">
    <el-affix>
      <div id="nav">
        <div>
          <img
            src="../../assets/logoGreen.png"
            :style="{ 'margin-left': '10px', height: '50px' }"
          />
        </div>
        <el-popover
          :width="300"
          popper-style="box-shadow: rgb(14 18 22 / 35%) 0px 10px 38px -10px, rgb(14 18 22 / 20%) 0px 10px 20px -15px; padding: 20px;"
        >
          <template #reference>
            <img
              id="icon"
              src="../../assets/staff.png"
              :style="{ 'margin-right': '10px' }"
            />
          </template>
          <template #default>
            <div
              class="conent"
              style="display: flex; gap: 16px; flex-direction: column"
            >
              <img src="../../assets/staff.png" id="innericon" />
              <div>
                <p class="name" style="margin: 0; font-weight: 500">
                  姓名：{{ store.token.name }}
                </p>
                <p class="mention" style="margin: 0; font-weight: 500">
                  工号：{{ store.token.id }}
                </p>
                <p style="margin: 0; font-weight: 500">
                  部门：{{ store.token.identity == 1 ? "科技部" : "后勤部" }}
                </p>
              </div>
            </div>
          </template>
        </el-popover>
        <el-dropdown @command="handleCommand">
          <span class="el-dropdown-link"> {{ store.token.name }} </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="b">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>

      <!--侧边栏-->

      <div :class="{ menuexp: isExp, menucol: isCol }">
        <el-button
          :icon="currentIcon"
          @click="
            isExp = !isExp;
            isCol = !isCol;
            isCollapse = !isCollapse;
          "
          text
        />
        <el-menu
          background-color="#F7F8FF"
          text-color="#00994C"
          active-text-color="#000000"
          :router="true"
          :collapse="isCollapse"
          :default-active="$route.path"
        >
          <el-menu-item index="/farmmanagement">
            <img class="side-icon" src="../../assets/farm.png" />
            <template #title>农场管理</template>
          </el-menu-item>

          <el-menu-item index="/fieldmanagement">
            <img class="side-icon" src="../../assets/field.png" />
            <template #title>田地管理</template>
          </el-menu-item>

          <el-menu-item
            index="/toolmanagement"
            :disabled="store.token.identity != 2"
          >
            <img class="side-icon" src="../../assets/tools.png" />
            <template #title>资产管理</template>
          </el-menu-item>

          <el-menu-item 
            index="/warehousemanagement"
            :disabled="store.token.identity != 2"
          >
            <img class="side-icon" src="../../assets/warehouse.png" />
            <template #title>粮仓管理</template>
          </el-menu-item>



          <el-menu-item index="/informationstatistic">
            <img class="side-icon" src="../../assets/info.png" />
            <template #title>信息统计</template>
          </el-menu-item>
        </el-menu>
      </div>
    </el-affix>
    <!--右侧主页面-->
    <div id="main">
      <el-main>
        <router-view></router-view>
      </el-main>
    </div>
  </div>
</template>
  
  
<script setup>
import { ElMessage, ElMessageBox } from "element-plus";
import router from "@/router";
import { ref, computed, onMounted } from "vue";
import { DArrowLeft, DArrowRight } from "@element-plus/icons-vue";

import useUserStore2 from "@/store/uss";
const store = useUserStore2();

const isCollapse = ref(false);
const isExp = ref(true);
const isCol = ref(false);

const currentIcon = computed(() => {
  if (isExp.value) {
    return "DArrowLeft";
  } else {
    return "DArrowRight";
  }
});

const handleCommand = (command) => {
  if (command === "b") {
    ElMessageBox.confirm("确定要退出登录吗？", "警告", {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "warning",
    })
      .then(() => {
        ElMessage({
          type: "success",
          message: "成功",
        });
        store.clearUserInfo();
        router.replace({ path: "/login" });
      })
      .catch(() => {
        ElMessage({
          type: "info",
          message: "取消",
        });
      });
  }
};
onMounted(() => {
  if (store.token.identity != 1 && store.token.identity != 2) {
    router.push({ path: "/login" });
  }
});
</script>
  
<style scoped>
#techpage {
  background-image: url("@/assets/bgi.png");
  background-size: cover;
}

#nav {
  background-color: #f7f8ff;
  height: 60px;
  width: 100%;
  display: flex;
  padding-left: 0;
  align-items: center;
  color: black;
  font-size: 15px;
}

#icon {
  height: 30px;
  margin-left: 65%;
}

.side-icon {
  height: 25px;
  width: 25px;
  margin-right: 10px;
}

#innericon {
  height: 40px;
  width: 40px;
}

.menuexp {
  position: absolute; /*绝对位置*/
  margin-top: 0px;
  height: 100%;
  min-height: 100vh;
  margin-bottom: 0px;
  background-color: #f7f8ff;
  z-index: 1;
}

.menucol {
  position: absolute; /*绝对位置*/
  margin-top: 0px;
  height: 100%;
  min-height: 100vh;
  margin-bottom: 0px;
  background-color: #f7f8ff;
  z-index: 1;
}

#main {
  background-color: rgba(255, 255, 255, 0.5);
  height: 100%;
  min-height: 100vh; /*写了一天只为一句话*/
}
.el-dropdown-link {
  cursor: pointer;
  color: #000000;
}
/*去掉选中的蓝色框*/
.el-dropdown-link:focus {
  outline: 0;
}

.el-button--primary {
  --el-button-bg-color: #409eff;
  --el-button-hover-bg-color: #409eff;
}
.el-button--primary:hover {
  --el-button-hover-bg-color: #79bbff;
}

.el-menu-item.is-active {
  background-color: #e0f0ff !important;
}
</style>