<template>
  <router-view>
    <div class="farm-management">
      <!-- Top Section -->
      <div class="top-section">
        <div class="farm-info">
          <h1>{{ farmTitle }}</h1>
          <p>{{ farmLocation }}</p>
        </div>
        <div class="farm-dropdown">
          <!-- Placeholder for farm switch dropdown -->
          <select v-model="assetSelectedFarm" @change="fetchTwoList(assetSelectedFarm)">
            <option v-for="farm in farms" :key="farm.farm_Id" :value="farm">{{ farm.name }}</option>
          </select>


        </div>
      </div>

      <!-- Middle Section -->
      <div class="middle-section">
        <div class="input-category">
          <div class="input-box">
            <h2>种子</h2>
            <div class="title-button-gapO">
              <button @click="openComsuablesAdd(addItem, assetSelectedFarm, '种子', 0)">新添</button>
            </div>
            <div v-if="consumablesAdd[0]" class="modal-overlay">
              <div class="modal-content-consumables">
                <div class="title-close">
                  <h6>种子信息填写</h6>

                </div>
                <div class="name">
                  <h4>农场:</h4>
                  <div>{{ assetSelectedFarm.name }}</div>
                </div>
                <div class="middle-input">
                  <div class="input-row">
                    <label for="name">名称:</label>
                    <input v-model="addItem.name" id="name" />
                  </div>
                  <div class="input-row">
                    <label for="stock">余量:</label>
                    <input v-model="addItem.stock" id="stock" />
                  </div>
                  <div class="input-row">
                    <label for="unit">单位:</label>
                    <input v-model="addItem.unit" id="unit" />
                  </div>
                </div>
                <div class="button-box">
                  <button @click="closeConsumablesAddWithoutIn(addItem, 0)" class="white-button">关闭</button>
                  <button @click="closeConsumablesAddWithIn(addItem, 0)">完成</button>
                </div>
              </div>
            </div>
          </div>
          <div class="input-table">
            <table class="comsumables-table">
              <thead>
                <tr>
                  <th>名称</th>
                  <th>数量</th>
                  <th>编辑</th>
                </tr>
              </thead>
              <tbody>
                <!-- Placeholder table rows -->
                <template v-for="item in consumablesList">
                  <tr v-if="item.type === '种子'" :key="item.consumables_Id">
                    <td>{{ item.name }}</td>
                    <td>{{ item.stock }}{{ item.unit }}</td>
                    <td><button @click="openComsuablesEdit(item, 0)">编辑</button></td>

                  </tr>
                </template>
                <div v-if="consumablesEdit[0]" class="modal-overlay">
                  <div class="modal-content-consumables">
                    <div class="title-close">
                      <h6>种子</h6>
                    </div>
                    <div class="middle-input">
                      <div class="input-row">
                        <label for="name">名称:</label>
                        <input v-model="editItem.name" id="name" />
                      </div>
                      <div class="input-row">
                        <label for="stock">余量:</label>
                        <input v-model="editItem.stock" id="stock" />
                      </div>
                      <div class="input-row">
                        <label for="unit">单位:</label>
                        <input v-model="editItem.unit" id="unit" />
                      </div>
                    </div>
                    <div class="button-box">
                      <button @click="closeConsumablesEditWithoutIn(0)" class="white-button">关闭</button>
                      <button @click="closeConsumablesEditWithIn(editItem, 0)">完成</button>
                    </div>
                  </div>
                </div>
                <!-- Add more rows as needed -->
              </tbody>
            </table>
          </div>
        </div>
        <div class="input-category">
          <div class="input-box">
            <h2>农药</h2>
            <div class="title-button-gap">
              <button @click="openComsuablesAdd(addItem, assetSelectedFarm, '农药', 1)">新添</button>
            </div>
            <div v-if="consumablesAdd[1]" class="modal-overlay">
              <div class="modal-content-consumables">
                <div class="title-close">
                  <h6>农药信息填写</h6>
                </div>
                <div class="name">
                  <h4>农场:</h4>
                  <div>{{ assetSelectedFarm.name }}</div>
                </div>
                <div class="middle-input">
                  <div class="input-row">
                    <label for="name">名称:</label>
                    <input v-model="addItem.name" id="name" />
                  </div>
                  <div class="input-row">
                    <label for="stock">余量:</label>
                    <input v-model="addItem.stock" id="stock" />
                  </div>
                  <div class="input-row">
                    <label for="unit">单位:</label>
                    <input v-model="addItem.unit" id="unit" />
                  </div>
                </div>
                <div class="button-box">
                  <button @click="closeConsumablesAddWithoutIn(addItem, 1)" class="white-button">关闭</button>
                  <button @click="closeConsumablesAddWithIn(addItem, 1)">完成</button>
                </div>
              </div>
            </div>
          </div>
          <div class="input-table">
            <table class="comsumables-table">
              <thead>
                <tr>
                  <th>名称</th>
                  <th>数量</th>
                  <th>编辑</th>
                </tr>
              </thead>
              <tbody>
                <!-- Placeholder table rows -->
                <template v-for="item in consumablesList">
                  <tr v-if="item.type === '农药'" :key="item.consumables_Id">
                    <td>{{ item.name }}</td>
                    <td>{{ item.stock }}{{ item.unit }}</td>
                    <td><button @click="openComsuablesEdit(item, 1)">编辑</button></td>

                  </tr>
                </template>
                <div v-if="consumablesEdit[1]" class="modal-overlay">
                  <div class="modal-content-consumables">
                    <div class="title-close">
                      <h6>农药</h6>
                    </div>
                    <div class="middle-input">
                      <div class="input-row">
                        <label for="name">名称:</label>
                        <input v-model="editItem.name" id="name" />
                      </div>
                      <div class="input-row">
                        <label for="stock">余量:</label>
                        <input v-model="editItem.stock" id="stock" />
                      </div>
                      <div class="input-row">
                        <label for="unit">单位:</label>
                        <input v-model="editItem.unit" id="unit" />
                      </div>
                    </div>
                    <div class="button-box">
                      <button @click="closeConsumablesEditWithoutIn(1)" class="white-button">关闭</button>
                      <button @click="closeConsumablesEditWithIn(editItem, 1)">完成</button>
                    </div>
                  </div>
                </div>
                <!-- Add more rows as needed -->
              </tbody>
            </table>
          </div>
        </div>
        <div class="input-category">
          <div class="input-box">
            <h2>化肥</h2>
            <div class="title-button-gap">
              <button @click="openComsuablesAdd(addItem, assetSelectedFarm, '化肥', 2)">新添</button>
            </div>
            <div v-if="consumablesAdd[2]" class="modal-overlay">
              <div class="modal-content-consumables">
                <div class="title-close">
                  <h6>化肥信息填写</h6>

                </div>
                <div class="name">
                  <h4>农场:</h4>
                  <div>{{ assetSelectedFarm.name }}</div>
                </div>
                <div class="middle-input">
                  <div class="input-row">
                    <label for="name">名称:</label>
                    <input v-model="addItem.name" id="name" />
                  </div>
                  <div class="input-row">
                    <label for="stock">余量:</label>
                    <input v-model="addItem.stock" id="stock" />
                  </div>
                  <div class="input-row">
                    <label for="unit">单位:</label>
                    <input v-model="addItem.unit" id="unit" />
                  </div>
                </div>
                <div class="button-box">
                  <button @click="closeConsumablesAddWithoutIn(addItem, 2)" class="white-button">关闭</button>
                  <button @click="closeConsumablesAddWithIn(addItem, 2)">完成</button>
                </div>
              </div>
            </div>
          </div>
          <div class="input-table">
            <table class="comsumables-table">
              <thead>
                <tr>
                  <th>名称</th>
                  <th>数量</th>
                  <th>编辑</th>
                </tr>
              </thead>
              <tbody>
                <!-- Placeholder table rows -->
                <template v-for="item in consumablesList">
                  <tr v-if="item.type === '化肥'" :key="item.consumables_Id">
                    <td>{{ item.name }}</td>
                    <td>{{ item.stock }}{{ item.unit }}</td>
                    <td><button @click="openComsuablesEdit(item, 2)">编辑</button></td>

                  </tr>
                </template>
                <div v-if="consumablesEdit[2]" class="modal-overlay">
                  <div class="modal-content-consumables">
                    <div class="title-close">
                      <h6>农药</h6>
                    </div>
                    <div class="middle-input">
                      <div class="input-row">
                        <label for="name">名称:</label>
                        <input v-model="editItem.name" id="name" />
                      </div>
                      <div class="input-row">
                        <label for="stock">余量:</label>
                        <input v-model="editItem.stock" id="stock" />
                      </div>
                      <div class="input-row">
                        <label for="unit">单位:</label>
                        <input v-model="editItem.unit" id="unit" />
                      </div>
                    </div>
                    <div class="button-box">
                      <button @click="closeConsumablesEditWithoutIn(2)" class="white-button">关闭</button>
                      <button @click="closeConsumablesEditWithIn(editItem, 2)">完成</button>
                    </div>
                  </div>
                </div>
                <!-- Add more rows as needed -->
              </tbody>
            </table>
          </div>
        </div>

        <!-- Similar input-category sections for "化肥" and "农药" -->

      </div>

      <!-- Bottom Section -->
      <div class="bottom-section">
        <div class="device-category">
          <div class="device-box">
            <h2>设备</h2>
            <button @click="openEquipmentAdd(addEquipment, assetSelectedFarm)" class="EA">新添设备</button>
            <div v-if="equipmentAdd" class="modal-overlay">
              <div class="modal-content-consumables">
                <div class=title-close>
                  <h4>农场名:{{ assetSelectedFarm.name }}</h4>
                </div>
                <div class="middle-input">
                  <div class="input-row">
                    <label for="name">名称:</label>
                    <input v-model="addEquipment.name" id="name" />
                  </div>
                  <div class="input-row">
                    <label for="type">类型:</label>
                    <input v-model="addEquipment.type" id="type" />
                  </div>
                </div>
                <div class="button-box">
                  <button @click="closeEquipmentAddWithoutIn(addEquipment)" class="white-button">关闭</button>
                  <button @click="closeEquipmentAddWithIn(addEquipment, assetSelectedFarm)">完成</button>
                </div>
              </div>
            </div>
          </div>
          <div class="device-table">
            <table class="input-table">
              <thead>
                <tr>
                  <th>名称</th>
                  <th>类型</th>
                  <th>使用状态</th>
                  <th></th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <!-- Placeholder table rows -->
                <template v-for="item in equipmentList">
                  <tr>
                    <td>{{ item.name }}</td>
                    <td>{{ item.type }}</td>
                    <td>{{ item.status }}</td>
                    <td>

                      <div>
                        <button @click=openEquipmentEdit(item) disabled>编辑</button>

                      </div>
                    </td>
                    <td>
                      <div v-if="item.status === '占用'">
                        <button class="button" disabled>维护</button>
                      </div>
                      <div v-else>
                        <button @click="openEquipmentMaintenance(item)">维护</button>

                      </div>

                    </td>
                  </tr>
                </template>
                <div v-if="equipmentEdit" class="modal-overlay">
                  <div class="modal-content-consumables">
                    <div class="title-close">
                      <h6>设备</h6>
                    </div>
                    <div class="middle-input">
                      <div class="input-row">
                        <label for="name">名称:</label>
                        <input v-model="editEquipment.name" id="name" />
                      </div>
                      <div class="input-row">
                        <label for="type">类型:</label>
                        <input v-model="editEquipment.type" id="type" />
                      </div>
                    </div>
                    <div class="button-box">
                      <button @click="closeEquipmentEditWithoutIn()" class="white-button">关闭</button>
                      <button @click="closeEquipmentEditWithIn(editEquipment)">完成</button>
                    </div>
                  </div>

                </div>
                <!-- Add more rows as needed -->
                <div v-if="equipmentMaintenanceEdit" class="modal-overlay">
                  <div class="modal-content-equipment">
                    <div class="content-container-M">

                      <div class="middle-bar">
                        {{ equipmentM.name }}
                        <button @click="openEquipmentMaintenanceAdd(equipmentM)">新添记录</button>
                        <div v-if="equipmentMaintenanceAdd" class="modal-overlay">
                          <div class="modal-content-consumables">

                            <div class="content-container">
                              <!-- 上栏 -->

                              <!-- 中栏 -->
                              <div class="middle-bar">
                                <div class="input-row">
                                  <label for="cost">花费:</label>
                                  <input v-model="addEquipmentMaintenance.cost" id="cost" />
                                </div>

                                <div class="input-row">
                                  <label for="detail">详情:</label>
                                  <input v-model="addEquipmentMaintenance.detail" id="detail" />
                                </div>
                              </div>

                              <!-- 下栏 -->
                              <div class="bottom-bar">
                                <button @click="closeEquipmentMaintenanceAddWithoutIn(addEquipmentMaintenance)"
                                  class="white-button">关闭</button>
                                <button
                                  @click="closeEquipmentMaintenanceAddWithIn(addEquipmentMaintenance, equipmentM)">完成</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="bottom-bar">
                        <div class="device-table">
                          <table class="input-M-table">
                            <thead>
                              <tr>
                                <th>维护日期</th>
                                <th>维护详情</th>
                                <th>维护费用</th>
                                <th>维护负责人</th>
                              </tr>
                            </thead>
                            <tbody v-if="maintananceHistoryList.length > 0">
                              <tr v-for="item in maintananceHistoryList" :key="item.id">
                                <td>{{ removeT(item.maintenance_Date) }}</td>
                                <td>{{ item.detail }}</td>
                                <td>{{ item.cost }}</td>
                                <td>{{ item.name }}</td>
                              </tr>
                            </tbody>
                            <tbody v-else>
                              <tr>
                                <td>无</td>
                                <td>无</td>
                                <td>无</td>
                                <td>无</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                      <div class="title-close">
                        <button @click="closeEquipmentMaintenance()">关闭</button>
                      </div>
                    </div>
                  </div>
                </div>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </router-view>
</template>
<script setup>
// import axios from 'axios';
// // eslint-disable-next-line no-unused-vars
// import { ElMessage, ElMessageBox } from "element-plus";
import { ref, onMounted } from 'vue';
import {
  FarmConsuable, FarmEquipment, getAllFarm, ModifyConsumables
  , ModifyEquipment, insertConsumables, insertEquipment, equipmentMaintenanceHistory
  , insertMaintenance
} from '@/api/WarehouseandToolManagement.js';
import useUserStore2 from "@/store/uss";
const store = useUserStore2();
import { ElMessage, ElMessageBox } from "element-plus";
const consumablesList = ref([]);
const farm_Id = ref(1); // 假设你的农场ID是1，可以根据实际情况修改
const equipmentList = ref([]);
const farms = ref([]);
const assetSelectedFarm = ref(null);
const farmTitle = ref('');
const farmLocation = ref();
const consumablesEdit = ref([false, false, false]);
const editItem = ref();
const editEquipment = ref();
const equipmentAdd = ref(false);
const equipmentEdit = ref(false);
const consumablesAdd = ref([false, false, false]);
const maintananceHistoryList = ref([]);
const equipmentMaintenanceEdit = ref(false);
const equipmentMaintenanceAdd = ref(false);
const consumablesTitle = ref('信息填写');
const addItem = ref({
  type: '',
  stock: 0,
  unit: '',
  name: '',
  farm_id: 0,
});
const equipmentM = ref(null);
const addEquipment = ref({
  name: '',
  type: '',
  farm_id: 0,
})
const addEquipmentMaintenance = ref({
  technologist_id: store.token.id ,
  equipment_id: 0,
  maintenance_date: '',
  detail: '',
  cost: 0,
})
const openComsuablesEdit = (item, input) => {
  consumablesEdit.value[input] = true;
  editItem.value = item;
  console.log('编辑选中的项', item);
}
const removeT = (value) => {
  // 使用JavaScript的字符串替换方法将'T'替换为空字符串
  return value.replace('T', ' ');
};
const openEquipmentEdit = (item) => {
  equipmentEdit.value = true;
  editEquipment.value = item;
  console.log('编辑选中的设备', item);
}
const openComsuablesAdd = (item, farm, type, input) => {
  consumablesAdd.value[input] = true;
  console.log('控制变量', input, consumablesAdd);
  console.log('新添对象', item);
  console.log('新添对象所在农场', farm);

  console.log('新添对象类型', type);
  item.farm_id = farm.farm_Id;
  item.type = type;
}
const openEquipmentAdd = (item, farm) => {
  item.name = '';
  item.type = '';
  equipmentAdd.value = true;

  console.log('新添设备', item);
  console.log('新添设备所在农场', farm);
  item.farm_id = farm.farm_Id;
}
const openEquipmentMaintenance = async (item) => {
  equipmentMaintenanceEdit.value = true;
  equipmentM.value = item;
  console.log('编辑维护状态的设备信息', item);
  const params = {
    equipment_id: item.equipment_Id,
  };

  try {
    const response = await equipmentMaintenanceHistory(params);
    maintananceHistoryList.value = response.data;
    console.log('维护记录清单', maintananceHistoryList);
  } catch (error) {
    console.error('获取 维护记录清单 失败', error);
  }
}
const closeEquipmentMaintenance = () => {
  equipmentMaintenanceEdit.value = false;
}
const closeConsumablesEditWithIn = async (item, input) => {
  consumablesEdit.value[input] = false;
  console.log('关闭时选取的对象', item);
  const params = {
    consumables_Id: item.consumables_Id,
    name: item.name,
    unit: item.unit,
    stock: item.stock,
  }
  console.log('最后输入的对象', params);
  try {
    // Call the ModifyConsumables function with the item parameter
    const response = await ModifyConsumables(params);

    // Check the response for success or failure
    if (response.data === 0) {
      console.log('消费品修改成功')
      ElMessage.success('完成修改');
    } else {
      ElMessage.info('修改失败，请重试'); // Handle failure case
    }
  } catch (error) {
    console.error('修改失败', error); // Handle error case
  }
};
const closeEquipmentEditWithIn = async (item) => {
  equipmentEdit.value = false;
  console.log('关闭时选取的设备', item);
  const params = {
    equipment_id: item.equipment_Id,
    name: item.name,
    type: item.type,
  }
  try {
    const response = await ModifyEquipment(params);

    // Check the response for success or failure
    if (response.data === 0) {
      ElMessage.success('完成设备修改');
    } else {
      ElMessage.success('设备修改失败，请重试'); // Handle failure case
    }
  } catch (error) {
    console.error('设备修改失败', error); // Handle error case
  }
};
const closeConsumablesAddWithIn = async (item, input) => {
  consumablesAdd.value[input] = false;
  console.log('关闭时选取的对象', item);
  const params = {
    farm_id: item.farm_id,
    name: item.name,
    type: item.type,
    unit: item.unit,
    stock: item.stock,
  }
  const farm = {
    farm_Id: item.farm_id,
  }
  try {
    // Call the ModifyConsumables function with the item parameter
    const response = await insertConsumables(params);
    console.log("添加对象", params);
    // Check the response for success or failure
    if (response.data === 0) {
      ElMessage.success('完成添加');
      console.log('完成添加');
      fetchConsumablesList(farm);

    } else {
      ElMessage.error('添加失败，请重试'); // Handle failure case
      console.log('添加失败');
    }
  } catch (error) {
    console.error('修改失败', error); // Handle error case
  }
}
const closeEquipmentAddWithIn = async (item, input) => {
  consumablesAdd.value[input] = false;
  console.log('关闭时选取的设备', item);
  const params = {
    farm_id: item.farm_id,
    name: item.name,
    type: item.type,
  }
  const farm = {
    farm_Id: item.farm_id,
  }
  try {
    // Call the ModifyConsumables function with the item parameter
    const response = await insertEquipment(params);
    console.log("添加设备", params);
    // Check the response for success or failure
    if (response.data === 0) {
      equipmentAdd.value = false;
      ElMessage.success('完成设备添加');
      fetchEquipmentList(farm);
    } else {
      ElMessage.error('添加失败，请重试'); // Handle failure case
    }
  } catch (error) {
    console.error('修改失败', error); // Handle error case
  }
}
const closeConsumablesEditWithoutIn = (input) => {
  consumablesEdit.value[input] = false;
}
const closeEquipmentEditWithoutIn = () => {
  equipmentEdit.value = false;
}
const closeConsumablesAddWithoutIn = (item, input) => {
  consumablesAdd.value[input] = false;
  item.name = '';
  item.type = '';
  item.stock = 0;
  item.unit = '';
  item.farm_id = 0;
}
const closeEquipmentAddWithoutIn = (item) => {

  equipmentAdd.value = false;
  console.log(item);
  item.name = '';
  item.type = '';
  item.farm_id = 0;
}
const closeEquipmentMaintenanceAddWithoutIn = (item) => {
  equipmentMaintenanceAdd.value = false;
  console.log(item);
  item.technologist_id = 2120001;
  item.equipment_id = 0;
  item.maintenance_date = getFormattedMin();
  item.detail = '';
  item.cost = 0;
}
const closeEquipmentMaintenanceAddWithIn = async (add, item) => {
  equipmentMaintenanceAdd.value = false;
  console.log('输入的细节与花费', add);
  console.log('要新添维护历史的设备', item)

  const params = {
    technologist_id: add.technologist_id,
    equipment_id: item.equipment_Id,
    maintenance_date: getFormattedMin(),
    detail: add.detail,
    cost: add.cost,
  }
  console.log('要添加的记录', params);
  try {

    const response = await insertMaintenance(params);
    console.log("添加设备", params);
    // Check the response for success or failure
    if (response.data === 0) {
      ElMessage.success('完成设备添加');

      openEquipmentMaintenance(item);
    } else {
      console.log('新添记录失败')
      ElMessage.success('添加失败，请重试'); // Handle failure case
    }
  } catch (error) {
    console.error('修改失败', error); // Handle error case
  }

}
const openEquipmentMaintenanceAdd = (item) => {
  equipmentMaintenanceAdd.value = true;
  console.log('要编辑的对象', item)
}
const getFormattedMin = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  const seconds = String(now.getSeconds()).padStart(2, "0");

  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
};
const fetchConsumablesList = async (farm) => {
  const params = {
    farm_Id: farm.farm_Id,
  };

  try {
    const response = await FarmConsuable(params);
    consumablesList.value = response.data;
    console.log('消耗品清单', farm_Id, consumablesList);
  } catch (error) {
    console.error('获取 consumablesList 失败', error);
  }
};

// 获取 equipmentList 数据
const fetchEquipmentList = async (farm) => {
  const params = {
    farm_Id: farm.farm_Id,
  };

  try {
    const response = await FarmEquipment(params);
    equipmentList.value = response.data;
    console.log('设备清单', equipmentList);
  } catch (error) {
    console.error('获取 equipmentList 失败', error);
  }
};

const fetchTwoList = (farm) => {
  fetchConsumablesList(farm);
  fetchEquipmentList(farm);
  farmTitle.value = farm.name;
  farmLocation.value = farm.location
}
onMounted(async () => {
  try {
    const responseC = await getAllFarm();
    farms.value = responseC.data;
    assetSelectedFarm.value = farms.value[0];
    const params = {
      farm_Id: assetSelectedFarm.value.farm_Id,
    }
    console.log('选中的农场', assetSelectedFarm);
    const responseA = await FarmConsuable(params);
    consumablesList.value = responseA.data; // 假设接口返回的数据在 response.data 中
    const responseB = await FarmEquipment(params);
    equipmentList.value = responseB.data; // 假设接口返回的数据在 response.data 中

    console.log('farmsdata', farms);
    console.log('消耗品清单', consumablesList);
    console.log('设备清单', equipmentList)

    console.log('选中农场的数据', assetSelectedFarm);
    console.log('选中农场名字', assetSelectedFarm.value.name);
    farmTitle.value = assetSelectedFarm.value.name;
    console.log('农场标题', farmTitle);
    farmLocation.value = assetSelectedFarm.value.location

  } catch (error) {
    console.error('获取农场 consumables 失败', error);
  }
});

</script>
<style scoped>
select,
input {
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 5px;
  margin-bottom: 10px;
  /* width: 100px; */
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  /* 设置为100% */
  height: 100vh;
  /* 设置为100vh */
  background-color: rgba(255, 255, 255, 0.7);
  /* 半透明黑色遮罩层 */
  z-index: 9999;
  /* 确保弹窗在最上层显示 */
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-content-consumables {
  /* 设置弹窗的样式，使其在屏幕中央显示，宽度为 400px */
  width: 400px;
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.farm-management {
  margin-left: 10%;
}

body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
}

/* Container for the whole layout */
.farm-management {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
}

/* Top Section */
.top-section {
  display: flex;
  justify-content: space-between;
  width: 100%;
  padding-bottom: 20px;
}

.farm-info {
  flex: 1;
}

.farm-dropdown {
  flex: 1;
  text-align: right;
}

/* Middle Section */
.middle-section {
  display: flex;
  width: 100%;

}

.input-category {
  flex: 1;
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 10px;
  margin-right: 10px;
  background-color: white;
}

.input-box {
  display: flex;

  align-items: center;
  background-color: white;
  margin-bottom: 10px;

}

.input-table {
  max-height: 180px;
  overflow-y: auto;
  overflow-x: hidden;

}

/* Bottom Section */
.bottom-section {
  width: 100%;
  padding-top: 20px;
  align-items: flex-start;
  /* 左对齐 */
}

.device-category {
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: White;
  padding: 10px;
  width: 97.4%
}

.device-box {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.device-table {
  max-height: 200px;
  overflow-y: auto;
  overflow-x: hidden;
}

/* Table styles */
table {
  width: 100%;
  border-collapse: collapse;
}

th,
td {
  border: 1px solid #ccc;
  padding: 8px;
  text-align: center;
}

th {
  background-color: #f2f2f2;
}

/* Button styles */
button {
  padding: 5px 10px;
  border: none;
  background-color: #007bff;
  color: white;
  border-radius: 3px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

.comsumables-table {
  width: 100%;
  border-collapse: collapse;
}

.comsumables-table th:last-child,
.comsumables-table td:last-child {
  width: 80px;
  /* 调整最早入库时间列的宽度 */
}

.comsumables-table th:first-child,
.comsumables-table td:first-child {
  width: 100px;
  /* 调整最早入库时间列的宽度 */
}

.comsumables-table th:nth-child(2),
.comsumables-table td:nth-child(2) {
  width: 80px;
  /* 调整名称列的宽度 */
}

.title-close {
  text-align: center;
  /* 水平居中 */
}

.title-close h6 {
  font-size: 24px;
  /* 设置字号大小，你可以根据需要调整 */
  margin: 0;
  /* 移除默认的外边距，以防止额外的空白间距 */
}

.middle-input {
  text-align: center;
}

.button-box {
  text-align: center;
}

.content-title {
  flex: 1;
  /* 占据剩余空间 */
}

.white-button {
  background-color: white;
  color: black;
  border: 0.1px solid black;
  /* 添加边框，根据需要调整边框样式 */
  padding: 5px 10px;
  /* 调整按钮内边距，根据需要调整大小 */
  border-radius: 5px;
  /* 圆角边框，根据需要调整圆角程度 */
  cursor: pointer;
  /* 鼠标指针样式 */
  text-align: center;
  text-decoration: none;
  display: inline-block;
  margin-right: 10px;
  transition: background-color 0.3s, color 0.3s;
  /* 添加过渡效果 */
}

.white-button:hover {
  background-color: black;
  color: white;
}

/* 蓝底白字按钮 */
.button {
  background-color: blue;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  transition: background-color 0.3s, color 0.3s;
}

.button:hover {
  background-color: white;
  color: blue;
}

.button[disabled] {
  background-color: #ccc;
  /* 灰色背景 */
  color: #999;
  /* 灰色文字颜色 */
  cursor: not-allowed;
  padding:5px 10px;
  /* 禁用鼠标指针 */
}

.input-M-table {
  border-collapse: collapse;
  /* 合并单元格边框 */
  margin: 10px auto;
  /* 居中显示 */
}

.input-M-table th,
.input-M-table td {
  padding: 10px;
  /* 设置单元格内边距 */
  border: 1px solid #ccc;
  /* 添加边框 */
  text-align: center;
  /* 文字居中对齐 */
}

.input-M-table th {
  background-color: #f2f2f2;
  /* 设置表头背景颜色 */
  font-weight: bold;
  /* 加粗表头文字 */
}

.input-M-table tr:nth-child(even) {
  background-color: #f2f2f2;
  /* 设置偶数行背景颜色 */
}

.input-M-table tr:hover {
  background-color: #ddd;
  /* 鼠标悬停时的背景颜色 */
}

.input-M-table th:nth-child(1),
.input-M-table td:nth-child(1) {
  width: 90px;
  /* 设置第一列宽度为 100px */
}

.input-M-table th:nth-child(2),
.input-M-table td:nth-child(2),

.input-M-table th:nth-child(3),
.input-M-table td:nth-child(3) {
  width: 65px;
  /* 设置第二、第三、第四列宽度为 50px */
}

.input-M-table th:nth-child(4),
.input-M-table td:nth-child(4) {
  width: 80px;
}

.content-container-M {
  display: flex;
  flex-direction: column;
  border: 1px solid #ccc;
  margin: 20px;
  width: 450px
}

.top-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #6b6969;
  color: #fff;
  padding: 10px;
}

.middle-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
}

.bottom-bar {
  padding: 10px;
}

.modal-content-equipment {
  /* 设置弹窗的样式，使其在屏幕中央显示，宽度为 400px */
  width: 500px;
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.name {
  display: flex;
  align-items: center;
  /* 垂直居中对齐 */
  justify-content: center;
  /* 水平居中对齐 */
  margin-bottom: 10px;
  margin-top: 10px;
}

.name h4,
.name div {
  margin: 0;
  /* 移除默认的外边距，以防止额外的空白间距 */
}

.name h4 {
  font-weight: normal;
  /* 取消黑体样式 */
  /* 添加其他字体样式（例如字体系列和大小） */
}

.EA {
  margin-left: 84%;
}

.input-row {
  margin-top: 10px;
  /* 顶部间距 */
  margin-bottom: 10px;
  /* 底部间距 */
}

input {
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
  margin-bottom: 10px;
}

.title-button-gap {
  margin-left: 67%
}

.title-button-gapO {
  margin-left: 63%
}
</style>
