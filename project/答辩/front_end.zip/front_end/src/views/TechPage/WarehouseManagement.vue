<template>
  <router-view>
    <div class="whole">
      <div class="header">
        <div>
          <h2>粮仓</h2>
        </div>
        <div class="container">
          <button @click="openFileter">筛选</button>
          <div v-if="Fileter" class="modal-overlay">
            <div class="fileter-container">
              <div class="top-section-warehouse">
                <div class="title-row">
                  <div class="row">

                    <h1 class="fileterTitle">
                      <div class="title-high">
                        高级筛选
                      </div>
                      <div class="closeButton">
                        <button @click="closeFilter">关闭</button>
                      </div>
                    </h1>
                  </div>
                </div>
                <div class="row">
                  <div class="column">
                    <label for="selectedFarm">农场</label>
                    <select id="selectedFarm" v-model="selectedFarm" @change="handleSelectChange" class="custom-select">
                      <option value="">全部</option>
                      <option v-for="farm in uniqueFarmNames" :value="farm" :key="farm">{{ farm }}
                      </option>
                    </select>
                  </div>
                  <div class="column">
                    <label for="selectedWarehouse">仓库</label>
                    <select id="selectedWarehouse" v-model="selectedWarehouse" @change="handleSelectChange"
                      class="custom-select">
                      <option value="">全部</option>
                      <option v-for="warehouse in uniqueWarehouseNames" :value="warehouse" :key="warehouse">{{ warehouse
                      }}
                      </option>
                    </select>
                  </div>
                  <div class="column">
                    <label for="selectedItemName">名称</label>
                    <select id="selectedItemName" v-model="selectedItemName" @change="handleSelectChange"
                      class="custom-select">
                      <option value="">全部</option>
                      <option v-for="item in uniqueItemNames" :value="item" :key="item">{{
                        item }}</option>
                    </select>
                  </div>
                </div>
                <div class="row">
                  <div class="column">
                    <label for="selectedItemType">类型</label>
                    <select id="selectedItemType" v-model="selectedItemType" @change="handleSelectChange"
                      class="custom-select">
                      <option value="">全部</option>
                      <option value="蔬菜">蔬菜</option>
                      <option value="水果">水果</option>
                      <option value="谷类">谷类</option>

                      <!-- 其他类型选项... -->
                    </select>
                  </div>
                  <div class="column">
                    <label for="selectedItemQuality">品质</label>
                    <select id="selectedItemQuality" v-model="selectedItemQuality" @change="handleSelectChange"
                      class="custom-select">
                      <option value="">全部</option>
                      <option value="特级">特级</option>
                      <option value="一级">一级</option>
                      <option value="二级">二级</option>
                      <!-- 其他品质选项... -->
                    </select>
                  </div>
                  <div class="column">
                    <button @click="reset">重置</button>
                  </div>
                </div>
                <!-- <div class="row">
                  <button @click="showAddWarehouseDialog">添加粮仓</button>
                </div> -->
                <div v-if="showDialog" class="dialog-overlay">
                  <div class="dialog">
                    <h2>添加粮仓</h2>
                    <label>选择农场：</label>
                    <select v-model="addFarmName">
                      <option value="" disabled>请选择</option>
                      <option v-for="farm in uniqueFarmNames" :value="farm" :key="farm">{{ farm }}</option>
                    </select>
                    <label>仓库名称：</label>
                    <input type="text" v-model="addWarehouseName">
                    <button @click="addWarehouse(addFarmName, addWarehouseName)">完成</button>
                    <button @click="closeDialog" class="white-button">取消</button>
                  </div>
                </div>
              </div>

              <div class="bottom-section-warehouse">
                <table class="table-filter">
                  <thead>
                    <tr>
                      <th>农场名</th>
                      <th>粮仓名</th>
                      <th>名称</th>
                      <th>类型</th>
                      <th>品质</th>
                      <th>存量</th>
                      <th></th>
                      <th>上架量</th>
                      <th></th>
                      <th></th>
                      <th>最早入库时间</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>

                    <template v-for="item in filteredItems"
                      ::key="item.farmName + item.warehousename + item.name + item.crop_Type + item.quality">
                      <tr>
                        <td>{{ item.farmName }}</td>
                        <td>{{ item.warehousename }}</td>
                        <td>{{ item.name }}</td>
                        <td>{{ item.crop_Type }}</td>
                        <td>{{ item.quality }}</td>
                        <td>
                          <input v-model="item.weight" :disabled="!isEditing(item)" class="narrow-input" />
                        </td>
                        <td>
                          <button @click="weightEdit(item)">{{ getSaveButtonText(item) }}</button>
                        </td>
                        <td>
                          <input v-model="item.stock" :disabled="!isStockEditing(item)" class="narrow-input" />
                        </td>
                        <td>
                          <button @click="stockEdit(item)">{{ getSaveButtonTextTwo(item) }}</button>

                        </td>
                        <td><button @click="openStockEdit(item)">记录</button></td>
                        <td>{{ removeT(item.earliest_Date) }}</td>
                        <td><button @click="openrecord(item.wares_Id)">记录</button></td>

                      </tr>

                    </template>
                  </tbody>
                </table>
                <div v-if="isStockEdit" class="overlay-record">
                  <div class="modal-content-record">
                    <div class="record-top" style="justify-content: space-between;">
                      <h2 class="record-title">仓库入库记录</h2>


                      <button @click="closeStockEdit">关闭</button>
                    </div>
                    <div class="record-bottom">
                      <table class="table-record">
                        <thead>
                          <tr>
                            <th>时间</th>
                            <th>上下架量</th>
                            <th>记录人</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr v-for="historyItem in theShelfHistory"
                            :key="historyItem.shelf_Date + historyItem.amount + historyItem.name">
                            <td>{{ removeT(historyItem.shelf_Date) }}</td>
                            <td>{{ historyItem.amount }}</td>
                            <td>{{ historyItem.name }}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <div v-if="showRecordPopup" class="overlay-record">
                  <div class="modal-content-record">
                    <div class="record-top" style="justify-content: space-between;">

                      <h2 class="record-title">仓库入库记录</h2>
                      <div class="record-close-button">
                        <button @click="closeRecordPopup">关闭</button>
                      </div>
                    </div>
                    <div class="record-bottom">
                      <table class="table-record">
                        <thead>
                          <tr>
                            <th>入库日期</th>
                            <th>入库量</th>
                            <th>负责人</th>
                          </tr>
                          <div v-if="isWeightEditing" class="modal-overlay">
                            <div class="modal-content">
                              <div class="title-close">
                                <h2>{{ consumablesTitle }}</h2>
                                <button @click="closeWeightEditing(editItem)">关闭</button>
                              </div>
                              <div>
                                <h4>农场名字</h4>
                                <div>{{ assetSelectedFarm.name }}</div>
                              </div>
                              <div class="input-row">
                                <label for="name">名称:</label>
                                <input v-model="addItem.name" id="name" />
                              </div>
                              <div class="input-row">
                                <label for="stock">余量:</label>
                                <input v-model="addItem.stock" id="stock" />
                              </div>
                              <div class="input-row">
                                <label for="unit">单位:</label>
                                <input v-model="addItem.unit" id="unit" />
                              </div>
                              <button @click="closeConsumablesAddWithIn(addItem, assetSelectedFarm, '种子')">完成</button>
                            </div>
                          </div>
                        </thead>
                        <tbody>
                          <tr v-for="record in theWaresHistory" :key="record.ware_id">
                            <td>{{ removeT(record.harvest_Date) }}</td>
                            <td>{{ record.weight }}</td>
                            <td>{{ record.name }}</td>
                          </tr>
                        </tbody>
                      </table>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="farm-container-out">
        <br>
        <br>
        <div v-for="farm in originalFarms" :key="farm.id" class="all-farm">
          <div class="farm-title">
            <h3>{{ farm.name }}</h3>
          </div>
          <div class="farm" ref="'farmElementRefName-' + farm.id">
            <div class="warehouse-list">
              <div v-for="warehouse in farm.warehouses" :key="warehouse.name + farm.name" class="warehouse-box">
                <div v-if="isWarehouseVisible">
                  <h4 class="warehouse-info"> {{ warehouse.name }}
                    <button class="details-button" @click="showDetails(warehouse, farm)">查看详情</button>
                    <div class="border-line"></div>
                  </h4>
                  <table class="fixed-table">

                    <tr>
                      <th>名称</th>
                      <th>类型</th>
                      <th>品质</th>
                      <th>存量</th>
                      <th>上架量</th>
                      <th>最早入库时间</th>
                    </tr>
                    <tr v-for="item in getTopThreeItems(warehouse.items)" :key="item.name">
                      <td>{{ item.name }} </td>

                      <td>{{ item.type }}</td>
                      <td>{{ item.quality }}</td>
                      <td>{{ item.weight }}</td>
                      <td>{{ item.stock }}</td>
                      <td>{{ removeT(item.earliest_date) }}</td>
                    </tr>
                  </table>

                  <div v-if="showModal && warehouse == currentWarehouse && farm == currentFarm" class="modal-overlay">
                    <div class="modal-content">
                      <div class="title-close">
                        <h2>{{ currentWarehouse.name }} 详情 </h2>
                      </div>
                      <div class="table-detail-contain">
                        <table class="fixed-table-detail">
                          <!-- 表格内容，展示全部数据（详情） -->
                          <tr>
                            <th>名称<img src="/order.jpg" alt="Order Icon" class="order-icon"
                                @click="sortFarmByName(warehouse, farm)" /></th>
                            <th>类型<img src="/order.jpg" alt="Order Icon" class="order-icon"
                                @click="sortFarmByType(warehouse, farm)" /></th>
                            <th>品质<img src="/order.jpg" alt="Order Icon" class="order-icon"
                                @click="sortFarmByQuality(warehouse, farm)" /></th>
                            <th>存量 <img src="/order.jpg" alt="Order Icon" class="order-icon"
                                @click="sortFarmByWeight(warehouse)" /></th>
                            <th>上架量 <img src="/order.jpg" alt="Order Icon" class="order-icon"
                                @click="sortFarmByStock(warehouse, farm)" /></th>
                            <th>最早入库时间 <img src="/order.jpg" alt="Order Icon" class="order-icon"
                                @click="sortFarmByDateTime(warehouse, farm)" /></th>
                          </tr>

                          <tr v-for="item in showWarehouse.items"
                            :key="item.name + showWarehouse.name + currentFarm.name + item.type + item.quality">
                            <td>
                              <template v-if="isItemEditing(item)">
                                <input v-model="item.name">
                              </template>
                              <template v-else>
                                {{ item.name }}

                              </template>
                            </td>
                            <td>{{ item.type }}</td>
                            <td>{{ item.quality }}</td>
                            <td>{{ item.weight }}</td>
                            <td>{{ item.stock }}</td>
                            <td>{{ removeT(item.earliest_date) }}</td>
                          </tr>
                        </table>
                      </div>
                      <div class="title-close">
                        <button @click="closeModal">关闭</button>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </router-view>
</template>
<script setup>
import useUserStore2 from "@/store/uss";
const store = useUserStore2();

import axios from 'axios';
// eslint-disable-next-line no-unused-vars

import { onMounted, ref } from 'vue';
import { createWarehouse, wareConsume, WaresOnShelf, ShelfHistory, WaresHistory, filter, GetFarmWarehouse } from '@/api/WarehouseandToolManagement.js'; // Import the newly created function
import cloneDeep from 'lodash/cloneDeep';
import { ElMessage, ElMessageBox } from "element-plus";
const farms = ref([]);
const showModal = ref(false);
const currentWarehouse = ref(null);
const currentFarm = ref(null);
const selectedName = ref('');
const selectedGrade = ref('');
const isStockEdit = ref(false);

const editingItem = ref(null);

// const allItemNames= ref([]); 
// const nameOptions = ref(['卷心菜', '番茄', '胡萝卜']); // 根据实际情况添加更多选项
// const gradeOptions = ref(['特级', '一级', '二级']); // 根据实际情况添加更多选项
const editingItems = ref(new Set()); // 存储正在编辑的项目的集合
const addFarmName = ref('');
const addWarehouseName = ref('');
const Fileter = ref(false);
const selectedFarm = ref('');
const selectedWarehouse = ref('');
const selectedItemName = ref('');
const selectedItemType = ref('');
const selectedItemQuality = ref('');
// const currentSelectdWarehouse = ref(null);
const currentSelectedFarm = ref(null);
const currentSelectedWarehouse = ref(null);
//用来判断下滑菜单
const showDialog = ref(false);
const filteredItems = ref([]);
const uniqueFarmNames = ref([]);
const uniqueWarehouseNames = ref([]);
const uniqueItemNames = ref([]);
const editingStatus = ref({
  stock: null,
  weight: null,
});
const theShelfHistory = ref([]);
const theWaresHistory = ref([]);

const saveButtonText = ref('编辑');
const stock = ref();
const weight = ref();
const isWeightEditing = ref(false);
const loadButtonText = ref('上下架');
const editStock = ref(false);
const showRecordPopup = ref(false);
const isUpshelf = ref(false);
const changeWeight = ref(0);
const upShelfInput = ref('');
const isDownshelf = ref(false);
const upShelfItem = ref();
const originalWeight = ref(0);
const originalStock = ref(0);
const originalFarms = ref([]);
const fetchAllWarehosue = async () => {
  try {
    const response = await GetFarmWarehouse();
    console.log('全部仓库数据', response);
  } catch (error) {
    console.error('Error fetching warehouse', error);
  }
}
const fetchData = async () => {
  try {
    const params = {
      farmName: selectedFarm.value,
      warehouseName: selectedWarehouse.value,
      name: selectedItemName.value,
      cropType: selectedItemType.value,
      quality: selectedItemQuality.value
    };

    const response = await filter(params);
    filteredItems.value = response.data; // 假设 API 返回的数据是数组
    console.log('筛选结果数据', filteredItems);
    const farmNamesSet = new Set();
    const warehouseNamesSet = new Set();
    const itemNamesSet = new Set();

    response.data.forEach(item => {
      farmNamesSet.add(item.farmName);
      warehouseNamesSet.add(item.warehousename);
      itemNamesSet.add(item.name);
    });

    // 将 Set 转换为数组，存储在相应的变量中
    uniqueFarmNames.value = Array.from(farmNamesSet);
    uniqueWarehouseNames.value = Array.from(warehouseNamesSet);
    uniqueItemNames.value = Array.from(itemNamesSet);

    // 将数据存储在 filteredItems 中
    filteredItems.value = response.data;
    console.log(uniqueFarmNames);
    console.log(uniqueWarehouseNames);
    console.log(uniqueItemNames);
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};
const fetchFarmsData = async () => {
  try {
    const params = {
      farmName: "",
      warehouseName: "",
      name: "",
      cropType: "",
      quality: ""
    };

    const response = await filter(params);
    const newItems = response.data; // 假设 API 返回的数据是数组
    console.log('原始数据', newItems);
    // 将新形式的数据转化为旧形式的数据并存储在 farms 数组中
    const convertedFarms = {};
    newItems.forEach(item => {
      if (!convertedFarms[item.farmName]) {
        convertedFarms[item.farmName] = {
          farm_id: null, // 你之前的数据结构中的 farm_id
          name: item.farmName,
          warehouses: []
        };
      }
      const farm = convertedFarms[item.farmName];
      let existingWarehouse = farm.warehouses.find(warehouse => warehouse.name === item.warehousename);
      if (!existingWarehouse) {
        existingWarehouse = {
          warehouse_id: null, // 你之前的数据结构中的 warehouse_id
          name: item.warehousename,
          items: []
        };
        farm.warehouses.push(existingWarehouse);
      }
      const itemToAdd = {
        name: item.name,
        type: item.crop_Type,
        quality: item.quality,
        earliest_date: item.earliest_Date,
        weight: item.weight,
        stock: item.stock
      };
      existingWarehouse.items.push(itemToAdd);
    });

    // 将转化后的数据存储在 farms 数组中
    farms.value = Object.values(convertedFarms);
    originalFarms.value = farms.value;
    console.log('农场数据', farms);

  } catch (error) {
    console.error('Error fetching data:', error);
  }
};
const handleSelectChange = async () => {
  try {
    const params = {
      farmName: selectedFarm.value,
      warehouseName: selectedWarehouse.value,
      name: selectedItemName.value,
      Type: selectedItemType.value,
      quality: selectedItemQuality.value
    };

    const response = await filter(params);
    // 假设 API 返回的数据是数组
    console.log('筛选条件', params);
    console.log("筛选成功");
    console.log(filteredItems);
    // 将 Set 转换为数组，存储在相应的变量中

    // 将数据存储在 filteredItems 中
    filteredItems.value = response.data;


  } catch (error) {
    console.error('Error fetching data:', error);
    console.log(filteredItems);
  }
};
const sortFarmByStock = () => {

  showWarehouse.value.items.sort((a, b) => a.stock - b.stock);

};
const sortFarmByWeight = () => {
  showWarehouse.value.items.sort((a, b) => a.weight - b.weight);
};
const sortFarmByName = () => {
  showWarehouse.value.items.sort((a, b) => a.name.localeCompare(b.name));
};
const sortFarmByType = () => {
  showWarehouse.value.items.sort((a, b) => a.type.localeCompare(b.type));
};
const sortFarmByQuality = () => {

  showWarehouse.value.items.sort((a, b) => a.quality.localeCompare(b.quality));

};
const sortFarmByDateTime = () => {

  showWarehouse.value.items.sort((a, b) => {
    const dateA = new Date(a.earliest_date); // 将日期时间字符串转换为 Date 对象
    const dateB = new Date(b.earliest_date);

    return dateA - dateB; // 根据日期时间升序排序
  });
  ;
};
const weightEdit = async (item) => {
  if (!isEditing(item)) {
    // 如果当前行不在编辑状态，则开始编辑当前行
    editingItem.value = item;
    originalWeight.value = item.weight;
  } else if (editingItem.value === item) {
    // 如果当前行已经在编辑状态，执行保存操作
    const params = {
      wares_id: item.wares_Id,
      weight: originalWeight.value - item.weight,
    };
    console.log('修改后的重量', item.weight);
    console.log('原始重量', originalWeight)
    console.log('重量差', params.weight);
    if (item.weight > originalWeight.value) {
      // 弹窗提示存量不能修改为更大
      console.log('修改失败');
      ElMessage.info('存量不能修改为更大的值');
      item.weight = originalWeight; // 将 item.weight 改回之前保存的值
    } else {
      try {
        const response = await wareConsume(params);
        // 在这里根据后端的返回结果进行处理
        console.log('存量更新成功', response);
        console.log('输入数据', params);
        ElMessage.success('修改成功');
        console.log('返回数据', response.data)
        editingItem.value = null; // 保存后结束编辑状态
      } catch (error) {
        console.error('存量更新失败', error);
        ElMessage.error('存量更新失败');
        // 在这里处理错误
      }
    }
  } else {
    // 如果有其他行在编辑状态，提示用户先保存或取消其他行的编辑
    alert('请先保存或取消其他行的编辑');
  }
};
const editingStockItem = ref(null);
const stockEdit = async (item) => {

  if (!isStockEditing(item)) {
    // 如果当前行不在编辑状态，则开始编辑当前行
    editingStockItem.value = item;
    originalStock.value = item.stock;
  } else if (editingStockItem.value === item) {
    // 如果当前行已经在编辑状态，执行保存操作
    const params = {
      wares_id: item.wares_Id,
      weight: item.stock - originalStock.value,
      salesperson_id: store.token.id,
    };
    console.log('修改后的重量', item.stock);
    console.log('原始重量', originalStock)
    console.log('重量差', params.weight);
    console.log('库存', item.weight);
    if (item.weight < originalStock.value) {
      // 弹窗提示存量不能修改为更大
      console.log('修改失败1');
      ElMessage.info('上架量不能修改为比库存更大的值');
      item.stock = originalStock; // 将 item.weight 改回之前保存的值
    } else {
      try {
        const response = await WaresOnShelf(params);
        // 在这里根据后端的返回结果进行处理
        if (response.data === 1) {
          console.log('输入数据', params);
          console.log('修改失败2');
        }
        else {
          console.log('存量更新成功', response);
          console.log('输入数据', params);
          ElMessage.success('修改成功');
          console.log('返回数据', response.data)
          editingStockItem.value = null; // 保存后结束编辑状态
        }
      }
      catch (error) {
        console.error('存量更新失败', error);
        ElMessage.error('存量更新失败');
        // 在这里处理错误
      }
    }
  } else {
    // 如果有其他行在编辑状态，提示用户先保存或取消其他行的编辑
    alert('请先保存或取消其他行的编辑');
  }
};
//编辑上架量

// const StockEdit = async (item, inchangeWeight) => {
//   console.log(item.stock);
//   console.log('要编辑的对象');
//   console.log(item);
//   console.log("库存编辑量")
//   console.log(inchangeWeight);
//   const params = {
//     wares_id: item.wares_Id,
//     weight: inchangeWeight,
//     salesperson_id: 1,
//   };

//   try {
//     const response = await wareConsume(params);
//     // 在这里根据后端的返回结果进行处理
//     console.log('上架更新成功', response);
//     console.log('输入数据', params);
//     ElMessage.success('修改成功');
//     closeUpShelf();
//   } catch (error) {

//     console.error('存量更新失败', error);
//     // 在这里处理错误
//   }
// }

const openStockEdit = (item) => {
  isStockEdit.value = true;
  upShelfItem.value = item;
  fetchShelfHistory(item);
  console.log('查询对象', item);

}
const closeStockEdit = () => {
  isStockEdit.value = false;
}

const fetchShelfHistory = async (item) => {
  const params = {
    wares_Id: item.wares_Id,
  }
  console.log(item);
  console.log('查询对象', params)
  try {
    console.log('上下架记录查询成功');
    const response = await ShelfHistory(params);

    theShelfHistory.value = response.data; // 假设接口返回的数据在 response.data 中
    console.log('THEshelfHISTORY', theShelfHistory);
  } catch (error) {
    console.error('获取上下架历史记录失败', error);
  }
}
//
const fetchWaresHistory = async (wares_Id) => {
  const params = {
    wares_id: wares_Id,
  }
  try {
    console.log('入库记录查询成功');
    const response = await WaresHistory(params);

    theWaresHistory.value = response.data; // 假设接口返回的数据在 response.data 中
    console.log('THEWaresHISTORY', theWaresHistory);
  } catch (error) {
    console.error('获取入库历史记录失败', error);
  }
}

// 在组件加载时触发一次获取数据
onMounted(() => {
  fetchData();
  fetchFarmsData();

  fetchWaresHistory();
});
const removeT = (value) => {
  // 使用JavaScript的字符串替换方法将'T'替换为空字符串
  return value.replace('T', ' ');
};
//   const selectedWarehouseData = currentSelectedFarm.value.warehouses.find(warehouse => warehouse.name === selectedWarehouse.value);
//   console.log(2);
//   if (selectedWarehouseData) {
//     chooseWarehouse(selectedWarehouseData);

//   }
// };
const openrecord = (wares_Id) => {
  showRecordPopup.value = true;
  const warehouseId = 0;
  console.log('查询记录的库存号', wares_Id);
  fetchWaresHistory(wares_Id);
}
const closeRecordPopup = () => {
  showRecordPopup.value = false;
}
const openFileter = () => {
  Fileter.value = true;
  currentSelectedFarm.value = farms.value[0];
  currentSelectedWarehouse.value = currentSelectedFarm.value.warehouses[0];
}

const reset = () => {
  selectedFarm.value = '';
  selectedWarehouse.value = '';
  selectedItemName.value = '';
  selectedItemType.value = '';
  selectedItemQuality.value = '';
  handleSelectChange();
};

const showAddWarehouseDialog = () => {
  showDialog.value = true;
};

const closeDialog = () => {
  showDialog.value = false;
  selectedFarm.value = '';

};

const addWarehouse = async (infarmName, inwarehouseName) => {
  const params = {
    farmName: infarmName,
    warehouseName: inwarehouseName,
  };

  try {
    const response = await createWarehouse(params);
    // Handle the response here if needed
    console.log('Warehouse added successfully', response);
    fetchAllWarehosue();
  } catch (error) {
    // Handle errors here
    console.error('Error adding warehouse', error);
  }
  closeDialog();
};



const getTopThreeItems = (items) => {
  return items.slice(0, 3);
};
const showWarehouse = ref([]);
const showDetails = (warehouse, farm) => {
  currentWarehouse.value = warehouse;
  currentFarm.value = farm;
  console.log('选择的农场与仓库111', farm, warehouse, currentFarm, currentWarehouse);
  showModal.value = true;
  console.log('目标农场名', currentFarm.value.name)
  console.log(farms[0])
  for (const farmm of farms.value) {
    // 检查农场是否匹配
    if (farmm.name === currentFarm.value.name) {
      // 遍历农场中的仓库
      for (const warehousee of farm.warehouses) {
        // 检查仓库是否匹配
        if (warehousee.name === currentWarehouse.value.name) {
          // 如果找到匹配的仓库，将其赋值给 showWarehouse
          showWarehouse.value = JSON.parse(JSON.stringify(warehousee));; // 找到后可以立即返回，不需要继续搜索
        }
      }
    }
  }
  console.log('找到的仓库', 'showWarehouse', showWarehouse);

};

const closeModal = () => {
  currentWarehouse.value = null;
  currentFarm.value = null;
  showModal.value = false;
  fetchFarmsData();
};

const getFilteredItems = (items) => {
  return items.filter((item) => {
    if (selectedName.value && item.name !== selectedName.value) {
      return false;
    }
    if (selectedGrade.value && item.grade !== selectedGrade.value) {
      return false;
    }
    return true;
  });
};

const isWarehouseVisible = (warehouse) => {
  if (!selectedName.value && !selectedGrade.value) {
    return true; // Show all warehouses if no criteria selected
  }

  const filteredItems = getFilteredItems(warehouse.items);
  return filteredItems.length > 0;
};

const isItemEditing = (item) => {
  return editingItems.value.has(`${item.name}-${item.grade}`);
};
const closeFilter = () => {
  Fileter.value = false;
  selectedFarm.value = '';
  selectedWarehouse.value = '';
  selectedItemName.value = '';
  selectedItemType.value = ''
  selectedItemQuality.value = '';
};
// 获取按钮文本
const getSaveButtonText = (item) => {
  return editingItem.value === item ? '保存' : '编辑';
};
const getSaveButtonTextTwo = (item) => {
  return editingStockItem.value === item ? '保存' : '编辑';
}
// 检查是否正在编辑
const isEditing = (item) => {
  return editingItem.value === item;
};
const isStockEditing = (item) => {
  return editingStockItem.value === item;
};
const getAllFarmWarehouse = (farm_id) => {
  const params = {
    farm_Id: farm_id,
  };

}
// const changeContent = (item) => {
//   const itemId = `${item.name}-${item.grade}`;
//   if (isItemEditing(item)) {
//     editingItems.value.delete(itemId); // 取消编辑状态
//     // 在这里可以将编辑的内容提交到后端或进行其他保存操作
//   } else {
//     editingItems.value.add(itemId); // 进入编辑模式
//   }
// };

// const deleteItem = (item) => {
//   const index = currentWarehouse.value.items.findIndex((i) => i === item);
//   if (index !== -1) {
//     currentWarehouse.value.items.splice(index, 1);
//     const itemId = `${item.name}-${item.grade}`;
//     editingItems.value.delete(itemId); // 删除时也要取消编辑状态
//   }
// };

// const addItem = () => {
//   const newItem = {
//     name: '',
//     grade: '',
//     category: '',
//     stock: '',
//   };

//   // Check for duplicate items
//   const isDuplicate = currentWarehouse.value.items.some(item =>
//     item.name === newItem.name && item.grade === newItem.grade
//   );

//   if (isDuplicate) {
//     // Show a popup message for duplicate item
//     // You can use any UI library's modal or ElMessage.success function
//     alert('已有对应物品，无法添加重复项');
//     return; // Cancel adding the item
//   }

//   // Add the item if not duplicate
//   currentWarehouse.value.items.push(newItem);
//   const newItemId = `${newItem.name}-${newItem.grade}`;
//   editingItems.value.add(newItemId); // 进入编辑模式
// };


// 在组件创建时获取初始数据



</script>

<style scoped>
.table-detail-contain {
  height: 200px;
  overflow-y: auto;
  text-align: center;
}

.record-title {
  margin: 0;
}

.record-close-button {
  margin-left: 400px;
  /* 将按钮推到右侧 */
}

.record-top {
  display: flex;
  margin-bottom: 10px;
}

.record-bottom {
  max-height: 250px;
  overflow-y: auto;
}

.modal-content-record {
  width: 600px;
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.upshelf-content {
  width: 800px;
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.modal-content-shelf {
  width: 800px;
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.table-record {
  width: 100%;
  border-collapse: collapse;
}

.table-record th:first-child,
.table-record td:first-child {
  width: 300px;
  /* 调整名称列的宽度 */
}

.table-record th:nth-child(2),
.table-record th:nth-child(2) {
  width: 150px;
  /* 调整名称列的宽度 */
}

.history-table {
  width: 100%;
  border-collapse: collapse;
}

.history-table th,
.history-table td {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: center;
}

.narrow-input {
  width: 70%;
}

.whole {
  margin-left: 15%;
  width: 80%
}

.all-farm {
  width: 100%;
}

.farm {
  margin-right: 20px;
  /* 可选：添加右侧边距，增加农场之间的间距 */
  overflow-x: auto;
  display: flex;
  flex-wrap: nowrap;
  margin-bottom: 0px;
  height: 400px;
}

.farm-title {
  margin-bottom: 10px;
  /* 可选：添加下方边距，增加农场标题与仓库列表之间的间距 */
}

.warehouse-list {

  display: flex;
  /* 使用 Flexbox 布局，子元素横向排列 */
  flex-wrap: nowrap;
  height: 350px;
  /* 子元素不换行，横向排列 */
  /* 横向内容溢出时，添加横向滚动条 */
}

.warehouse-box {
  border: 1px solid #ccc;
  border-radius: 5px;
  /* Add rounded corners to the warehouse box */
  padding: 10px;
  height: 300px;
  width: 520px;
  /* 设置每个仓库的宽度，可以根据需要调整宽度值 */
  background-color: #ffffff;
  margin-right: 10px;
  /* 可选：添加右侧边距，增加仓库之间的间距 */

  display: flex;
  flex-wrap: wrap;
  position: relative;
}

.farm-container-out {
  display: flex;
  flex-wrap: wrap;
  overflow-x: auto;
  width: 1150px;
  /* background-color: #ffffff; */
  padding-left: 20px;
 
}

table {
  table-layout: fixed;
  /* 使用固定布局，使列宽度固定 */
  width: 80%;
}

th,
td {
  text-align: left;
  /* 设置表头和单元格文本左对齐 */
  vertical-align: top;
  padding: 5px;
  /* 设置单元格内边距，可以根据需要进行调整 */
}

/* 可选样式：设置表头的背景颜色和文字颜色 */
th {
  background-color: #f2f2f2;
  color: #333;
}

.details-button {
  margin-left: 50px;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;
  /* 添加相对定位 */
}

.search-bar {
  display: flex;
  align-items: center;
  position: relative;
  /* 添加相对定位 */
}

/* 筛选下拉菜单 */
.search-dropdown {
  position: absolute;
  /* 添加绝对定位 */
  top: 20px;
  /* 调整下拉菜单与搜索框的垂直距离 */
  left: 0;
  /* 调整下拉菜单与搜索框的水平位置，这里设置为 0 表示与搜索框左对齐 */
  background-color: #fff;
  /* 设置下拉菜单背景颜色 */
  border: 1px solid #ccc;
  /* 设置下拉菜单边框样式 */
  border-radius: 5px;
  /* 添加圆角边框 */
  padding: 5px 10px;
  /* 设置下拉菜单内边距 */
  z-index: 1;
  /* 设置 z-index 属性，保证下拉菜单在其他内容上方显示 */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  /* 添加阴影效果 */
}

/* 仓库标题 */
.warehouse-info {
  position: relative;
  /* 设置为定位上下文 */
  width: 100%;
  display: flex;
  margin-left: 15%;
}

/* 仓库标题和下面的分界线 */
.border-line {
  position: absolute;
  /* 绝对定位 */
  bottom: 150px;
  /* 距离底部为0，即固定在底部 */
  left: 0;
  /* 距离左边为0，即固定在左边 */
  width: 100%;
  /* 边界线宽度为100%，与父元素宽度一致 */
  height: 1px;
  /* 边界线高度为1px */
  background-color: #c72323;
  /* 边界线颜色 */
}

.fixed-table {
  position: absolute;
  /* 设置表格为绝对定位 */
  top: 100px;
  /* 距离上方的距离，根据需要进行调整 */
  left: 0;
  /* 距离左边为0，即固定在左边 */
  /* 表格宽度为100%，与父元素宽度一致 */
  table-layout: fixed;
  /* 使用固定布局，使表格列宽度固定 */
  /* 其他样式设置 */
  margin-left: 5%;
}

.fixed-table th:first-child,
.fixed-table td:first-child {
  width: 100px;
  /* 调整名称列的宽度 */
}

.fixed-table th:nth-child(2),
.fixed-table td:nth-child(2) {
  width: 40px;
  /* 调整名称列的宽度 */
}

.fixed-table th:nth-child(3),
.fixed-table td:nth-child(3) {
  width: 40px;
  /* 调整名称列的宽度 */
}

.fixed-table th:nth-child(4),
.fixed-table td:nth-child(4) {
  width: 40px;
  /* 调整名称列的宽度 */
}

.fixed-table th:nth-child(5),
.fixed-table td:nth-child(5) {
  width: 80px;
  /* 调整名称列的宽度 */
}

.fixed-table th:last-child,
.fixed-table td:last-child {
  width: 100px;
  /* 调整最早入库时间列的宽度 */
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  /* 设置为100% */
  height: 100vh;
  /* 设置为100vh */
  background-color: rgba(0, 0, 0, 0.5);
  /* 半透明黑色遮罩层 */
  z-index: 9999;
  /* 确保弹窗在最上层显示 */
  display: flex;
  align-items: center;
  justify-content: center;
}

.overlay-record {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  /* 设置为100% */
  height: 100vh;
  /* 设置为100vh */
  background-color: rgba(0, 0, 0, 0.5);
  /* 半透明黑色遮罩层 */
  z-index: 10000;
  /* 确保弹窗在最上层显示 */
  display: flex;
  align-items: center;
  justify-content: center;
}

.fixed-table-detail {
  top: 100px;
  /* 距离上方的距离，根据需要进行调整 */
  left: 0;
  /* 距离左边为0，即固定在左边 */
  /* 表格宽度为100%，与父元素宽度一致 */
  table-layout: fixed;
  /* 使用固定布局，使表格列宽度固定 */
  /* 其他样式设置 */
  margin-left: 10%;
}

.fixed-table-detail th:first-child,
.fixed-table-detail td:first-child {
  width: 100px;
  /* 调整名称列的宽度 */
}

.fixed-table-detail th:nth-child(2),
.fixed-table-detail td:nth-child(2) {
  width: 50px;
  /* 调整名称列的宽度 */
}

.fixed-table-detail th:nth-child(3),
.fixed-table-detail td:nth-child(3) {
  width: 60px;
  /* 调整名称列的宽度 */
}

.fixed-table-detail th:nth-child(4),
.fixed-table-detail td:nth-child(4) {
  width: 80px;
  /* 调整名称列的宽度 */
}

.fixed-table-detail th:nth-child(5),
.fixed-table-detail td:nth-child(5) {
  width: 80px;
  /* 调整名称列的宽度 */
}

.fixed-table-detail th:last-child,
.fixed-table-detail td:last-child {
  width: 200px;
  /* 调整最早入库时间列的宽度 */
}

.modal-content {
  /* 设置弹窗的样式，使其在屏幕中央显示，宽度为 400px */
  width: 800px;
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.close-button {
  margin-top: 20px;
  margin-left: 30px
}


table {
  width: 80%;
  border-collapse: collapse;
  border: 1px solid #ccc;
}

th,
td {
  border: 1px solid #ccc;
  padding: 8px;
  text-align: center;
}

.fileter-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  /* 设置容器高度为视窗的高度 */
  width: 75%;
  overflow-y: auto;

}

.top-section-warehouse {
  margin-top: 10%;
  flex: 25%;
  /* 上面占 30% 的空间 */
  background-color: white;
  padding: 20px;
  height: 100%;
}

.bottom-section-warehouse {
  flex: 70%;
  /* 下面占 70% 的空间 */
  height: 100%;
  background-color: white;
  padding: 20px;
  overflow: auto;
  /* 添加此行以实现滚动条 */
  margin-bottom: 5%;
}

.table-filter {
  width: 100%;
  border-collapse: collapse;
  border: 1px solid #ccc;
}

.closeRecordPopup {
  width: 100%;
  border-collapse: collapse;
  border: 1px solid #ccc;
}

th,
td {
  border: 1px solid #ccc;
  padding: 8px;
  text-align: center;
}

.row {
  display: flex;
  flex-wrap: wrap;
  margin-bottom: 20px;
  width: 1000px;
  /* 调整行之间的间距 */
}

.table-filter th:first-child,
.table-filter td:first-child {
  width: 80px;
  /* 调整名称列的宽度 */
}

.table-filter th:nth-child(2),
.table-filter td:nth-child(2) {
  width: 100px;
  /* 调整名称列的宽度 */
}

.table-filter th:nth-child(3),
.table-filter td:nth-child(3) {
  width: 80px;
  /* 调整名称列的宽度 */
}

.table-filter th:nth-child(4),
.table-filter td:nth-child(4) {
  width: 37px;
  /* 调整名称列的宽度 */
}

.table-filter th:nth-child(5),
.table-filter td:nth-child(5) {
  width: 37px;
  /* 调整名称列的宽度 */
}

.table-filter th:nth-child(6),
.table-filter td:nth-child(6) {
  width: 50px;
  /* 调整名称列的宽度 */
}

.table-filter th:nth-child(7),
.table-filter td:nth-child(7) {
  width: 50px;
  /* 调整名称列的宽度 */
}

.table-filter th:nth-child(9),
.table-filter td:nth-child(9) {
  width: 50px;
  /* 调整名称列的宽度 */
}

.table-filter th:nth-child(10),
.table-filter td:nth-child(10) {
  width: 50px;
  /* 调整名称列的宽度 */
}

.table-filter th:nth-child(11),
.table-filter td:nth-child(11) {
  width: 150px;
  /* 调整名称列的宽度 */
}

.table-filter th:nth-child(12),
.table-filter td:nth-child(12) {
  width: 50px;
  /* 调整名称列的宽度 */
}

.fixed-table th:last-child,
.fixed-table td:last-child {
  width: 100px;
  /* 调整最早入库时间列的宽度 */
}

.column {
  flex: 1;
  margin-right: 150px;
  /* 调整列之间的间距 */
}

.dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
}

.dialog {
  background-color: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
}

select,
input {
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
  margin-bottom: 10px;
}

.closeButton {
  margin-left: 750px;
}

.title-high {
  width: 200px
}

.fileterTitle {
  display: flex;
  /* 使用 Flexbox 布局 */
  align-items: center;
  /* 垂直居中 */
}

.custom-select {
  width: 100px;
  /* 设置你想要的固定宽度 */


}

button {
  padding: 5px 10px;
  border: none;
  background-color: #007bff;
  color: white;
  border-radius: 3px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

.title-row {
  display: flex;
  align-items: center;
  width: 100%
    /* 垂直居中标题和关闭按钮 */
}

.close-button {

  padding: 5px 10px;
  border: none;
  background-color: #ffffff;
  color: white;
  border-radius: 3px;
  cursor: pointer;
}

.title-detail {
  margin-left: 15%;
}

.small-button {
  width: 50px;
  height: 25px
}

.order-icon {
  width: 10px;
  height: 10px;
  cursor: pointer;
  /* 可选：添加光标样式以指示按钮是可点击的 */
}

.button {
  background-color: rgb(28, 28, 175);
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  transition: background-color 0.3s, color 0.3s;
}

.button:hover {
  background-color: white;
  color: blue;
}

.button[disabled] {
  background-color: #ccc;
  /* 灰色背景 */
  color: #999;
  /* 灰色文字颜色 */
  cursor: not-allowed;
  width: 15px;
  height: 10px;
  /* 禁用鼠标指针 */
}

.title-close {
  text-align: center;
  /* 水平居中 */
}

.white-button {
  background-color: white;
  color: black;
  border: 0.1px solid black;
  /* 添加边框，根据需要调整边框样式 */
  padding: 5px 10px;
  /* 调整按钮内边距，根据需要调整大小 */
  border-radius: 5px;
  /* 圆角边框，根据需要调整圆角程度 */
  cursor: pointer;
  /* 鼠标指针样式 */
  text-align: center;
  text-decoration: none;
  display: inline-block;
  margin-right: 10px;
  transition: background-color 0.3s, color 0.3s;
  /* 添加过渡效果 */
}

.white-button:hover {
  background-color: black;
  color: white;
}
</style>
