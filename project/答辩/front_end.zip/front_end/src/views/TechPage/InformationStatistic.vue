<template>
  <div id="statistic page">
    <el-row>
      <el-col :span="10" :offset="3">
        <el-card class="box-card">
          <template #header>
            <div class="card-header" style="height: 32px">
              <span>农场分布热力图</span>
            </div>        
          </template>
          <div style="height: 220px">
            <span>
              <div class="content">
                <div ref="charts" style="width: 100%; height: 320%"></div>
              </div>
            </span>
          </div>
        </el-card>
      </el-col>
      <el-col :span="10">
        <el-card class="box-card">
          <template #header>
            <div class="card-header" style="height: 32px">
              <span>保质期预警榜</span>
            </div>
          </template>
          <div style="height: 220px" >
            <span>
              <div id="chart" style="width: 100%; height: 110%">
                <Rank></Rank>
              </div>
            </span>
          </div>
        </el-card>   
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="10" :offset="3">
        <el-card class="box-card">
          <template #header>
            <div class="card-header" style="height: 32px">
              <span>收获统计图</span>

            </div>
          </template>
          <div style="height: 220px">
            <span>
              <div>
                <div id="chart1" style="width: 100%; height: 330%;">
                  <Bill></Bill>
                </div>
              </div>
            </span>
          </div>
        </el-card>
      </el-col>
      <el-col :span="10">
        <el-card class="box-card">
          <template #header>
            <div class="card-header" style="height: 32px">
              <span>商品销量饼状图</span>
            </div>
          </template>
          <div style="height: 220px">
            <span>
              <div class="content">
                <div ref="charts1" style="width: 100%; height: 240%">
                </div>
              </div>

            </span>
          </div>
        </el-card>   
      </el-col>
    </el-row>
  </div>
</template>

<script>
// https://www.ciciai.com/chat/1349536233476
import axios from 'axios'; // 导入axios
import * as echarts from "echarts";
import zhongguo from "@/assets/china.json"
import { Count_Provinces,Product_Rank,Bill_Service,Product_Quality} from "@/api/InformationStatistic.js";
import { reactive,watch,ref } from 'vue';
var img = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMYAAADGCAYAAACJm/9dAAABS2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxMzggNzkuMTU5ODI0LCAyMDE2LzA5LzE0LTAxOjA5OjAxICAgICAgICAiPgogPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIi8+CiA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgo8P3hwYWNrZXQgZW5kPSJyIj8+IEmuOgAAE/9JREFUeJztnXmQVeWZxn/dIA2UgsriGmNNrEQNTqSio0IEFXeFkqi4kpngEhXjqMm4MIldkrE1bnGIMmPcUkOiIi6gJIragLKI0Songo5ZJlHGFTADaoRuhZ4/nnPmnO4+l+7bfc85d3l+VV18373n3Ptyvve53/5+da1L6jDdYjgwBhgNHALMBn6Sq0VdcxlwGvACsAx4HliTq0VlRlNzY+LrfTO2o5LoDxwOHAmMA/4WiP+KzM3DqCJpAA4K/i4F2oBXgWbgWWAxsDEv48oZC6M9Q4EJwInAMcDAfM0pOXXA14K/y4FPgQXAfOBxYF1+ppUXFgYMBiYCp6PaoU+B694HFqEmyVJgVSbW9Y6bgCeBb6Am4GHALrH3B6L/+0RgM6pFHgQeAzZkaWi5UVejfYx64AjgXOAk1OToSCtqajyFHGZlVsalzH7oB+BYJJR+Cde0oKbi3cBCYEtWxmVNoT5GrQljGHAecD7wxYT3P0bNirlIEB9lZ1ouDEICOQk1H7dLuOYt4C7gZ8Da7EzLhloXxv7AJcCZdK4dWpAIHkDt7FrtjA5A/aszkFiSntP9wAzgP7M1LT0KCaM+YzuyZixy+leAb9O+sN9AHdDd0S/mbGpXFKD/+2z0LHZHz+aN2PsN6Bm+gjrsY7M2MEuqVRhHoU7yYjS6FPI5MAc4FNgHzUN4JKYz69Cz2Qc9qzno2YUcjZ7t8iBddVSbMEYDzwFPA6Nir28Afgx8CZiERpVM91iKntnfoGcYH606BNUez6GRr6qhWoSxF/AoKsQxsdfXAj9AHe2rgNXZm1Y1/A96hl8E/pn2HfExwBJUBntlb1rpqXRhbA/cDLyGxuJDPgSuBPYErqPGx+RLzAagCT3bK9GzDpmIyuJmVDYVS6UKow74e+APwPeIxuI/AX6Emkw3opldkw6fome8F3rmnwSv90Nl8gdURhU57FmJwtgHdfx+jpZwgCag7gW+DFyDa4gsWY+e+ZdRGYSTgUNRGS1GZVZRVJIwtgF+iMbQ4/2IF4ADgHOA93Kwy4j3UBkcgMokZAwqsx+iMqwIKkUYI4AXgelEzab1wAVoNOSVnOwynXkFlckFqIxAZTYdleGInOwqinIXRh1wMfASMDL2+hxgb+BOqngdTwWzBZXN3qisQkaisryYMu97lLMwhgHzgJ+ivRGgIcJJwd8HOdllus8HROUVDu/2R2U6D5VxWVKuwjgEVcnjY689jqrhOYl3mHJmDiq7x2OvjUdlfEguFnVBOQrju2gmdbcgvwmYitbweFtm5bIGleFUVKagMn4OlXlZUU7C6A/MQqs3w9GLN4ADgZloW6apbNpQWR5ItEBxG1Tms4iazLlTLsLYCW2IOTv22iNor3Il7JQzxbEKle0jsdfORj6wUy4WdaAchDEC+A1RW3MzcAVwKtW/UaiW+QiV8RWozEE+8Bu0yzBX8hbGwaiNuUeQ/xi1Q2/CTadaoA2V9Umo7EG+8Dw57/fIUxhHAs8AOwb5t9Cy8fm5WWTyYj4q+7eC/PZoOfspeRmUlzBOBn4FbBvkX0XVaLUEHDDFsxL5wG+DfAOKWHJOHsbkIYwpaAtluLRjEdol5nVO5j20tmpRkO+DAjFclLUhWQvjUhSSJYzdNA84DneyTcRHyCfmBfk64HYUbjQzshTGVOBWojUys9GoREuGNpjKoAX5xuwgXwfcQoY1R1bCmILWx4SimAWcBXyW0febyuMz5COzgnxYc0zJ4suzEMZEFKwrFMVDKAzL5oJ3GCM2I195KMjXIV86Ke0vTlsYR6CRhbBPMReYjEVhus9mNCseRpfvg5pYR6T5pWkKYz8UNSIcfVqIzmpoTfE7TXXyGfKdhUG+H/Kt1GbI0xLGMODXKJI4aIz6m1gUpue0Ih8Kw4MORj6Wyp6ONITRADyBwjyC4hEdjwMUmN6zAUU+fDPI7458LSlafa9IQxh3oZWToP/ICcDbKXyPqU3WouDT4Q/tQcjnSkqphXEJ6lyDOk2T8TIPU3pW0n4QZzLyvZJRSmGMQislQ65C1ZwxafAEioQYchPt4xX3ilIJYygaaw5HoB5BM5XGpMmtwMNBuh/ywaGFL+8+pRBGHYpAF+7R/h2anfR+CpM2bWj1bbhNdjfki70OzVMKYVxEFM1jE955Z7Il3AkYHvoznhKsqeqtML6KIluHfB93tk32rEK+F3Iz8s0e0xth9EXVVhjZ4QkUAcKYPPg3orhV/YH76MVx3b0RxhXA3wXpdehoYPcrTF60oRN5w6PjDkQ+2iN6Kox9UOj3kAtxMDSTP2uQL4ZcA+zbkw/qiTDqULUVTsM/RDRkZkzePEy0TL0B+WrRo1Q9Eca3iEKbrKfEM47GlIBLgP8N0mPQyU5FUawwdqDz7Lajjpty4wPg6lj+RqIwTd2iWGE0Ei3zXUEKi7eMKRF3IR8F+ew1W7m2E8UI4ytEEydbUIRqH9piypWOPnoR8uFuUYwwbiKKQj4LeLmIe43Jg5eJgilsQ/tuwFbprjBGEy37+IT27TdjypmriY5aHo/OB+yS7grjulj6JzhqoKkc3gNui+X/pTs3dUcYRxMNz/4FLyc3lcfNyHdBvnxMVzd0RxiNsfQNeO+2qTw2IN8N6XKEqithjCXaFbUWuKNndhmTOzOJ1lGNoovzN7oSxrRY+jbg057bZUyu/BX1j0OmFboQti6Mkah/AVr64SXlptKZiXwZ5NsjC124NWFcGkvfHftAYyqV9bRfrXFpoQvrWpckLjwcigKl9Qc+B74ErC6hgcbkxR7Af6NNTK3Abk3Njes6XlSoxvgO0c68R7EoTPWwGvk0KLLIBUkXJQmjHu3GC5lRWruMyZ24T58zbdy1nXSQJIxxwJ5B+nVgWentMiZXliHfBvn6kR0vSBJG/JTMu0tvkzFlQdy3O53S1LHzPRht8mhA56DtTjQpYkw1MQR4h8jXd25qbvz/kdeONcZEor3cT2FRmOrlQ3S+Bsjn2x1f1lEYZ8TSD6RolDHlwP2x9JnxN+JNqWHAu2h892NgZ7wExFQ3A4H3ge3QkQK7NjU3roH2NcaJRJHb5mNRmOrnU+TroEMvw8147YQxIZaeizG1QdzXTwwTYVNqAOpoD0Q99GGoOWVMtTMIRTBsQBHThzQ1N24Ma4zDkCgAFmNRmBqhqbnxI+C5IDsAOByiplR85m9BhnYZUw48FUsfCcnCeCYzc4wpD+I+Pw7UxxiOhqzq0HDtbgk3GlOVNDUrpMG0cde+A+yKjhPYuR7F2QknM57PxTpj8ifsZ9QBh9ajYGohS7O3x5iyIL6KfFQ9cHDsBQvD1Cpx3z+4LzAHnV3Whg75M6YWWQVciZpSrYX2fBtTE4Sd746U4pxvY6oOC8OYBCwMYxKwMIxJwMIwJgELw5gELAxjErAwjEnAwjAmAQvDmAQsDGMSsDCMScDCMCYBC8OYBCwMYxKwMIxJwMIwJgELw5gELAxjErAwjEnAwjAmAQvDmAQsDGMSsDCMScDCMCYBC8OYBCwMYxKwMIxJwMIwJgELw5gELAxjErAwjEnAwjAmAQvDmAQsDGMSsDCMScDCMCYBC8OYBCwMYxLoC1wKNABtwC3A5lwtMiYHpo27tg/wPaAOaO0LnAqMCt5fAPw2J9uMyZMRwI+D9PJ6YEXszW9kb48xZUHc91fUA8sKvGlMLTE6ll5eDyxF/QuAMdnbY0xZMDb4tw1YUg+sAVYGL+6K2lrG1AzTxl07Avk+wMqm5sY14XBtc+y6o7I1y5jcift8M0TzGM/E3jgmM3OMKQ+OjaWfBahrXVIHMABYBwwEWoBhwMdZW2dMDgxC3YkGYCMwpKm5cWNYY2wEng7SDcBx2dtnTC4ci3weYEFTc+NGaL8k5IlY+qSsrDImZ+K+/qsw0VEYnwfpE1GzyphqZgDyddBSqMfDN+LCWAssCtLbAeMzMc2Y/DgB+TrAwqbmxjXhGx1X194fS5+WtlXG5MyZsfQD8Tc6CmMuGpUCOB4YkqJRxuTJEOTjIJ9/LP5mR2GsR+IA9dS/lappxuTHZKLRqLlNzY3r428mbVS6N5Y+Ny2rjMmZuG/f2/HNJGE8C7wZpPel/apDY6qB0cBXg/SbBLPdcZKEsQW4J5a/pORmGZMvcZ++p6m5cUvHCwrt+f53ok74N4E9SmyYMXmxB/JpgFbk650oJIx1wOwg3Rf4bklNMyY/LkY+DfBgU3PjuqSLthYl5LZY+lxg+xIZZkxeDAbOi+VvK3Th1oTxCtHCwu2BC3tvlzG5chHRD/wzyMcT6SquVFMsfRleP2Uql4HIh0Ou39rFXQnjOWB5kB4GTO25XcbkylTkwyCfXrSVa7sViXB6LH0VaqcZU0kMRr4b8qOubuiOMBagmgNgR+Dy4u0yJle+j3wX5MtPdXVDd2PX/iCWvhzYpTi7jMmNXVAY2pAfFLowTneFsZRoh9+2dNFxMaaMuB75LMiHl3bnpmKinf8T8FmQngwcUMS9xuTBAchXQb57RXdvLEYYvwNmxu77aZH3G5MlHX10JvBGMTcXw3S0BRbgYNrPIhpTTpyHfBS0xGn6Vq7tRLHC+AtqUoVcD+xU5GcYkzbDad8PvgL5brfpSVPoP4iGb3cA/rUHn2FMmsxAvgnwPPDzYj+gJ8JoQ+umwmXppwGn9OBzjEmDU4gCebQgX20rfHkyPe08/xft22wzUfVlTJ4MB+6I5acDr/fkg3ozqnQj8FKQHgbchc4vMyYP6pAPhj/QLyMf7RG9EcbnwLeBTUF+Al6abvLjQuSDoCbUPxBF1iya3s5DvEb7SZNbgP16+ZnGFMsI4OZY/irkmz2mFBN0twPzg3R/YA4KrW5MFgxCPjcgyD9JCUZKSyGMNmAK8E6Q/wqK0+P+hkmbOhTRZu8g/w5qQhU9CtWRUi3pWIuGyFqD/MnoMHFj0uRyoqmCVuSDawpf3n1KudZpGe1nxW/AEdNNeownOrAe5HvLClxbNKVeBDgD+EWQ7gPMwp1xU3r2Q77VJ8j/AvleyUhjdex5wItBejA6pWb3FL7H1CbD0AEv4RbrF0lhMWsawtiExpPfDvJfAH6N94qb3jMYhXTaM8i/jXxtU6Ebekpa+ynWoLMHNgT5/YBHgX4pfZ+pfvohH9o/yG9APlaSznZH0txotBLFCA1Hqo5AYT8tDlMs2yDfOSLItyLfWpnWF6a9A28hcBY6+A90Qma802RMV/RBnevwdNXN6IiwhWl+aRZbUx8GvkM06TIJuA+Lw3RNH+Qrk4J8G3A+8EjaX5zVnu170JkEoTgmA79EVaQxSWyDaoowmEEb8qFOpx+lQZbBDG5HM5WhOE4DHsJ9DtOZfsg3Tg/ybSho2u1ZGZB1lI/bUFUY73M8hRcdmohBaCFg2KdoQ+ez3JqlEXmEv7mb9uuqDkd7yB3d0OyMfCEcfdqMfkjvKHhHSuQVF+oR4ETgr0F+fxSB2stHapcRwAtE8xQtwBnohzRz8gyY9gxwJFFYkz3RIrAT8jLI5MYJ6IdxzyC/HjgO7bPIhbwjCa4ADgNWB/ntgHlopaT3c1Q/dahTPQ+VPcgXxtLF+RVpk7cwQLOXB6FqFDR2fSPeCVjthDvvbiKa01qBfOHVvIwKKQdhALyPOly/jL12Mlo5OSIXi0yajEBle3LstfvRQMz7uVjUgXIRBmiF5NnAPxJFVd8bhei5CDetqoE6VJYvEW1H/QyV+VmksEq2p5STMEJmoF+OcA95fzRcNxcHdatkhqMyvAOVKaiMD6PEm4xKQTkKAzQ6NRJtcgqZgPojp+ZikekNp6CymxB7bT4q4+WJd+RMuQoDFGBhPKpmwyp2OFoqMBtHWa8EhgMPok52WNtvQjPZE4iOlCg7ylkYoOUAM4ADaX9Y+SQUP/d8yv//UIvUo7J5gyjAMqgMD0Rrnnod4iZNKsWpVqFhvEaipSQ7AHcCS1CVbMqDkahM7iQKxd+Kyu4gVJZlT6UIAzR6MZ3owYeMQgF878HrrfJkF1QGL6MyCQl/uKYTjTaWPZUkjJDX0czoFHSEFOj/MQX4PXAtDryQJYPRM/89KoPQp9YF+bH0MBR/nlSiMEDt0/vQWPhMoqjW2wLXAH9Ey0oG5mJdbTAQPeM/omceHhn8OSqTfVAZlXVfohCVKoyQD4GpwNdQiJ6QoWhZyZ+BaXhpSSkZhJ7pn9EzHhp770lUFlOJavOKpNKFEfI6WqF5KO37H8OB69DCtBtQjCvTM76ADnxcjZ5pfLJ1CXr2x1OBzaYkqkUYIUuBMcAxRIsSQe3gK4E/oTmQ0dmbVrGMRs/sT+jciXj/bQVwLHrmS7M3LT2qTRghT6ORkcODdEhfNAeyFB0schmwY+bWlT9D0LN5DT2rSejZhTyNnu0hwILMrcuAahVGyGJUe3wdHWnbEntvX7SP+F3gMbTUZAC1ywAkgMfQGqZb0TMKaUHP8OvomS7O1rxsqWtdUlOLVoejGdnzgD0S3v8IreGZi4I0fJydabmwHWoKTUR9tKRBitXo0MefkVI4zDxpam5MfL3WhBFSj/Z/nI/W7DQkXNOCdpE9jbbhVsSMbTcYARwFHI2aQ4X+748jQTQDWzKzLmMKCaNv4qvVzxbg2eBve/SLeTowjmg3WQP6NT02yL+Lmg/Lgr9VRGGAypU+SAijg7/DgF0LXLsZiWA2Cp68PgP7ypZarTEKMQzVIOPRr+rWJgivRkPA5cxVaIi1EJ+i2vAJVEOU7WrXtHCN0T3WovU+96DO6OEoksk4FNqn0n9F2tC+iGZUWy4CNuZqUZliYRRmI5pND2fUd0JDwKPRMGVLgfvKiRa0EegF1PxbDnyQq0UVwv8BNYmwIpIWBvwAAAAASUVORK5CYII=';

const newData =[]; 
/*let newData = */
let geoCoordMap = {
    '台湾': [121.5135,25.0308,0],
    '黑龙江': [127.9688, 45.368,0],
    '内蒙古': [110.3467, 41.4899,0],
    "吉林": [125.8154, 44.2584,0],
    '北京市': [116.4551, 40.2539,0],
    "辽宁": [123.1238, 42.1216,0],
    "河北": [114.4995, 38.1006,0],
    "天津": [117.4219, 39.4189,0],
    "山西": [112.3352, 37.9413,0],
    "陕西": [109.1162, 34.2004,0],
    "甘肃": [103.5901, 36.3043,0],
    "宁夏": [106.3586, 38.1775,0],
    "青海": [101.4038, 36.8207,0],
    "新疆": [87.9236, 43.5883,0],
    "西藏": [91.11, 29.97,0],
    "四川": [103.9526, 30.7617,0],
    "重庆": [108.384366, 30.439702,0],
    "山东": [117.1582, 36.8701,0],
    "河南": [113.4668, 34.6234,0],
    "江苏": [118.8062, 31.9208,0],
    "安徽": [117.29, 32.0581,0],
    "湖北": [114.3896, 30.6628,0],
    "浙江": [119.5313, 29.8773,0],
    "福建": [119.4543, 25.9222,0],
    "江西": [116.0046, 28.6633,0],
    "湖南": [113.0823, 28.2568,0],
    "贵州": [106.6992, 26.7682,0],
    "云南": [102.9199, 25.4663,0],
    "广东": [113.12244, 23.009505,0],
    "广西": [108.479, 23.1152,0],
    "海南": [110.3893, 19.8516,0],
    '上海': [121.4648, 31.2891,0],
    };
var charts = {
    cityList: [],
    cityData: []
  };

var xData = []


var data1 = [];
var data2 = [];
var data3 = [];
//const data3 = data1.map((value, index) => value + data2[index] );
const cropQuality = [
        { name: '特级', value: 20 },
        { name: '一级', value: 30 },
        { name: '二级', value: 50 }
      ];



try {
    let params = {
      mode: 1,
    };
    await Bill_Service (params).then(function (res) {
      var backendData= res.data;
      console.log(backendData);
      //xData=[];
      //backendData.reverse();
      data1=[];
      data2=[];
      data3=[];
      xData=[];
      for (const item of backendData)
      {
        
        data2.push((item.countservice+8)*5);
        data3.push((item.countbill+8)*5);
        data1.push((item.countbill-item.countservice)*5);
        xData.push(item.date.substring(5,10));
        //const a=item.countservice;
        //a.push(item.countservice);
        //charts.cityList.push(item.name);
        //charts.cityData.push(item.count);
        //console.log(a);
      }

      console.log(xData);
      console.log(data1);
      //newData=data;
      
    });
} catch (error) {
    console.error(error);
}

try {
    let params = {
      mode: 3,
    };
    await Product_Quality (params).then(function (res) {
      var backendData= res.data;
      console.log(backendData);
      //const a=backendData[0][2].count;
      //console.log(a);
     
      cropQuality[0].value=backendData[9][2].count*2;
      cropQuality[1].value=backendData[9][0].count;  
      cropQuality[2].value=backendData[9][1].count;  
      
    });
} catch (error) {
    console.error(error);
}



export const Bill= {
  mounted() {
    this.renderChart();
  },
  methods: {
    renderChart() {

      const option = {
        backgroundColor: "#0A2E5D",
        title: {
          
          x: "4%",
          textStyle: {
            color: '#fff',
            fontSize: '22'
          },
          subtextStyle: {
            color: '#90979c',
            fontSize: '16',
          },
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow",
            textStyle: {
              color: "#fff",
              fontSize:10
            },
            extraCssText: 'width: 200px; height: 100px;' // 调整 tooltip 的大小
          },
        },
        grid: {
          borderWidth: 0,
          top: 65,
          bottom: 120,
          textStyle: {
            color: "#fff"
          }
        },
        legend: {
          x: '4%',
          top: '5%',
          textStyle: {
            color: '#90979c',
          },
          data: ['一级与二级的质量', '特级的质量',  '收获总质量']
        },
        calculable: true,
        xAxis: [{
          type: "category",
          axisLine: {
            lineStyle: {
              color: '#90979c'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          splitArea: {
            show: false
          },
          axisLabel: {
            interval: 0,
          },
          data: xData,
        }],
        yAxis: [{
          type: "value",
          splitLine: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: '#90979c'
            }
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            interval: 0,
          },
          splitArea: {
            show: false
          },
        }],
        dataZoom: [{
          show: true,
          height: 30,
          xAxisIndex: [
            0
          ],
          bottom: 30,
          start: 40,
          end: 100,
          handleIcon: 'path://M306.1,413c0,2.2-1.8,4-4,4h-59.8c-2.2,0-4-1.8-4-4V200.8c0-2.2,1.8-4,4-4h59.8c2.2,0,4,1.8,4,4V413z',
          handleSize: '110%',
          handleStyle: {
            color: "#d3dee5",
          },
          textStyle: {
            color: "#fff"
          },
          borderColor: "#90979c"
        }, {
          type: "inside",
          show: true,
          height: 15,
          start: 1,
          end: 35
        }],
        series: [{
          name: "一级与二级的质量",
          type: "bar",
          stack: "总量",
          barMaxWidth: 35,
          barGap: "10%",
          itemStyle: {
            normal: {
              color: "rgba(255,144,128,1)",
              label: {
                show: true,
                textStyle: {
                  color: "#fff"
                },
                position: "inside",
                formatter: function(p) {
                  return p.value > 0 ? (p.value) : '';
                }
              }
            }
          },
          data: data1,
        }, {
          name: "特级的质量",
          type: "bar",
          stack: "总量",
          itemStyle: {
            normal: {
              color: "rgba(0,191,183,1)",
              barBorderRadius: 0,
              label: {
                show: true,
                position: "inside",
                formatter: function(p) {
                  return p.value > 0 ? (p.value) : '';
                }
              }
            }
          },
          data: data2
        }, {
          name: "收获总质量",
          type: "line",
          symbolSize: 10,
          symbol: 'circle',
          itemStyle: {
            normal: {
              color: "rgba(252,230,48,1)",
              barBorderRadius: 0,
              label: {
                show: true,
                position: "top",
                formatter: function(p) {
                  return p.value > 0 ? (p.value) : '';
                }
              }
            }
          },
          data: data3
        }]
      };

      const chart = echarts.init(document.getElementById('chart1'));
      chart.setOption(option);
    }
  }
};
try {
    let params = {
      mode: 3,
    };
    await Product_Rank (params).then(function (res) {
      const backendData= res.data;
      console.log(backendData);
      for (const item of backendData[9])
      {
        //const a=item.name;
        charts.cityList.push(item.name);
        charts.cityData.push(item.count);
        //console.log(a);
      }
      
      console.log(charts);
      //newData=data;
      
    });
} catch (error) {
    console.error(error);
}



export const Rank= {
  mounted() {
    this.renderChart1();
  },
  methods: {
    renderChart1() {
      
      var top10CityList = charts.cityList;
      var top10CityData = charts.cityData;
      var color = ['rgba(248,195,248', 'rgba(100,255,249', 'rgba(135,183,255', 'rgba(248,195,248', 'rgba(100,255,249', 'rgba(135,183,255', 'rgba(248,195,248', 'rgba(100,255,249', 'rgba(135,183,255','rgba(248,195,248'];

      let lineY = [];
      for (var i = 0; i < charts.cityList.length; i++) {
        var x = i;
        if (x > color.length - 1) {
          x = color.length - 1;
        }
        var data = {
          name: charts.cityList[i],
          color: color[x] + ')',
          value: top10CityData[i],
          itemStyle: {
            normal: {
              show: true,
              color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
                offset: 0,
                color: color[x] + ', 0.3)'
              }, {
                offset: 1,
                color: color[x] + ', 1)'
              }], false),
              barBorderRadius: 10
            },
            emphasis: {
              shadowBlur: 15,
              shadowColor: 'rgba(0, 0, 0, 0.1)'
            }
          }
        };
        lineY.push(data);
      }

      const option = {
        backgroundColor: '#0A2E5D',
        title: {
          show: false
        },
        tooltip: {
          trigger: 'item'
        },
        grid: {
          borderWidth: 0,
          top: '3%',
          left: '20%',
          right: '15%',
          bottom: '3%'
        },
        color: color,
        yAxis: [{
          type: 'category',
          inverse: true,
          axisTick: {
            show: false
          },
          axisLine: {
            show: false
          },
          axisLabel: {
            show: false,
            inside: false
          },
          data: top10CityList
        }, {
          type: 'category',
          inverse:true,
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            show: true,
            inside: false,
            textStyle: {
              color: '#b3ccf8',
              fontSize: '14',
              fontFamily: 'PingFangSC-Regular'
            },
            formatter: function (val) {
              return `${val}千克`;
            }
          },
          splitArea: {
            show: false
          },
          splitLine: {
            show: false
          },
          data: top10CityData
        }],
        xAxis: {
          type: 'value',
          axisTick: {
            show: false
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            show: false
          }
        },
        series: [{
          name: '',
          type: 'bar',
          zlevel: 2,
          barWidth: '10px',
          data: lineY,
          animationDuration: 1500,
          label: {
            normal: {
              color: '#b3ccf8',
              show: true,
              position: ['-97px', '0px'],
              textStyle: {
                fontSize: 12
              },
              formatter: function (a, b) {
                return a.name;
              }
            }
          }
        }],
        animationEasing: 'cubicOut'
      };

      const chart = echarts.init(document.getElementById('chart'));
      chart.setOption(option);
    }
  }
};
    /*前端 */
/*let newData = [
    { "台湾": 20 },
    { "上海": 18 }
];*/
try {
    await Count_Provinces().then(function (res) {
      const backendData= res.data;
      console.log(backendData);
      //newData=data;
    
      for (const key in backendData) {
  if (Object.hasOwnProperty.call(backendData, key)) {
    
    newData.push({ [key]: backendData[key] });
    //break;
  }

}
console.log(newData);
    });
} catch (error) {
    console.error(error);
}

newData.forEach(function (item) {
    let name = Object.keys(item)[0];
    if (geoCoordMap.hasOwnProperty(name)) {
        geoCoordMap[name][2] = item[name];
    }
});
    var ha = Object.keys(geoCoordMap).filter(function (key) {
    return geoCoordMap[key][2] !== 0;
}).map(function (key) {
    return { name: key, value: geoCoordMap[key] };
});

export default {
  mounted() {
    this.renderChart();
  },
  created () {
    this.$nextTick(() => {
      this.initCharts();
    })
  },
  components: {
    Rank, Bill// 在组件中注册 Rank
  },
  methods: {
    initCharts() {
      const charts = echarts.init(this.$refs["charts"]);
      const option = {
        // 背景颜色
        backgroundColor: "#0A2E5D",
        visualMap: {
        // 是否展示左下角，即是是false，也仅是不显示，不影响数据的映射
        show: true,
        // 上下端文字
        text: ["农场数量", ""],
        // 最小值和最大值，必须指定
        min: 0,
        max: 5,
        // 位置
        left: "3%",
        bottom: "35%",
        // 是否展示滑块
        calculable: true,
        // 指定映射的数据，对应的是option.series，这里根据自己的实际需要进行配置
        seriesIndex: [0],
        // 从下到上的颜色
        inRange: {
            color: ['rgba(0,191,183,1)','rgba(252,230,48,1)'],
        },
        //字体颜色
        textStyle: {
            color: "#fff",
            map: "china",
        },},

        // 提示浮窗样式
        tooltip: {
          show: true,
          trigger: "item",
          alwaysShowContent: false,
          backgroundColor: "#0C121C",
          borderColor: "rgba(0, 0, 0, 0.16);",
          hideDelay: 100,
          triggerOn: "mousemove",
          enterable: true,
          formatter(params) {
            return `地区：${params.name}</br>数值：${params.value[2]}`;
          },
          textStyle: {
            color: "#DADADA",
            fontSize: "10",
            width: 5,
            height: 10,
            overflow: "break",
          },
          showDelay: 100
        },
        series: [
    
     {
       type: "effectScatter",
       coordinateSystem: "geo",
       effectType: "ripple",
       legendHoverLink: true,
       showEffectOn: "render",
       rippleEffect: {
         period: 10,
         scale: 10,
         brushType: "fill",
       },

       hoverAnimation: true,
       itemStyle: {
         normal: {
           color: "rgba(255, 235, 59, .7)",
           shadowBlur: 10,
           shadowColor: "#333",
         },
       },
       zlevel: 1,
       data: ha
       /*[
         { name: "西藏", value: [91.23, 29.5, 2333] },
         { name: "黑龙江", value: [128.03, 47.01, 1007] }]  */

       
     },
      ],

        // 地图配置
        geo: {
          map: "china",
          label: {
            // 通常状态下的样式
            normal: {
              show: true,
              textStyle: {
                color: "#fff",
                fontSize: "0",
              },
            },
            // 鼠标放上去的样式
            emphasis: {
              textStyle: {
                color: "#fff",
              },
            },
          },
          // 地图区域的样式设置
          itemStyle: {
            normal: {
              borderColor: "rgba(147, 235, 248, 1)",
              borderWidth: 1,
              areaColor: {
                type: "radial",
                x: 0.25,
                y: 0.25,
                r: 0.4,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(147, 235, 248, 0)", // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(147, 235, 248, .2)", // 100% 处的颜色
                  },
                ],
                globalCoord: false, // 缺省为 false
              },
              shadowColor: "rgba(128, 217, 248, 1)",
              shadowOffsetX: -1.5,
              shadowOffsetY: 1.5,
              shadowBlur: 7.5,
            },
            // 鼠标放上去高亮的样式
            emphasis: {
              areaColor: "#389BB7",
              borderWidth: 0,
            },
          },
        },
      };
      // 地图注册，第一个参数的名字必须和option.geo.map一致
      echarts.registerMap("china",zhongguo)

      charts.setOption(option);
    },
    renderChart() {
      //const chartDom = this.$refs.chart;
      //const myChart = echarts.init(chartDom);
      const myChart = echarts.init(this.$refs["charts1"]);

      
      const data = [];
      const color = ['#00ffff',  '#006ced', '#ffe000'];
      for (let i = 0; i < cropQuality.length; i++) {
        data.push(
          {
            value: cropQuality[i].value,
            name: cropQuality[i].name,
            itemStyle: {
              normal: {
                borderWidth: 5,
                shadowBlur: 20,
                borderColor: color[i],
                shadowColor: color[i]
              }
            }
          },
          {
            value: 2,
            name: '',
            itemStyle: {
              normal: {
                label: { show: false },
                labelLine: { show: false },
                color: 'rgba(0, 0, 0, 0)',
                borderColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 0
              }
            }
          }
        );
      }
      
      const seriesOption = [
        {
          name: '',
          type: 'pie',
          clockWise: false,
          radius: [75, 80],
          hoverAnimation: false,
          itemStyle: {
            normal: {
              label: {
                show: true,
                position: 'outside',
                color: '#ddd',
                formatter: params => {
                  let percent = 0;
                  let total = 0;
                  for (let i = 0; i < cropQuality.length; i++) {
                    total += cropQuality[i].value;
                  }
                  percent = ((params.value / total) * 100).toFixed(0);
                  if (params.name !== '') {
                    return `等级：${params.name}\n\n占比：${percent}%`;
                  } else {
                    return '';
                  }
                }
              },
              labelLine: {
                length: 24,
                length2: 60,
                show: true,
                color: '#00ffff'
              }
            }
          },
          data: data
        }
      ];
      
      const option = {
        backgroundColor: '#0A2E5D',
        color: color,
        title: {
          text: '商品销量',
          top: '45%',
          textAlign: 'center',
          left: '49%',
          textStyle: {
            color: '#fff',
            fontSize: 18,
            fontWeight: '400'
          }
        },
        graphic: {
          elements: [
            {
              type: 'image',
              z: 3,
              style: {
                image: img,
                width: 127,
                height: 127
              },
              left: 'center',
              top: 'center'
            }
          ]
        },
        tooltip: {
          show: false
        },
        legend: {
          icon: 'circle',
          orient: 'horizontal',
          data: ['特级', '一级', '二级'],
          right: 50,
          bottom: 200,
          align: 'right',
          textStyle: {
            color: '#fff'
          },
          itemGap: 20
        },
        toolbox: {
          show: false
        },
        series: seriesOption
      };

      myChart.setOption(option);
    }
  },


};

</script>

<style>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.box-card {
  margin-left: 20px;
  margin-bottom: 20px;
}
</style>