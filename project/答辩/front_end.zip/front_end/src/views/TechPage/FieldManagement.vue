<template>
  <div id="fieldpage" v-if="finish">
    <div>
      <el-row :gutter="10">
        <el-col :span="21" :offset="2">
          <el-card class="box-card">
            <div class="two-side">
              <span
                >农场：<el-select
                  v-model="select.name"
                  placeholder="请选择农场"
                  style="width: 300px"
                >
                  <el-option
                    v-for="item in farmoptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  /> </el-select
              ></span>
              <span
                ><el-button
                  class="button"
                  text
                  @click="
                    select.name = '';
                    select.crop = '';
                    select.soil = '';
                    select.state = '';
                    select.leftpH = '';
                    select.rightpH = '';
                  "
                  >重置选项卡</el-button
                ><el-button
                  class="button"
                  text
                  @click="
                    seniorFormVisible = true;
                    preload();
                  "
                  >筛选田地</el-button
                ></span
              >
            </div>
            <br />
            <div class="two-side">
              <span
                >状态：<el-select
                  v-model="select.state"
                  placeholder="请选择状态"
                  style="width: 300px"
                >
                  <el-option label="空闲" value="空闲" />
                  <el-option label="占用" value="占用" /> </el-select
              ></span>
              <span
                >作物：<el-select
                  v-model="select.crop"
                  placeholder="请选择作物"
                  style="width: 300px"
                >
                  <el-option
                    v-for="item in cropoptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  /> </el-select
              ></span>
            </div>
            <br />
            <div class="two-side">
              <span
                >土壤：<el-select
                  v-model="select.soil"
                  placeholder="请选择土壤类型"
                  style="width: 300px"
                >
                  <el-option label="红壤" value="红壤" />
                  <el-option label="棕壤" value="棕壤" />
                  <el-option label="褐土" value="褐土" />
                  <el-option label="黑土" value="黑土" />
                  <el-option label="栗钙土" value="栗钙土" />
                  <el-option label="漠土" value="漠土" />
                  <el-option label="潮土" value="潮土" />
                  <el-option label="湿土" value="湿土" />
                  <el-option label="水稻土" value="水稻土" />
                  <el-option label="盐碱土" value="盐碱土" />
                  <el-option label="岩性土" value="岩性土" />
                  <el-option label="高山土" value="高山土" /> </el-select
              ></span>
              <span
                >pH值：<el-input
                  v-model="select.leftpH"
                  autocomplete="off"
                  style="width: 145px" />~<el-input
                  v-model="select.rightpH"
                  autocomplete="off"
                  style="width: 145px"
              /></span>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
    <br />
    <div>
      <el-row :gutter="10">
        <el-col :span="21" :offset="2">
          <el-card class="box-card">
            <template #header>
              <div class="card-header">
                <div>
                  <span>{{ fieldinfo.name }}</span> <br />
                </div>
                <el-button class="button" text @click="soilFormVisible = true"
                  >编辑</el-button
                >

              </div>
            </template>
            <div class="two-side">
              <span>
                <el-icon>
                  <location-information />
                </el-icon>
                {{ fieldinfo.location }}
              </span>
              <span>土壤类型：{{ soilinfo.类型 }} </span>
              <span>土壤pH值：{{ soilinfo.pH值 }}</span>
            </div>
            <br />
            <div class="two-side">
              <div id="container"></div>
              <div>
                <el-image :src="soilinfo.photo" :fit="'fill'">
                  <template #error>
                    <div class="image-slot">
                      <el-icon><icon-picture /></el-icon>
                    </div>
                  </template>
                </el-image>
              </div>
            </div>
          </el-card>
          <div></div>
        </el-col>
      </el-row>
    </div>
    <br />
    <div>
      <el-col :span="21" :offset="2">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>农业事项</span>
              <div v-if="fieldinfo.planting_id != 0">
                <el-button
                  class="button"
                  text
                  @click="finishharvest()"
                  :disabled="store.token.identity != 1"
                  >完成收获</el-button
                >
                <el-button
                  class="button"
                  text
                  @click="harvestissueFormVisible = true"
                  :disabled="store.token.identity != 1"
                  >添加收获</el-button
                >
                <el-button
                  class="button"
                  text
                  @click="issueFormVisible = true"
                  :disabled="store.token.identity != 1"
                  >添加事项</el-button
                >
              </div>
              <div v-else>
                <el-button
                  class="button"
                  text
                  @click="
                    chooseFormVisible = true;
                    preloadS0();
                  "
                  :disabled="store.token.identity != 1"
                  >开始种植</el-button
                >
              </div>
            </div>
          </template>
          <el-scrollbar>
            <div class="card-container" v-if="fieldinfo.planting_id != 0">
              <el-card
                v-for="(item, index) in issueinfo"
                :key="item.index"
                class="innerbox"
              >
                <div>
                  {{ item.type }}
                </div>
                <div
                  :class="{
                    red: item.state === '待解决',
                    orange: item.state === '解决中',
                    green: item.state === '已解决',
                  }"
                >
                  {{ item.state }}
                </div>
                <div class="card-bottom-btn">
                  <el-button
                    id="card-btn"
                    :icon="Plus"
                    circle
                    size="small"
                    @click="handlecardbtn(index)"
                  />
                </div>
              </el-card>
            </div>
            <div class="center-text" v-else>暂无作物种植</div>
          </el-scrollbar>
        </el-card>
      </el-col>
    </div>
    <br />
    <div>
      <el-col :span="21" :offset="2">
        <el-card class="box-card" style="height: 400px">
          <template #header>
            <div class="card-header">
              <span
                ><img
                  v-if="weather.天气 == '多云'"
                  class="side-icon"
                  src="../../assets/duoyun.png"
                />
                <img
                  v-else-if="weather.天气 == '雷雨'"
                  class="side-icon"
                  src="../../assets/leiyu.png"
                />
                <img
                  v-else-if="weather.天气 == '晴天'"
                  class="side-icon"
                  src="../../assets/qingtian.png"
                />
                <img
                  v-else-if="weather.天气 == '小雨'"
                  class="side-icon"
                  src="../../assets/xiaoyu.png"
                />
                <img
                  v-else-if="weather.天气 == '大雨'"
                  class="side-icon"
                  src="../../assets/dayu.png"
                />
                <img v-else class="side-icon" src="../../assets/yintian.png" />
                {{ weather.天气 }}</span
              >
              <span
                ><img class="side-icon" src="../../assets/temp.png" />{{
                  weather.最低温
                }}℃ ~ {{ weather.最高温 }}℃</span
              >
              <span
                ><img class="side-icon" src="../../assets/humidity.png" />{{
                  weather.湿度
                }}%</span
              >
              <span
                ><img class="side-icon" src="../../assets/rain.png" />{{
                  weather.降雨量
                }}mm</span
              >
              <span
                ><img class="side-icon" src="../../assets/speed.png" />{{
                  weather.最大风速
                }}km/h</span
              >
              <span
                >
                <el-button class="button" text @click="goToBot.jumpToUrl"
                  >AI智能助手</el-button
                >
                </span
              >
              <el-select v-model="optionvalue" placeholder="Select">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </div>
          </template>
          <div>
            <el-carousel trigger="click">
              <el-carousel-item>
                <v-chart class="chart" :option="issueoption" autoresize />
              </el-carousel-item>
              <el-carousel-item>
                <v-chart class="chart" :option="tempoption" autoresize />
              </el-carousel-item>
              <el-carousel-item>
                <v-chart class="chart" :option="humidityoption" autoresize />
              </el-carousel-item>
              <el-carousel-item>
                <v-chart class="chart" :option="rainoption" autoresize />
              </el-carousel-item>
              <el-carousel-item>
                <v-chart class="chart" :option="windoption" autoresize />
              </el-carousel-item>
            </el-carousel>
          </div>
        </el-card>
      </el-col>
    </div>
    <br />

    <div>
      <el-row :gutter="10">
        <el-col :span="10" :offset="2">
          <el-card
            class="box-card"
            style="height: 250px"
            v-if="fieldinfo.planting_id != 0"
          >
            <template #header>
              <div class="card-header">
                <span>作物</span>
                <el-button class="button" text @click="cropTableVisible = true"
                  >查看历史</el-button
                >
              </div>
            </template>
            <div
              v-for="(value, key) in cropinfo"
              :key="key"
              class="inner-card"
              style="margin-bottom: 5px"
            >
              <span>{{ key }} </span>
              <span>{{ value }} </span>
            </div>
          </el-card>
          <el-card class="box-card" style="height: 250px" v-else>
            <template #header>
              <div class="card-header">
                <span>作物</span>
                <el-button class="button" text @click="cropTableVisible = true"
                  >查看历史</el-button
                >
              </div>
            </template>
            <div style="height: 130px" class="center-text">暂无作物种植</div>
          </el-card>
        </el-col>
        <el-col :span="11">
          <el-card class="box-card" style="height: 250px">
            <template #header>
              <div class="card-header" style="height: 32px">
                <span>收获</span>
              </div>
            </template>
            <div>
              <el-table :data="harvestinfo" height="155">
                <el-table-column prop="date" label="日期" />
                <el-table-column prop="quality" label="品质" />
                <el-table-column prop="quantity" label="收获量" />
                <el-table-column prop="admin" label="记录人" />
              </el-table>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
  <div
    id="fieldpage-loading"
    v-else
    v-loading="!finish"
    :element-loading-svg="svg"
    class="custom-loading-svg"
    element-loading-svg-view-box="-10, -10, 50, 50"
  ></div>

  <!--事项对话框-->
  <el-scrollbar>
    <el-dialog
      v-model="issueFormVisible"
      title="添加事项"
      width="30%"
      center
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
    >
      <el-form :model="singleissue">
        <el-form-item label="事项类型">
          <el-select
            v-model="singleissue.type"
            placeholder="请选择事项的类型"
            style="width: 100%"
          >
            <el-option label="待种植" value="待种植" />
            <el-option label="待施肥" value="待施肥" />
            <el-option label="待施农药" value="待施农药" />
            <el-option label="待浇水" value="待浇水" />
            <el-option label="自定义添加" value="自定义添加" />
          </el-select>
        </el-form-item>
        <el-form-item label="事项详情">
          <el-input
            v-model="singleissue.desc"
            autocomplete="off"
            :rows="2"
            type="textarea"
            placeholder="限120字内"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button
            @click="
              issueFormVisible = false;
              singleissue.type = '';
              singleissue.desc = '';
            "
            >取消</el-button
          >
          <el-button
            type="primary"
            @click="addIssueinfo(-1, singleissue.type, singleissue.desc)"
          >
            确认
          </el-button>
        </span>
      </template>
    </el-dialog>
  </el-scrollbar>

  <!--单独收获事项对话框-->
  <el-scrollbar>
    <el-dialog
      v-model="harvestissueFormVisible"
      title="添加事项"
      width="30%"
      center
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
    >
      <el-form :model="singleissue">
        <el-form-item label="事项类型"> 待收获 </el-form-item>
        <el-form-item label="事项详情">
          <el-input
            v-model="singleissue.desc"
            autocomplete="off"
            :rows="2"
            type="textarea"
            placeholder="限120字内"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button
            @click="
              harvestissueFormVisible = false;
              singleissue.type = '';
              singleissue.desc = '';
            "
            >取消</el-button
          >
          <el-button
            type="primary"
            @click="addIssueinfo(-1, '待收获', singleissue.desc)"
          >
            确认
          </el-button>
        </span>
      </template>
    </el-dialog>
  </el-scrollbar>

  <!--土壤对话框-->
  <el-dialog
    v-model="soilFormVisible"
    title="编辑信息"
    width="30%"
    center
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    :show-close="false"
  >
    <el-form :model="singlesoil">
      <el-form-item
        label="田地名称"
        :label-width="soilFormLabelWidth"
        class="left-aligned-label"
      >
        <el-input v-model="singlesoil.location" autocomplete="off" />
      </el-form-item>
      <el-form-item
        label="土壤类型"
        :label-width="soilFormLabelWidth"
        class="left-aligned-label"
      >
        <el-select
          v-model="singlesoil.类型"
          placeholder="请选择土壤类型"
          style="width: 100%"
        >
          <el-option label="红壤" value="红壤" />
          <el-option label="棕壤" value="棕壤" />
          <el-option label="褐土" value="褐土" />
          <el-option label="黑土" value="黑土" />
          <el-option label="栗钙土" value="栗钙土" />
          <el-option label="漠土" value="漠土" />
          <el-option label="潮土" value="潮土" />
          <el-option label="湿土" value="湿土" />
          <el-option label="水稻土" value="水稻土" />
          <el-option label="盐碱土" value="盐碱土" />
          <el-option label="岩性土" value="岩性土" />
          <el-option label="高山土" value="高山土" />
        </el-select>
      </el-form-item>
      <el-form-item
        label="pH值"
        :label-width="soilFormLabelWidth"
        class="left-aligned-label"
      >
        <el-input v-model="singlesoil.pH值" autocomplete="off" />
      </el-form-item>
      <el-form-item
        label="照片"
        :label-width="soilFormLabelWidth"
        class="left-aligned-label"
      >
        <el-upload
          ref="upload"
          class="avatar-uploader"
          action="#"
          :show-file-list="false"
          :http-request="httpRequestFn"
          :on-exceed="handleExceed"
        >
          <img v-if="imageUrl" :src="imageUrl" class="avatar" />
          <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
        </el-upload>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button
          @click="
            soilFormVisible = false;
            singlesoil.location = soilinfo.location;
            singlesoil.类型 = soilinfo.类型;
            singlesoil.pH值 = soilinfo.pH值;
            singlesoil.photo = imageUrl;
          "
          >取消</el-button
        >
        <el-button
          type="primary"
          @click="
            changesoilinfo(
              singlesoil.location,
              singlesoil.类型,
              singlesoil.pH值,
              imageUrl
            )
          "
        >
          确认
        </el-button>
      </span>
    </template>
  </el-dialog>

  <!--收获对话框-->
  <el-scrollbar>
    <el-dialog
      v-model="harvestFormVisible"
      title="添加收获记录"
      width="30%"
      center
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
    >
      <el-form :model="singleharvest">
        <el-form-item
          label="特级"
          :label-width="harvestFormLabelWidth"
          class="left-aligned-label"
        >
          <el-input
            v-model="singleharvest.teji"
            autocomplete="off"
            style="width: 200px"
          />&nbsp;kg
        </el-form-item>
        <el-form-item
          label="粮仓"
          :label-width="harvestFormLabelWidth"
          class="left-aligned-label"
        >
          <el-select
            v-model="singleharvest.tejiwarehouse"
            placeholder="请选择存放的粮仓"
            style="width: 250px"
          >
            <el-option
              v-for="item in tejioptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          label="一级"
          :label-width="harvestFormLabelWidth"
          class="left-aligned-label"
        >
          <el-input
            v-model="singleharvest.yiji"
            autocomplete="off"
            style="width: 200px"
          />&nbsp;kg
        </el-form-item>
        <el-form-item
          label="粮仓"
          :label-width="harvestFormLabelWidth"
          class="left-aligned-label"
        >
          <el-select
            v-model="singleharvest.yijiwarehouse"
            placeholder="请选择存放的粮仓"
            style="width: 250px"
          >
            <el-option
              v-for="item in yijioptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          label="二级"
          :label-width="harvestFormLabelWidth"
          class="left-aligned-label"
        >
          <el-input
            v-model="singleharvest.erji"
            autocomplete="off"
            style="width: 200px"
          />&nbsp;kg
        </el-form-item>
        <el-form-item
          label="粮仓"
          :label-width="harvestFormLabelWidth"
          class="left-aligned-label"
        >
          <el-select
            v-model="singleharvest.erjiwarehouse"
            placeholder="请选择存放的粮仓"
            style="width: 250px"
          >
            <el-option
              v-for="item in erjioptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <!--<el-button
            @click="
              harvestFormVisible = false;
              singleharvest.teji = '';
              singleharvest.tejiwarehouse = '';
              singleharvest.yiji = '';
              singleharvest.yijiwarehouse = '';
              singleharvest.erji = '';
              singleharvest.erjiwarehouse = '';
            "
            >取消</el-button
          >-->
          <el-button
            type="primary"
            @click="
              addHarvestinfo(
                singleharvest.teji,
                singleharvest.tejiwarehouse,
                singleharvest.yiji,
                singleharvest.yijiwarehouse,
                singleharvest.erji,
                singleharvest.erjiwarehouse,
                singleharvest.admin
              )
            "
          >
            确认
          </el-button>
        </span>
      </template>
    </el-dialog>
  </el-scrollbar>

  <!--作物历史-->
  <el-dialog v-model="cropTableVisible" title="种植历史" width="58%">
    <el-table :data="historyCropData" height="250">
      <el-table-column property="date" label="种植时间" />
      <el-table-column property="name" label="作物名称" />
      <el-table-column property="type" label="作物种类" />
      <el-table-column property="admin" label="种植负责人" />
    </el-table>
  </el-dialog>

  <!--待解决弹窗-->
  <el-scrollbar>
    <el-dialog
      v-model="s1FormVisible"
      title="农业事项"
      width="30%"
      center
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
      v-if="nowindex != -1"
    >
      <el-form :model="singlehandle1">
        <el-form-item label="事项类型" class="left-aligned-label">
          {{ issueinfo[nowindex].type }}
        </el-form-item>
        <el-form-item label="事项详情" class="left-aligned-label">
          {{ issueinfo[nowindex].desc }}
        </el-form-item>
        <el-form-item label="事项负责人" class="left-aligned-label">
          {{ issueinfo[nowindex].issueadmin }}
        </el-form-item>
        <el-form-item label="事项添加时间" class="left-aligned-label">
          {{ issueinfo[nowindex].starttime }}
        </el-form-item>
        <el-form-item label="使用农资" class="left-aligned-label">
          <el-cascader
            v-model="singlehandle1.toolName"
            :options="tooloptions"
            placeholder="请选择农资"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="使用设备" class="left-aligned-label">
          <el-cascader
            v-model="singlehandle1.equipName"
            :options="equipoptions"
            placeholder="请选择设备"
            style="width: 100%"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button
            @click="
              s1FormVisible = false;
              singlehandle1.toolType = '';
              singlehandle1.toolName = '';
              singlehandle1.toolNum = '';
              singlehandle1.equipType = '';
              singlehandle1.equipName = '';
            "
            >取消</el-button
          >
          <el-button type="primary" @click="handleS1"> 确认 </el-button>
        </span>
      </template>
    </el-dialog>
  </el-scrollbar>

  <!--解决中弹窗-->
  <el-scrollbar>
    <el-dialog
      v-model="s2FormVisible"
      title="农业事项"
      width="30%"
      center
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
      v-if="nowindex != -1"
    >
      <el-form :model="singlehandle2">
        <el-form-item label="事项类型" class="left-aligned-label">
          {{ issueinfo[nowindex].type }}
        </el-form-item>
        <el-form-item label="事项详情" class="left-aligned-label">
          {{ issueinfo[nowindex].desc }}
        </el-form-item>
        <el-form-item label="事项负责人" class="left-aligned-label">
          {{ issueinfo[nowindex].issueadmin }}
        </el-form-item>
        <el-form-item label="事项添加时间" class="left-aligned-label">
          {{ issueinfo[nowindex].starttime }}
        </el-form-item>
        <span v-if="issueinfo[nowindex].toolName != ''">
          <el-form-item label="使用农资" class="left-aligned-label">
            <div>
              类型：{{ issueinfo[nowindex].toolType }} &nbsp; 名称：{{
                issueinfo[nowindex].toolName
              }}
              &nbsp; 存量：{{ issueinfo[nowindex].toolLeft }}
            </div>
            <br /><br />
            <div>
              使用：<el-input-number
                v-model="singlehandle1.toolNum"
                size="small"
                :min="1"
                :max="issueinfo[nowindex].toolLeft"
                :disabled="issueinfo[nowindex].toolName === ''"
              />
            </div>
          </el-form-item>
        </span>
        <span v-if="issueinfo[nowindex].equipName != ''">
          <el-form-item label="使用设备" class="left-aligned-label">
            类型：{{ issueinfo[nowindex].equipType }}
            <br />
            名称：{{ issueinfo[nowindex].equipName }}
          </el-form-item>
        </span>
        <el-form-item label="处理开始时间" class="left-aligned-label">
          {{ issueinfo[nowindex].handletime }}
        </el-form-item>
        <el-form-item label="处理详情" class="left-aligned-label">
          <el-input
            v-model="singlehandle2.desc"
            autocomplete="off"
            :rows="2"
            type="textarea"
            placeholder="限120字内"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button
            @click="
              s2FormVisible = false;
              singlehandle2.desc = '';
            "
            >取消</el-button
          >
          <el-button type="primary" @click="handleS2(singlehandle2.desc)">
            确认
          </el-button>
        </span>
      </template>
    </el-dialog>
  </el-scrollbar>

  <!--已解决弹窗-->
  <el-scrollbar>
    <el-dialog
      v-model="s3FormVisible"
      title="农业事项"
      width="30%"
      center
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
      v-if="nowindex != -1"
    >
      <el-form>
        <el-form-item label="事项类型" class="left-aligned-label">
          {{ issueinfo[nowindex].type }}
        </el-form-item>
        <el-form-item label="事项详情" class="left-aligned-label">
          {{ issueinfo[nowindex].desc }}
        </el-form-item>
        <el-form-item label="事项负责人" class="left-aligned-label">
          {{ issueinfo[nowindex].issueadmin }}
        </el-form-item>
        <el-form-item label="事项添加时间" class="left-aligned-label">
          {{ issueinfo[nowindex].starttime }}
        </el-form-item>
        <span v-if="issueinfo[nowindex].toolName != ''">
          <el-form-item label="使用农资" class="left-aligned-label">
            类型：{{ issueinfo[nowindex].toolType }}
            <br />
            名称：{{ issueinfo[nowindex].toolName }}
            <br />
            使用：{{ issueinfo[nowindex].toolNum }}
          </el-form-item>
        </span>
        <span v-if="issueinfo[nowindex].equipName != ''">
          <el-form-item label="使用设备" class="left-aligned-label">
            类型：{{ issueinfo[nowindex].equipType }}
            <br />
            名称：{{ issueinfo[nowindex].equipName }}
          </el-form-item>
        </span>
        <el-form-item label="处理开始时间" class="left-aligned-label">
          {{ issueinfo[nowindex].handletime }}
        </el-form-item>
        <el-form-item label="处理详情" class="left-aligned-label">
          {{ issueinfo[nowindex].handleDesc }}
        </el-form-item>
        <el-form-item label="处理负责人" class="left-aligned-label">
          {{ issueinfo[nowindex].handleadmin }}
        </el-form-item>
        <el-form-item label="处理结束时间" class="left-aligned-label">
          {{ issueinfo[nowindex].endtime }}
        </el-form-item>
        <span
          v-if="
            issueinfo[nowindex].teji != '' ||
            issueinfo[nowindex].yiji != '' ||
            issueinfo[nowindex].erji != ''
          "
        >
          <el-form-item label="收获详情" class="left-aligned-label">
            <span v-if="issueinfo[nowindex].teji != ''">
              特级：{{ issueinfo[nowindex].teji }}kg
            </span>
            &nbsp;
            <span v-if="issueinfo[nowindex].yiji != ''">
              一级：{{ issueinfo[nowindex].yiji }}kg
            </span>
            &nbsp;
            <span v-if="issueinfo[nowindex].erji != ''">
              二级：{{ issueinfo[nowindex].erji }}kg
            </span>
          </el-form-item>
        </span>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="s3FormVisible = false">取消</el-button>
          <el-button type="primary" @click="s3FormVisible = false">
            确认
          </el-button>
        </span>
      </template>
    </el-dialog>
  </el-scrollbar>

  <!--选择农作物弹窗-->
  <el-scrollbar>
    <el-dialog
      v-model="chooseFormVisible"
      title="开始种植"
      width="30%"
      center
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
    >
      推荐作物：
      <el-table
        ref="rectableRef"
        :data="reccrop"
        height="150"
        highlight-current-row
        @current-change="handleRecCurrentChange"
      >
        <el-table-column property="name" label="名称" />
        <el-table-column property="type" label="种类" />
        <el-table-column property="soil" label="适宜土壤" />
        <el-table-column property="pH" label="适宜pH值" />
      </el-table>
      <br />
      全部作物：
      <el-table
        ref="alltableRef"
        :data="allcrop"
        height="150"
        highlight-current-row
        @current-change="handleAllCurrentChange"
      >
        <el-table-column property="name" label="名称" />
        <el-table-column property="type" label="种类" />
        <el-table-column property="soil" label="适宜土壤" />
        <el-table-column property="pH" label="适宜pH值" />
      </el-table>
      <br />
      新添作物：
      <div class="between-side">
        <el-input
          v-model="newcrop.name"
          autocomplete="off"
          style="width: 90px"
        />
        <el-select
          v-model="newcrop.type"
          placeholder="请选择"
          style="width: 90px"
        >
          <el-option label="水果" value="水果" />
          <el-option label="蔬菜" value="蔬菜" />
          <el-option label="谷物" value="谷物" />
        </el-select>
        <el-select
          v-model="newcrop.soil"
          placeholder="请选择"
          style="width: 90px"
        >
          <el-option label="红壤" value="红壤" />
          <el-option label="棕壤" value="棕壤" />
          <el-option label="褐土" value="褐土" />
          <el-option label="黑土" value="黑土" />
          <el-option label="栗钙土" value="栗钙土" />
          <el-option label="漠土" value="漠土" />
          <el-option label="潮土" value="潮土" />
          <el-option label="湿土" value="湿土" />
          <el-option label="水稻土" value="水稻土" />
          <el-option label="盐碱土" value="盐碱土" />
          <el-option label="岩性土" value="岩性土" />
          <el-option label="高山土" value="高山土" />
        </el-select>
        <el-input v-model="newcrop.pH" autocomplete="off" style="width: 90px" />
      </div>
      <div>
        <el-radio-group v-model="radio">
          <el-radio label="1" size="large">种植已有作物</el-radio>
          <el-radio label="2" size="large">种植新添作物</el-radio>
        </el-radio-group>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button
            @click="
              chooseFormVisible = false;
              newcrop.name = '';
              newcrop.type = '';
              newcrop.soil = '';
              newcrop.pH = '';
              currentRow = 'null';
            "
            >取消</el-button
          >
          <el-button type="primary" @click="handlenewplant()"> 确认 </el-button>
        </span>
      </template>
    </el-dialog>
  </el-scrollbar>

  <!--高级筛选-->
  <el-scrollbar>
    <el-dialog
      v-model="seniorFormVisible"
      title="筛选田地"
      width="45%"
      center
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
    >
      <div>
        <el-table
          :data="fieldData"
          height="250"
          highlight-current-row
          @current-change="handleSeniorCurrentChange"
        >
          <el-table-column property="farmname" label="农场名称" />
          <el-table-column property="name" label="田地名称" />
          <el-table-column property="state" label="状态" />
          <el-table-column property="crop" label="作物" />
          <el-table-column property="soil" label="土壤" />
          <el-table-column property="ph" label="pH值" />
        </el-table>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button
            @click="
              seniorFormVisible = false;
              currentSelection = 'null';
            "
            >取消</el-button
          >
          <el-button type="primary" @click="handleseniorselect()">
            确认
          </el-button>
        </span>
      </template>
    </el-dialog>
  </el-scrollbar>
</template>

<script setup >
import { ref, reactive, onMounted, provide, watch } from "vue";
import { Plus, Picture as IconPicture } from "@element-plus/icons-vue";
import { ElMessage } from "element-plus";
import { Get_All_Farm, Get_Fields_By_Farm } from "@/api/FarmManagement.js";
import {
  Get_Filtered_Fields,
  Get_Farm_Fields,
  Find_Current_Crop,
  Get_Weather,
  Get_Current_Harvest,
  Update_Field,
  Get_Crop,
  find_appropriate_crop,
  Get_Todays_Weather,
  find_history_crop,
  create_planting_and_issue,
  CreateNewCropAndGetId,
  Create_Issue,
  Get_Free_Equipment,
  Get_Free_Consumables,
  GetIssuesByFieldId,
  GetActivitiesByActivityId,
  Solve_Issue_By_Equipment,
  Solve_Issue_By_Consumable,
  Find_Appropriate_Warehouse,
  Insert_Harvest_Info_And_Update_Wares,
  Get_Harvest_Info,
  Check_Harvest_Status,
  Get_Issue_Static,
} from "@/api/FieldManagement.js";
import global_var from "@/utils/global_var.js";
import router from "@/router";
//引入地图
import AMapLoader from "@amap/amap-jsapi-loader";
// 设置安全密钥
window._AMapSecurityConfig = {
  securityJsCode: "bc6447c7c502a1b31195cbb29dd23899",
};

//pinia
import useUserStore2 from "@/store/uss";
const store = useUserStore2();

//统计引用
import { use } from "echarts/core";
import { CanvasRenderer } from "echarts/renderers";
import { BarChart, LineChart } from "echarts/charts";
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
} from "echarts/components";
import VChart, { THEME_KEY } from "vue-echarts";
use([
  CanvasRenderer,
  BarChart,
  LineChart,
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
]);
provide(THEME_KEY, "light");

var echarts = require("echarts");
require("echarts-wordcloud");


const goToBot = {
  jumpToUrl: function() {
    window.open('https://www.ciciai.com/share?botId=7313188496997646338', '_blank');
  }
};

const issueoption = ref({
  title: {
    text: "热点分析",
    x: "center",
    textStyle: {
      fontSize: 20,
    },
  },
  backgroundColor: "#FFFFFF",
  tooltip: {
    show: true,
  },
  toolbox: {
    feature: {
      saveAsImage: {
        iconStyle: {
          normal: {
            color: "#FFFFFF",
          },
        },
      },
    },
  },
  series: [
    {
      name: "热点分析",
      type: "wordCloud",
      //size: ['9%', '99%'],
      sizeRange: [16, 66],
      //textRotation: [0, 45, 90, -45],
      rotationRange: [-45, 45],
      //shape: 'circle',
      textPadding: 0,
      autoSize: {
        enable: true,
        minSize: 6,
      },
      textStyle: {
        color: function () {
          return (
            "rgb(" +
            [
              Math.round(Math.random() * 200 + 55),
              Math.round(Math.random() * 200 + 55),
              Math.round(Math.random() * 200 + 55),
            ].join(",") +
            ")"
          );
        },
      },
      data: [],
    },
  ],
});

const tempoption = ref({
  title: {
    text: "温度",
    left: "center",
  },
  tooltip: {
    trigger: "axis",
    formatter: "{b} <br/>{a0}: {c0} °C<br/>{a1}: {c1} °C",
  },
  legend: {
    orient: "vertical",
    data: ["最高温", "最低温"],
    left: "left",
  },
  xAxis: {
    type: "category",
    data: [],
  },
  yAxis: {
    type: "value",
    name: "温度 (°C)",
  },
  series: [
    {
      name: "最高温",
      type: "line",
      data: [],
    },
    {
      name: "最低温",
      type: "line",
      data: [],
    },
  ],
});

const humidityoption = ref({
  title: {
    text: "湿度",
    left: "center",
  },
  tooltip: {
    trigger: "axis",
    formatter: "{b} <br/>{a}: {c} %",
  },
  xAxis: {
    type: "category",
    data: [],
  },
  yAxis: {
    type: "value",
    name: "湿度 (%)",
  },
  series: [
    {
      name: "湿度",
      type: "line",
      data: [],
    },
  ],
});

const rainoption = ref({
  title: {
    text: "降水量",
    left: "center",
  },
  tooltip: {
    trigger: "axis",
    formatter: "{b} <br/>{a} : {c} mm",
  },

  xAxis: {
    type: "category",
    data: [],
  },

  yAxis: {
    type: "value",
    name: "降雨量(mm)",
  },
  series: [
    {
      name: "降雨量",
      type: "bar",
      data: [],
    },
  ],
});

const windoption = ref({
  title: {
    text: "风速",
    left: "center",
  },
  tooltip: {
    trigger: "axis",
    formatter: "{b} <br/>{a}: {c} km/h",
  },
  xAxis: {
    type: "category",
    data: [],
  },
  yAxis: {
    type: "value",
    name: "风速 (km/h)",
  },
  series: [
    {
      name: "风速",
      type: "line",
      data: [],
    },
  ],
});

//加载
const svg = `
        <path class="path" d="
          M 30 15
          L 28 17
          M 25.61 25.61
          A 15 15, 0, 0, 1, 15 30
          A 15 15, 0, 1, 1, 27.99 7.5
          L 15 15
        " style="stroke-width: 4px; fill: rgba(0, 0, 0, 0)"/>
      `;

const finish = ref(false);
//输入框
const optionvalue = ref("Option4");
const options = [
  {
    value: "Option1",
    label: "查看最近一月",
  },
  {
    value: "Option2",
    label: "查看最近一季度",
  },
  {
    value: "Option3",
    label: "查看最近半年",
  },
  {
    value: "Option4",
    label: "查看最近一年",
  },
];

const radio = ref("1");

const farmoptions = reactive([]);

const cropoptions = reactive([]);

const tooloptions = reactive([]);

const equipoptions = reactive([]);

const tejioptions = reactive([]);

const yijioptions = reactive([]);

const erjioptions = reactive([]);

//处理照片上传
const imageUrl = ref("");

const COS = require("cos-js-sdk-v5");

var cos = new COS({
 SecretId: "AKID46yc3GKBoJarz3DJNH4e9QU6XotlNkts",
 SecretKey: "qRp4ADD0qcEfwGVinrkS6hElIj6d7PUL",
});

const httpRequestFn = (res) => {
  cos.putObject(
    {
      Bucket: "dyc-1319697249", // 存储桶
      Region: "ap-shanghai", // 存储桶所在地域
      Key: res.file.name, // 文件名
      StorageClass: "STANDARD", // 上传模式
      Body: res.file, // 上传文件对象
      onProgress: (progressData) => {
        // 进度条
        console.log(JSON.stringify(progressData));
      },
    },
    (err, data) => {
      console.log(err || data);
      if (data) {
        // 上传成功
        imageUrl.value = `http://${data.Location}`;
        console.log(imageUrl.value);
      }
    }
  );
};

const upload = ref(null);
const handleExceed = (files) => {
  upload.value.clearFiles();
  const file = files[0];
  file.uid = Date.now();
  upload.value.handleStart(file);
};

//监视选择器的选项

watch(optionvalue, (newValue, oldValue) => {
  console.log("新选项:", newValue);
  tempoption.value.xAxis.data.length = 0;
  tempoption.value.series[0].data.length = 0;
  tempoption.value.series[1].data.length = 0;
  humidityoption.value.xAxis.data.length = 0;
  humidityoption.value.series[0].data.length = 0;
  rainoption.value.xAxis.data.length = 0;
  rainoption.value.series[0].data.length = 0;
  windoption.value.xAxis.data.length = 0;
  windoption.value.series[0].data.length = 0;
  //天气
  try {
    let params = {
      farm_id: global_var.farmid,
      mode: 0,
    };
    if (newValue == "Option2") {
      params.mode = 1;
    } else if (newValue == "Option3") {
      params.mode = 2;
    } else if (newValue == "Option4") {
      params.mode = 3;
    }
    Get_Issue_Static(params).then(function (res) {
      const data = res.data;
      //for (const item of data)
      //search.value.series[0].data.push(data[0]);
      console.log(data);
      // 清空数据
      issueoption.value.series[0].data = [];
      for (const item of data) {
        issueoption.value.series[0].data.push({
          name: item.type,
          value: item.count,
        });
      }
    });
    Get_Weather(params).then(function (res) {
      const data = res.data;
      if (data.length > 0) {
        const reversed = data.slice().reverse();
        if (params.mode == 0) {
          if (data.length >= 0 + 3 * 9) {
            for (let i = 0 + 3 * 9; i >= 0; i -= 3) {
              rainoption.value.xAxis.data.push(
                reversed[i].record_Date.split("T")[0]
              );
              rainoption.value.series[0].data.push(reversed[i].precipitation);
            }
          }
        } else if (params.mode == 1) {
          if (data.length >= 0 + 9 * 9) {
            for (let i = 0 + 9 * 9; i >= 0; i -= 9) {
              rainoption.value.xAxis.data.push(
                reversed[i].record_Date.split("T")[0]
              );
              rainoption.value.series[0].data.push(reversed[i].precipitation);
            }
          }
        } else {
          if (data.length >= 0 + 18 * 9) {
            for (let i = 0 + 18 * 9; i >= 0; i -= 18) {
              rainoption.value.xAxis.data.push(
                reversed[i].record_Date.split("T")[0]
              );
              rainoption.value.series[0].data.push(reversed[i].precipitation);
            }
          }
        }
        for (const item of data) {
          tempoption.value.xAxis.data.push(item.record_Date.split("T")[0]);
          tempoption.value.series[0].data.push(item.high_Temp);
          tempoption.value.series[1].data.push(item.low_Temp);
          humidityoption.value.xAxis.data.push(item.record_Date.split("T")[0]);
          humidityoption.value.series[0].data.push(item.humidity);
          windoption.value.xAxis.data.push(item.record_Date.split("T")[0]);
          windoption.value.series[0].data.push(item.wind);
        }
      }
    });
  } catch (error) {
    console.error(error);
  }
});

//时间日期

const currentMin = ref("");
const getFormattedMin = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  const seconds = String(now.getSeconds()).padStart(2, "0");

  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
};
currentMin.value = getFormattedMin();

//信息初始化
const nowadmin = ref("");

const nowindex = ref(-1);

const weather = reactive({
  天气: null,
  最高温: null,
  最低温: null,
  湿度: null,
  降雨量: null,
  最大风速: null,
});

const fieldinfo = reactive({
  id: null,
  name: null,
  location: null,
  planting_id: -1,
});

const soilinfo = reactive({
  location: null,
  类型: null,
  pH值: null,
  photo: "",
});

const cropinfo = reactive({
  名称: "",
  种类: "",
  适宜土壤: "",
  适宜pH值: "",
  开始种植时间: "",
  种植负责人: "",
});

const harvestinfo = reactive([]);

const addHarvestinfo = async (
  teji,
  tejiwarehouse,
  yiji,
  yijiwarehouse,
  erji,
  erjiwarehouse,
  admin
) => {
  if (
    (teji === "" && yiji === "" && erji === "") ||
    (teji != "" && tejiwarehouse === "") ||
    (yiji != "" && yijiwarehouse === "") ||
    (erji != "" && erjiwarehouse === "") ||
    (teji === "" && tejiwarehouse != "") ||
    (yiji === "" && yijiwarehouse != "") ||
    (erji === "" && erjiwarehouse != "")
  ) {
    ElMessage.error("收获记录不完整");
    return;
  }
  harvestFormVisible.value = false;
  singleharvest.teji = "";
  singleharvest.tejiwarehouse = "";
  singleharvest.yiji = "";
  singleharvest.yijiwarehouse = "";
  singleharvest.erji = "";
  singleharvest.erjiwarehouse = "";

  try {
    let params = {
      harvest_id: issueinfo[nowindex.value].harvestid,
    };
    if (teji != "") {
      params.weight1 = teji;
      params.warehouse_id1 = tejiwarehouse;
    }
    if (yiji != "") {
      params.weight2 = yiji;
      params.warehouse_id2 = yijiwarehouse;
    }
    if (erji != "") {
      params.weight3 = erji;
      params.warehouse_id3 = erjiwarehouse;
    }
    await Insert_Harvest_Info_And_Update_Wares(params).then(function (res) {
      //const data = res.data;
    });
  } catch (error) {
    console.error(error);
  }
  let nowtime = getFormattedMin();
  if (teji != "") {
    harvestinfo.push({
      date: nowtime.split(" ")[0],
      quality: "特级",
      quantity: teji + "kg",
      admin: admin,
    });
    issueinfo[nowindex.value].teji = teji;
    issueinfo[nowindex.value].tejiwarehouse = tejiwarehouse;
  }
  if (yiji != "") {
    harvestinfo.push({
      date: nowtime.split(" ")[0],
      quality: "一级",
      quantity: yiji + "kg",
      admin: admin,
    });
    issueinfo[nowindex.value].yiji = yiji;
    issueinfo[nowindex.value].yijiwarehouse = yijiwarehouse;
  }
  if (erji != "") {
    harvestinfo.push({
      date: nowtime.split(" ")[0],
      quality: "二级",
      quantity: erji + "kg",
      admin: admin,
    });
    issueinfo[nowindex.value].erji = erji;
    issueinfo[nowindex.value].erjiwarehouse = erjiwarehouse;
  }
};

const issueinfo = reactive([]);

const addIssueinfo = async (id, type, desc) => {
  if (type === "" || desc === "") {
    ElMessage.error("事项的名称或详情为空");
    return;
  }

  if (desc.length > 120) {
    ElMessage.error("事项的详情字数超过限制");
    return;
  }

  let now = getFormattedMin();

  if (id == -1) {
    try {
      let params = {
        type: type,
        dateString: now,
        technologist_id: store.token.id,
        planting_id: fieldinfo.planting_id,
        detail: desc,
      };
      await Create_Issue(params)
        .then(function (res) {
          const data = res.data;
          id = data;
        })
        .catch((error) => {
          console.error("查询请求失败:", error);
        });
    } catch (error) {
      console.error(error);
    }
  }

  issueinfo.push({
    id: id,
    type: type,
    state: "待解决",
    desc: desc,
    issueadmin: nowadmin.value,
    starttime: now,
    toolType: "",
    toolName: "",
    toolNum: "",
    equipType: "",
    equipName: "",
    handletime: "",
    handleDesc: "",
    handleadmin: "",
    endtime: "",
    teji: "",
    tejiwarehouse: "",
    yiji: "",
    yijiwarehouse: "",
    erji: "",
    erjiwarehouse: "",
  });
  issueFormVisible.value = false;
  harvestissueFormVisible.value = false;
  singleissue.type = "";
  singleissue.desc = "";
};

const reccrop = reactive([]);

const allcrop = reactive([]);

const handlecardbtn = async (index) => {
  nowindex.value = index;
  console.log(issueinfo[index].id);

  if (issueinfo[index].state === "待解决") {
    tooloptions.length = 0;
    equipoptions.length = 0;

    //获取推荐消耗物
    try {
      let params = {
        issue_id: issueinfo[index].id,
      };
      await Get_Free_Consumables(params).then(function (res) {
        const data = res.data;
        if (data.length > 0) {
          for (const item of data) {
            if (tooloptions.length == 0) {
              tooloptions.push({
                value: item.type,
                label: item.type,
                children: [
                  {
                    value: item.name + "#*#" + item.consumables_Id,
                    label: item.name,
                  },
                ],
              });
            } else {
              let exist = false;
              for (const opt of tooloptions) {
                if (opt.value == item.type) {
                  opt.children.push({
                    value: item.name + "#*#" + item.consumables_Id,
                    label: item.name,
                  });
                  exist = true;
                  break;
                }
              }
              if (exist == false) {
                tooloptions.push({
                  value: item.type,
                  label: item.type,
                  children: [
                    {
                      value: item.name + "#*#" + item.consumables_Id,
                      label: item.name,
                    },
                  ],
                });
              }
            }
          }
        }
      });
    } catch (error) {
      console.error(error);
    }

    //获取推荐设备
    try {
      let params = {
        issue_id: issueinfo[index].id,
      };
      await Get_Free_Equipment(params).then(function (res) {
        const data = res.data;
        if (data.length > 0) {
          for (const item of data) {
            if (equipoptions.length == 0) {
              equipoptions.push({
                value: item.type,
                label: item.type,
                children: [
                  {
                    value: item.name + "#*#" + item.equipment_Id,
                    label: item.name,
                  },
                ],
              });
            } else {
              let exist = false;
              for (const opt of equipoptions) {
                if (opt.value == item.type) {
                  opt.children.push({
                    value: item.name + "#*#" + item.equipment_Id,
                    label: item.name,
                  });
                  exist = true;
                  break;
                }
              }
              if (exist == false) {
                equipoptions.push({
                  value: item.type,
                  label: item.type,
                  children: [
                    {
                      value: item.name + "#*#" + item.equipment_Id,
                      label: item.name,
                    },
                  ],
                });
              }
            }
          }
        }
      });
    } catch (error) {
      console.error(error);
    }

    s1FormVisible.value = true;
  } else if (issueinfo[index].state === "解决中") {
    s2FormVisible.value = true;
  } else {
    s3FormVisible.value = true;
  }
};

const handleS1 = async () => {
  if (
    (singlehandle1.toolName[0] != "" && singlehandle1.toolName[1] === "") ||
    (singlehandle1.equipType[0] != "" && singlehandle1.equipName[1] === "")
  ) {
    ElMessage.error("资产信息不完整");
    return;
  }
  issueinfo[nowindex.value].state = "解决中";
  if (singlehandle1.toolName != "") {
    issueinfo[nowindex.value].toolType = singlehandle1.toolName[0];
    issueinfo[nowindex.value].toolName =
      singlehandle1.toolName[1].split("#*#")[0];
  }
  if (singlehandle1.equipName != "") {
    issueinfo[nowindex.value].equipType = singlehandle1.equipName[0];
    issueinfo[nowindex.value].equipName =
      singlehandle1.equipName[1].split("#*#")[0];
  }
  issueinfo[nowindex.value].handletime = getFormattedMin();

  //待解决->解决中
  try {
    let params = {
      issue_id: issueinfo[nowindex.value].id,
    };
    if (singlehandle1.equipName != "") {
      params.equipment_id = singlehandle1.equipName[1].split("#*#")[1];
    }
    params.technologist_id = store.token.id;
    params.datestring = issueinfo[nowindex.value].handletime;
    if (singlehandle1.toolName != "") {
      params.consumables_id = singlehandle1.toolName[1].split("#*#")[1];
    }
    await Solve_Issue_By_Equipment(params).then(function (res) {
      const data = res.data;
      issueinfo[nowindex.value].toolLeft = data;
    });
  } catch (error) {
    console.error(error);
  }

  singlehandle1.toolType = "";
  singlehandle1.toolName = "";
  singlehandle1.equipType = "";
  singlehandle1.equipName = "";
  s1FormVisible.value = false;
};

const handleS2 = async (desc) => {
  if (desc === "") {
    ElMessage.error("处理详情为空");
    return;
  }

  if (desc.length > 120) {
    ElMessage.error("处理详情字数超过限制");
    return;
  }

  issueinfo[nowindex.value].toolNum = singlehandle1.toolNum;
  issueinfo[nowindex.value].state = "已解决";
  issueinfo[nowindex.value].handleDesc = desc;
  issueinfo[nowindex.value].handleadmin = nowadmin.value;
  issueinfo[nowindex.value].endtime = getFormattedMin();

  //解决中->已解决
  try {
    let params = {
      issue_id: issueinfo[nowindex.value].id,
    };
    params.technologist_id = store.token.id;
    params.datestring = issueinfo[nowindex.value].endtime;
    if (singlehandle1.toolNum != "") {
      params.amount = singlehandle1.toolNum;
    }
    params.detail = issueinfo[nowindex.value].handleDesc;
    await Solve_Issue_By_Consumable(params).then(function (res) {
      const data = res.data;
      console.log(data);
      issueinfo[nowindex.value].harvestid = data.newHarvestId;
    });
  } catch (error) {
    console.error(error);
  }

  singlehandle2.desc = "";
  singlehandle1.toolNum = "";
  s2FormVisible.value = false;
  if (issueinfo[nowindex.value].type === "待收获") {
    try {
      let params = {
        harvest_id: issueinfo[nowindex.value].harvestid,
      };
      await Find_Appropriate_Warehouse(params).then(function (res) {
        const data = res.data;
        if (data.length > 0) {
          let tejiunique = false;
          let yijiunique = false;
          let erjiunique = false;
          for (const item of data) {
            if (item.quality == "特级") {
              if (tejiunique == false && item.status == "非空") {
                tejiunique = true;
                tejioptions.length = 0;
                tejioptions.push({
                  label: item.name,
                  value: item.warehouse_Id,
                });
              } else if (tejiunique == false) {
                tejioptions.push({
                  label: item.name,
                  value: item.warehouse_Id,
                });
              }
            } else if (item.quality == "一级") {
              if (yijiunique == false && item.status == "非空") {
                yijiunique = true;
                yijioptions.length = 0;
                yijioptions.push({
                  label: item.name,
                  value: item.warehouse_Id,
                });
              } else if (yijiunique == false) {
                yijioptions.push({
                  label: item.name,
                  value: item.warehouse_Id,
                });
              }
            } else {
              if (erjiunique == false && item.status == "非空") {
                erjiunique = true;
                erjioptions.length = 0;
                erjioptions.push({
                  label: item.name,
                  value: item.warehouse_Id,
                });
              } else if (erjiunique == false) {
                erjioptions.push({
                  label: item.name,
                  value: item.warehouse_Id,
                });
              }
            }
          }
        }
      });
    } catch (error) {
      console.error(error);
    }
    harvestFormVisible.value = true;
  }
};

const changesoilinfo = (location, type, pH, photo) => {
  if (location === "" || type === "" || pH === "" || photo === "") {
    ElMessage.error("土壤的类型或pH值为空");
    return;
  }
  soilFormVisible.value = false;
  soilinfo.location = singlesoil.location;
  fieldinfo.location = singlesoil.location;
  soilinfo.类型 = singlesoil.类型;
  soilinfo.pH值 = singlesoil.pH值;
  try {
    let params = {
      field_id: fieldinfo.id,
      name: fieldinfo.location,
      soil_type: soilinfo.类型,
      ph_level: soilinfo.pH值,
      photo: photo,
    };
    Update_Field(params).then(function (res) {
      const data = res.data;
      console.log(data);
    });
  } catch (error) {
    console.error(error);
  }
  soilinfo.photo = photo;

  for (let i = 0; i < farmList.value.length; i++) {
    if (farmList.value[i].farm_Id == global_var.farmid) {
      for (let j = 0; j < farmList.value[i].fieldList.length; j++) {
        if (farmList.value[i].fieldList[j].field_Id == global_var.fieldid) {
          polygonsText.value[i][j].setText(location);
        }
      }
    }
  }
};

const currentRow = ref("null");
const handleRecCurrentChange = (val) => {
  allsetCurrent();
  currentRow.value = val;
};

const handleAllCurrentChange = (val) => {
  recsetCurrent();
  currentRow.value = val;
};

const rectableRef = ref();
const recsetCurrent = () => {
  rectableRef.value.setCurrentRow();
};

const alltableRef = ref();
const allsetCurrent = () => {
  alltableRef.value.setCurrentRow();
};

const handlenewplant = async () => {
  let newissueid = -1;
  let newcropid = -1;
  if (radio.value === "1") {
    if (currentRow.value === "null") {
      ElMessage.error("未选择");
      return;
    }
    cropinfo.名称 = currentRow.value.name;
    cropinfo.种类 = currentRow.value.type;
    cropinfo.适宜土壤 = currentRow.value.soil;
    cropinfo.适宜pH值 = currentRow.value.pH;
    cropinfo.开始种植时间 = getFormattedMin();
    cropinfo.种植负责人 = nowadmin.value;
    try {
      let params = {
        field_id: global_var.fieldid,
        crop_id: currentRow.value.id,
        dateString: cropinfo.开始种植时间,
        technologist_id: store.token.id,
      };
      await create_planting_and_issue(params)
        .then(function (res) {
          const data = res.data;
          fieldinfo.planting_id = data[0].planting_Id;
          newissueid = data[0].issue_Id;
        })
        .catch((error) => {
          console.error("查询请求失败:", error);
        });
    } catch (error) {
      console.error(error);
    }
  } else {
    if (
      newcrop.name === "" ||
      newcrop.type === "" ||
      newcrop.soil === "" ||
      newcrop.pH === ""
    ) {
      ElMessage.error("新添作物所填信息不完整");
      return;
    }
    const regex = /^\d+(\.\d+)?~\d+(\.\d+)?$/;
    if (regex.test(newcrop.pH) == false) {
      ElMessage.error("pH的填写不符合格式要求");
      return;
    }
    try {
      let params = {
        name: newcrop.name,
        cropType: newcrop.type,
        soilType: newcrop.soil,
        lowPh: newcrop.pH.split("~")[0],
        highPh: newcrop.pH.split("~")[1],
      };
      await CreateNewCropAndGetId(params)
        .then(function (res) {
          const data = res.data;
          newcropid = data;
        })
        .catch((error) => {
          console.error("查询请求失败:", error);
        });
    } catch (error) {
      console.error(error);
    }
    cropinfo.名称 = newcrop.name;
    cropinfo.种类 = newcrop.type;
    cropinfo.适宜土壤 = newcrop.soil;
    cropinfo.适宜pH值 = newcrop.pH;
    cropinfo.开始种植时间 = getFormattedMin();
    cropinfo.种植负责人 = nowadmin.value;
    try {
      let params = {
        field_id: global_var.fieldid,
        crop_id: newcropid,
        dateString: cropinfo.开始种植时间,
        technologist_id: store.token.id,
      };
      await create_planting_and_issue(params)
        .then(function (res) {
          const data = res.data;
          fieldinfo.planting_id = data[0].planting_Id;
          newissueid = data[0].issue_Id;
        })
        .catch((error) => {
          console.error("查询请求失败:", error);
        });
    } catch (error) {
      console.error(error);
    }
  }
  chooseFormVisible.value = false;
  addIssueinfo(newissueid, "待种植", "空");
  currentRow.value = "null";
};

const finishharvest = async () => {
  let existharvest = false;
  for (const item of issueinfo) {
    if (item.state != "已解决") {
      ElMessage.error("仍有事项尚未解决");
      return;
    }
    if (item.type == "待收获") {
      existharvest = true;
    }
  }
  if (existharvest == true) {
    try {
      let params = {
        planting_id: fieldinfo.planting_id,
        dateString: getFormattedMin(),
      };
      await Check_Harvest_Status(params).then(function (res) {
        const data = res.data;
        console.log(data);
      });
    } catch (error) {
      console.error(error);
    }
    ElMessage({
      type: "success",
      message: "收获已完成",
    });
    nowindex.value = -1;
    issueinfo.length = 0;
    historyCropData.length = 0;
    fieldinfo.planting_id = 0;
    harvestinfo.length = 0;

    //历史种植
    try {
      let params = {
        field_id: global_var.fieldid,
      };
      await find_history_crop(params)
        .then(function (res) {
          const data = res.data;
          if (data.length > 0) {
            for (const item of data) {
              historyCropData.push({
                date:
                  item.start_date.split("T")[0] +
                  "~" +
                  item.end_date.split("T")[0],
                name: item.name,
                type: item.crop_type,
                admin: item.technologist_name,
              });
            }
          }
        })
        .catch((error) => {
          console.error("查询请求失败:", error);
        });
    } catch (error) {
      console.error(error);
    }
  } else {
    ElMessage.error("当前种植未收获过");
  }
};

const historyCropData = reactive([]);

const fieldData = reactive([]);
const preload = () => {
  fieldData.length = 0;
  let params = {};
  if (select.name != "") {
    params.farm_name = select.name;
  }
  if (select.state != "") {
    params.status = select.state == "空闲" ? "空" : "非空";
  }
  if (select.crop != "") {
    params.crop_name = select.crop;
  }
  if (select.soil != "") {
    params.soil_type = select.soil;
  }
  if (select.leftpH != "") {
    params.min_ph = select.leftpH;
  }
  if (select.rightpH != "") {
    params.max_ph = select.rightpH;
  }
  Get_Filtered_Fields(params).then(function (res) {
    const data = res.data;
    console.log(data);
    for (const item of data) {
      fieldData.push({
        id: item.field_Id,
        farmname: item.farmname,
        name: item.name,
        state: item.status == "空" ? "空闲" : "占用",
        crop: item.cropName == null ? "无" : item.cropName,
        soil: item.soil_Type,
        ph: item.ph_Level,
      });
    }
  });
};

const preloadS0 = async () => {
  reccrop.length = 0;
  allcrop.length = 0;
  //获取推荐种植作物
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await find_appropriate_crop(params)
      .then(function (res) {
        const data = res.data;
        if (data.length > 0) {
          for (const item of data) {
            reccrop.push({
              id: item.crop_Id,
              name: item.name,
              type: item.crop_Type,
              soil: item.soil_Type,
              pH: item.low_Ph + "~" + item.high_Ph,
            });
          }
        }
      })
      .catch((error) => {
        console.error("查询请求失败:", error);
      });
  } catch (error) {
    console.error(error);
  }

  //获取全部可种植作物
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await Get_Crop(params)
      .then(function (res) {
        const data = res.data;
        if (data.length > 0) {
          for (const item of data) {
            allcrop.push({
              id: item.crop_Id,
              name: item.name,
              type: item.crop_Type,
              soil: item.soil_Type,
              pH: item.low_Ph + "~" + item.high_Ph,
            });
          }
        }
      })
      .catch((error) => {
        console.error("查询请求失败:", error);
      });
  } catch (error) {
    console.error(error);
  }
};

const currentSelection = ref("null");

const handleSeniorCurrentChange = (val) => {
  currentSelection.value = val;
};

const handleseniorselect = () => {
  if (currentSelection.value === "null") {
    ElMessage.error("未选择");
    return;
  }
  //为了适应地图打的补丁，逻辑并不严谨，希望以后能改成更加严谨的依靠唯一标识id搜索
  for (const item of farmList.value) {
    if (item.name == currentSelection.value.farmname) {
      global_var.farmid = item.farm_Id;
    }
  }
  //补丁以上//
  global_var.fieldid = currentSelection.value.id;
  seniorFormVisible.value = false;
  onMountedLogic();
  currentSelection.value = "null";
};

const onMountedLogic = async () => {
  farmoptions.length = 0;
  cropoptions.length = 0;
  fieldData.length = 0;
  harvestinfo.length = 0;
  issueinfo.length = 0;
  allcrop.length = 0;
  reccrop.length = 0;
  historyCropData.length = 0;
  nowindex.value = -1;
  fieldinfo.planting_id = 0;
  finish.value = false;
  //田地名称、位置、土壤、pH
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await Get_Farm_Fields(params).then(function (res) {
      const data = res.data;
      fieldinfo.id = global_var.fieldid;
      fieldinfo.name = data[0].farmName;
      fieldinfo.location = data[0].fieldName;
      fieldinfo.planting_id = data[0].planting_Id;
      soilinfo.location = data[0].fieldName;
      soilinfo.类型 = data[0].soilType;
      soilinfo.pH值 = data[0].phLevel;
      soilinfo.photo = data[0].photo;
      singlesoil.location = data[0].fieldName;
      singlesoil.类型 = data[0].soilType;
      singlesoil.pH值 = data[0].phLevel;
      singlesoil.photo = data[0].photo;
      imageUrl.value = data[0].photo;
    });
  } catch (error) {
    console.error(error);
  }

  //田地当前种植作物
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await Find_Current_Crop(params)
      .then(function (res) {
        const data = res.data;
        if (data.length > 0) {
          cropinfo.名称 = data[0].name;
          cropinfo.种类 = data[0].crop_type;
          cropinfo.适宜土壤 = data[0].soil_type;
          cropinfo.适宜pH值 = data[0].low_ph + "~" + data[0].high_ph;
          cropinfo.开始种植时间 = data[0].start_date.replace("T", " ");
          cropinfo.种植负责人 = data[0].technologist_name;
        }
      })
      .catch((error) => {
        console.error("查询请求失败:", error);
      });
  } catch (error) {
    console.error(error);
  }

  //统计图的天气
  try {
    let params = {
      farm_id: global_var.farmid,
      mode: 0,
    };
    await Get_Issue_Static(params).then(function (res) {
      const data = res.data;
      //for (const item of data)
      //search.value.series[0].data.push(data[0]);
      console.log(data);
      // 清空数据
      issueoption.value.series[0].data = [];
      for (const item of data) {
        issueoption.value.series[0].data.push({
          name: item.type,
          value: item.count,
        });
      }
    });
    await Get_Weather(params).then(function (res) {
      const data = res.data;
      if (data.length > 0) {
        const reversed = data.slice().reverse();
        tempoption.value.xAxis.data.length = 0;
        tempoption.value.series[0].data.length = 0;
        tempoption.value.series[1].data.length = 0;
        humidityoption.value.xAxis.data.length = 0;
        humidityoption.value.series[0].data.length = 0;
        rainoption.value.xAxis.data.length = 0;
        rainoption.value.series[0].data.length = 0;
        windoption.value.xAxis.data.length = 0;
        windoption.value.series[0].data.length = 0;
        if (data.length >= 0 + 3 * 9) {
          for (let i = 0 + 3 * 9; i >= 0; i -= 3) {
            rainoption.value.xAxis.data.push(
              reversed[i].record_Date.split("T")[0]
            );
            rainoption.value.series[0].data.push(reversed[i].precipitation);
          }
        }
        for (const item of data) {
          tempoption.value.xAxis.data.push(item.record_Date.split("T")[0]);
          tempoption.value.series[0].data.push(item.high_Temp);
          tempoption.value.series[1].data.push(item.low_Temp);
          humidityoption.value.xAxis.data.push(item.record_Date.split("T")[0]);
          humidityoption.value.series[0].data.push(item.humidity);
          windoption.value.xAxis.data.push(item.record_Date.split("T")[0]);
          windoption.value.series[0].data.push(item.wind);
        }
      }
    });
  } catch (error) {
    console.error(error);
  }

  //田地最新收获
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await Get_Current_Harvest(params)
      .then(function (res) {
        const data = res.data;
        if (data.length > 0) {
          for (const item of data) {
            harvestinfo.push({
              date: item.harvest_date.split("T")[0],
              quality: item.quality,
              quantity: item.weight + "kg",
              admin: item.technologist_name,
            });
          }
        }
      })
      .catch((error) => {
        console.error("查询请求失败:", error);
      });
  } catch (error) {
    console.error(error);
  }

  //高级筛选的农场列表
  try {
    await Get_All_Farm().then(function (res) {
      const data = res.data;
      for (const item of data) {
        farmoptions.push({
          label: item.name,
          value: item.name,
        });
      }
    });
  } catch (error) {
    console.error(error);
  }

  //高级筛选的作物列表
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await Get_Crop(params)
      .then(function (res) {
        const data = res.data;
        if (data.length > 0) {
          for (const item of data) {
            cropoptions.push({
              label: item.name,
              value: item.name,
            });
          }
        }
      })
      .catch((error) => {
        console.error("查询请求失败:", error);
      });
  } catch (error) {
    console.error(error);
  }

  //当天的天气
  try {
    let params = {
      farm_id: global_var.farmid,
    };
    await Get_Todays_Weather(params)
      .then(function (res) {
        const data = res.data;
        console.log("当天天气：" + data);
        weather.天气 = data[0].weather_Info;
        weather.最高温 = data[0].high_Temp;
        weather.最低温 = data[0].low_Temp;
        weather.湿度 = data[0].humidity;
        weather.降雨量 = data[0].precipitation;
        weather.最大风速 = data[0].wind;
      })
      .catch((error) => {
        console.error("查询请求失败:", error);
      });
  } catch (error) {
    console.error(error);
  }

  //历史种植
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await find_history_crop(params)
      .then(function (res) {
        const data = res.data;
        if (data.length > 0) {
          for (const item of data) {
            historyCropData.push({
              date:
                item.start_date.split("T")[0] +
                "~" +
                item.end_date.split("T")[0],
              name: item.name,
              type: item.crop_type,
              admin: item.technologist_name,
            });
          }
        }
      })
      .catch((error) => {
        console.error("查询请求失败:", error);
      });
  } catch (error) {
    console.error(error);
  }

  //当前事项
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await GetIssuesByFieldId(params).then(function (res) {
      const data = res.data;
      if (data.length > 0) {
        for (const item of data) {
          if (item.activityId) {
            try {
              let params = {
                activity_id: item.activityId,
              };
              GetActivitiesByActivityId(params).then(function (res) {
                const innerdata = res.data;
                if (item.end_Date) {
                  //已解决
                  if (item.harvestid == 0) {
                    issueinfo.push({
                      id: item.issue_Id,
                      type: item.type,
                      state: "已解决",
                      desc: item.detail,
                      issueadmin: item.technologistName,
                      starttime: item.start_Date.replace("T", " "),
                      toolType:
                        innerdata[0].consumablesType == null
                          ? ""
                          : innerdata[0].consumablesType,
                      toolName:
                        innerdata[0].consumablesName == null
                          ? ""
                          : innerdata[0].consumablesName,
                      toolNum:
                        innerdata[0].amount == null ? "" : innerdata[0].amount,
                      equipType:
                        innerdata[0].technologistType == null
                          ? ""
                          : innerdata[0].technologistType,
                      equipName:
                        innerdata[0].equipmentName == null
                          ? ""
                          : innerdata[0].equipmentName,
                      handletime: item.address_Date.replace("T", " "),
                      handleDesc: innerdata[0].detail,
                      handleadmin: innerdata[0].technologistName,
                      endtime: item.end_Date.replace("T", " "),
                      teji: "",
                      tejiwarehouse: "",
                      yiji: "",
                      yijiwarehouse: "",
                      erji: "",
                      erjiwarehouse: "",
                      harvestid: item.harvestid,
                      toolLeft: 10086,
                    });
                  } else {
                    try {
                      let params = {
                        harvest_id: item.harvestid,
                      };
                      Get_Harvest_Info(params).then(function (res) {
                        const hardata = res.data;
                        let tempteji = "";
                        let tempyiji = "";
                        let temperji = "";
                        for (const har of hardata) {
                          if (har.quality == "特级") {
                            tempteji = har.weight;
                          } else if (har.quality == "一级") {
                            tempyiji = har.weight;
                          } else if (har.quality == "二级") {
                            temperji = har.weight;
                          }
                        }
                        issueinfo.push({
                          id: item.issue_Id,
                          type: item.type,
                          state: "已解决",
                          desc: item.detail,
                          issueadmin: item.technologistName,
                          starttime: item.start_Date.replace("T", " "),
                          toolType:
                            innerdata[0].consumablesType == null
                              ? ""
                              : innerdata[0].consumablesType,
                          toolName:
                            innerdata[0].consumablesName == null
                              ? ""
                              : innerdata[0].consumablesName,
                          toolNum:
                            innerdata[0].amount == null
                              ? ""
                              : innerdata[0].amount,
                          equipType:
                            innerdata[0].technologistType == null
                              ? ""
                              : innerdata[0].technologistType,
                          equipName:
                            innerdata[0].equipmentName == null
                              ? ""
                              : innerdata[0].equipmentName,
                          handletime: item.address_Date.replace("T", " "),
                          handleDesc: innerdata[0].detail,
                          handleadmin: innerdata[0].technologistName,
                          endtime: item.end_Date.replace("T", " "),
                          teji: tempteji,
                          tejiwarehouse: "",
                          yiji: tempyiji,
                          yijiwarehouse: "",
                          erji: temperji,
                          erjiwarehouse: "",
                          harvestid: item.harvestid,
                          toolLeft: 10086,
                        });
                      });
                    } catch (error) {
                      console.error(error);
                    }
                  }
                } else {
                  //解决中
                  issueinfo.push({
                    id: item.issue_Id,
                    type: item.type,
                    state: "解决中",
                    desc: item.detail,
                    issueadmin: item.technologistName,
                    starttime: item.start_Date.replace("T", " "),
                    toolType:
                      innerdata[0].consumablesType == null
                        ? ""
                        : innerdata[0].consumablesType,
                    toolName:
                      innerdata[0].consumablesName == null
                        ? ""
                        : innerdata[0].consumablesName,
                    toolNum: "",
                    equipType:
                      innerdata[0].technologistType == null
                        ? ""
                        : innerdata[0].technologistType,
                    equipName:
                      innerdata[0].equipmentName == null
                        ? ""
                        : innerdata[0].equipmentName,
                    handletime: item.address_Date.replace("T", " "),
                    handleDesc: "",
                    handleadmin: innerdata[0].technologistName,
                    endtime: "",
                    teji: "",
                    tejiwarehouse: "",
                    yiji: "",
                    yijiwarehouse: "",
                    erji: "",
                    erjiwarehouse: "",
                    harvestid: 0,
                    toolLeft:
                      innerdata[0].consumablesStock == null
                        ? ""
                        : innerdata[0].consumablesStock,
                  });
                }
              });
            } catch (error) {
              console.error(error);
            }
          } else {
            issueinfo.push({
              id: item.issue_Id,
              type: item.type,
              state: "待解决",
              desc: item.detail,
              issueadmin: item.technologistName,
              starttime: item.start_Date.replace("T", " "),
              toolType: "",
              toolName: "",
              toolNum: "",
              equipType: "",
              equipName: "",
              handletime: "",
              handleDesc: "",
              handleadmin: "",
              endtime: "",
              teji: "",
              tejiwarehouse: "",
              yiji: "",
              yijiwarehouse: "",
              erji: "",
              erjiwarehouse: "",
              harvestid: 0,
              toolLeft: 10086,
            });
          }
        }
      }
    });
  } catch (error) {
    console.error(error);
  }
  //获取地图需要的信息
  try {
    let res = await Get_All_Farm();
    farmList.value = res.data;
    for (const item of farmList.value) {
      let params = {
        farm_id: item.farm_Id,
      };
      await Get_Fields_By_Farm(params).then(function (res) {
        item.fieldList = res.data;
      });
      item.farmLocation = [116, 39]; //默认坐标
      if (item.fieldList.length != 0) {
        item.farmLocation = [
          item.fieldList[0].vertex1_Longitude,
          item.fieldList[0].vertex1_Latitude,
        ];
        if (
          item.farmLocation[0] < -180 ||
          item.farmLocation[1] < -85 ||
          item.farmLocation[0] > 180 ||
          item.farmLocation[1] > 85
        ) {
          item.farmLocation = [116, 39]; //经纬度出错则改为默认坐标
        }
      }
    }
    console.log(farmList);
  } catch (error) {
    console.error(error);
  }
  initMap(); //初始化地图
  finish.value = true;
};
//对话框信息

const s1FormVisible = ref(false);
const s2FormVisible = ref(false);
const s3FormVisible = ref(false);

const issueFormVisible = ref(false);
const harvestissueFormVisible = ref(false);
const singleissue = reactive({
  type: "",
  desc: "",
});

const soilFormVisible = ref(false);
const soilFormLabelWidth = "80px";
const singlesoil = reactive({
  location: soilinfo.location,
  类型: soilinfo.类型,
  pH值: soilinfo.pH值,
  photo: soilinfo.photo,
});

const harvestFormVisible = ref(false);
const harvestFormLabelWidth = "60px";
const singleharvest = reactive({
  teji: "",
  tejiwarehouse: "",
  yiji: "",
  yijiwarehouse: "",
  erji: "",
  erjiwarehouse: "",
  admin: nowadmin.value,
});

const cropTableVisible = ref(false);

const chooseFormVisible = ref(false);

const singlehandle1 = reactive({
  toolType: "",
  toolName: "",
  toolNum: 0,
  equipType: "",
  equipName: "",
});

const singlehandle2 = reactive({
  desc: "",
});

const select = reactive({
  name: "",
  state: "",
  crop: "",
  soil: "",
  leftpH: "",
  rightpH: "",
});

const newcrop = reactive({
  name: "",
  type: "",
  soil: "",
  pH: "",
});

const seniorFormVisible = ref(false);
//统计图信息

//地图信息

const farmList = ref([]); //地图需要的信息初始化
let AMap = null;
let map = null;
const polygons = ref([[]]); //多边形覆盖物用于展示地图上农田信息
const polygonsText = ref([[]]); //用于展示地图上农田名字文本框

const addFieldInMap = (farmIdNum, data) => {
  //添加多边形覆盖物
  for (let i = 0; i < farmList.value.length; i++) {
    if (farmList.value[i].farm_Id == farmIdNum) {
      let tempLocationArr = [
        [data.vertex1_Longitude, data.vertex1_Latitude],
        [data.vertex2_Longitude, data.vertex2_Latitude],
        [data.vertex3_Longitude, data.vertex3_Latitude],
        [data.vertex4_Longitude, data.vertex4_Latitude],
      ];
      polygons.value[i].push(
        new AMap.Polygon({
          path: tempLocationArr,
          strokeColor: "#FF33FF",
          strokeWeight: 6,
          strokeOpacity: 0.2,
          fillOpacity: 0.4,
          fillColor: "#1791fc",
          zIndex: 50,
          bubble: true,
        })
      );
      var tmp_center = getPointsCenter(tempLocationArr);
      polygonsText.value[i].push(
        new AMap.Text({
          text: data.name,
          anchor: "center", // 设置文本标记锚点
          cursor: "default",
          style: {
            padding: ".3rem .5rem",
            "margin-bottom": "1rem",
            "border-radius": ".25rem",
            background: "transparent",
            width: "5rem",
            "border-width": 0,
            "text-align": "center",
            "font-size": "10px",
            color: "white",
          },
          position: tmp_center,
        })
      );
      //多边形覆盖物触发的事件
      let j = polygons.value[i].length - 1;
      // 双击
      polygons.value[i][j].on("dblclick", () => {});
      //单击
      polygons.value[i][j].on("click", () => {
        global_var.farmid = farmList.value[i].farm_Id;
        global_var.fieldid = farmList.value[i].fieldList[j].field_Id;
        seniorFormVisible.value = false;
        onMountedLogic();
        currentSelection.value = "null";
      });

      // 鼠标移入更改样式
      polygons.value[i][j].on("mouseover", () => {
        polygons.value[i][j].setOptions({
          fillOpacity: 0.7,
          fillColor: "#7bccc4",
        });
      });

      // 鼠标移出恢复样式
      polygons.value[i][j].on("mouseout", () => {
        polygons.value[i][j].setOptions({
          fillOpacity: 0.4,
          fillColor: "#1791fc",
        });
      });
      //单击(Text)
      polygonsText.value[i][polygonsText.value[i].length - 1].on(
        "click",
        () => {
          global_var.farmid = farmList.value[i].farm_Id;
          global_var.fieldid = farmList.value[i].fieldList[j].field_Id;
          console.log("global_var.fieldid:", global_var.fieldid);
          // map.setFitView(polygons.value[i][j])
          seniorFormVisible.value = false;
          onMountedLogic();
          currentSelection.value = "null";
        }
      );
      // 鼠标移入更改样式(Text)
      polygonsText.value[i][polygonsText.value[i].length - 1].on(
        "mouseover",
        () => {
          polygons.value[i][j].setOptions({
            fillOpacity: 0.7,
            fillColor: "#7bccc4",
          });
        }
      );
      // 鼠标移出恢复样式(Text)
      polygonsText.value[i][polygonsText.value[i].length - 1].on(
        "mouseout",
        () => {
          polygons.value[i][j].setOptions({
            fillOpacity: 0.4,
            fillColor: "#1791fc",
          });
        }
      );
      map.add([polygons.value[i][j]]);
      map.add([polygonsText.value[i][polygonsText.value[i].length - 1]]);
      break;
    }
  }
};

//获取复数个点坐标中心位置
const getPointsCenter = (points) => {
  var point_num = points.length; //坐标点个数
  var X = 0,
    Y = 0,
    Z = 0;
  for (let i = 0; i < points.length; i++) {
    let point = points[i];
    X += point[0];
    Y += point[1];
  }
  X = X / point_num;
  Y = Y / point_num;
  return [X, Y];
};
const initMap = () => {
  polygons.value.length = 0;
  polygonsText.value.length = 0;
  AMapLoader.load({
    key: "48a10a5361d2ac9096e427d84fa9fede", //此处填入我们注册账号后获取的Key
    version: "2.0", //指定要加载的 JSAPI 的版本，缺省时默认为 1.4.15
    plugins: [
      "AMap.Polygon",
      "AMap.PolyEditor",
      "AMap.PolygonEditor",
      "AMap.Scale",
      "AMap.PolygonEditor",
      "AMap.ToolBar",
      "AMap.PlaceSearch",
      "AMap.AutoComplete",
      "AMap.Geocoder",
    ], //需要使用的的插件列表，如比例尺'AMap.Scale'等
  })
    .then((myMap) => {
      AMap = myMap;
      //地图
      map = new AMap.Map("container", {
        //设置地图容器id
        viewMode: "2D", //是否为3D地图模式
        zoom: 8.8, //初始化地图级别
        center: [116.400274, 39.905812], //初始化地图中心点位置
      });
      //卫星图
      var weixing = new AMap.TileLayer.Satellite({
        zIndex: 10,
      });
      map.add(weixing);
      map.addControl(new AMap.Scale()); //比例尺
      map.setStatus({ zoomEnable: true }); //控制地图是否可放大
      map.setStatus({ dragEnable: true, keyboardEnable: false }); //控制地图是否可以平移

      //同级位置添加相关代码即可

      //添加农场对应的点覆盖物和多边形覆盖物
      for (const item of farmList.value) {
        //添加多边形覆盖物
        polygons.value[polygons.value.length] = new Array();
        polygonsText.value[polygonsText.value.length] = new Array();
        for (const temp of item.fieldList) {
          addFieldInMap(item.farm_Id, temp);
        }
      }
      //加个这个
      console.log(polygonsText.value);
      for (let i = 0; i < farmList.value.length; i++) {
        if (farmList.value[i].farm_Id == global_var.farmid) {
          for (let j = 0; j < farmList.value[i].fieldList.length; j++) {
            if (farmList.value[i].fieldList[j].field_Id == global_var.fieldid) {
              map.setFitView(
                polygons.value[i][j],
                true,
                [60, 60, 60, 60],
                16.7
              ); //选中田地重绑事件
              polygons.value[i][j].setOptions({
                fillOpacity: 0.4,
                fillColor: "#F08080",
              });
              polygons.value[i][j].on("mouseout", () => {
                polygons.value[i][j].setOptions({
                  fillOpacity: 0.4,
                  fillColor: "#F08080",
                });
              });
              polygonsText.value[i][polygonsText.value[i].length - 1].on(
                "mouseout",
                () => {
                  polygons.value[i][j].setOptions({
                    fillOpacity: 0.4,
                    fillColor: "#F08080",
                  });
                }
              );
            }
          }
        }
      }
    })
    .catch((e) => {
      console.log(e);
    });
};

onMounted(async () => {
  //保证先打开哪个管理界面都能加载
  if (global_var.fieldid == -1) {
    try {
      await Get_All_Farm().then(function (res) {
        const data = res.data;
        if (global_var.farmid == -1) {
          global_var.farmid = data[0].farm_Id;
        }
      });
    } catch (error) {
      console.error(error);
    }

    try {
      let params = {
        farm_id: global_var.farmid,
      };
      await Get_Fields_By_Farm(params).then(function (res) {
        const data = res.data;
        if (data.length != 0) {
          global_var.fieldid = data[0].field_Id;
        }
      });
    } catch (error) {
      console.error(error);
    }
  }

  //田地名称、位置、土壤、pH
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await Get_Farm_Fields(params).then(function (res) {
      const data = res.data;
      console.log(data);
      fieldinfo.id = global_var.fieldid;
      fieldinfo.name = data[0].farmName;
      fieldinfo.location = data[0].fieldName;
      fieldinfo.planting_id = data[0].planting_Id;
      soilinfo.location = data[0].fieldName;
      soilinfo.类型 = data[0].soilType;
      soilinfo.pH值 = data[0].phLevel;
      soilinfo.photo = data[0].photo;
      singlesoil.location = data[0].fieldName;
      singlesoil.类型 = data[0].soilType;
      singlesoil.pH值 = data[0].phLevel;
      singlesoil.photo = data[0].photo;
      imageUrl.value = data[0].photo;
    });
  } catch (error) {
    console.error(error);
  }

  //田地当前种植作物
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await Find_Current_Crop(params)
      .then(function (res) {
        const data = res.data;
        if (data.length > 0) {
          cropinfo.名称 = data[0].name;
          cropinfo.种类 = data[0].crop_type;
          cropinfo.适宜土壤 = data[0].soil_type;
          cropinfo.适宜pH值 = data[0].low_ph + "~" + data[0].high_ph;
          cropinfo.开始种植时间 = data[0].start_date.replace("T", " ");
          cropinfo.种植负责人 = data[0].technologist_name;
        }
      })
      .catch((error) => {
        console.error("查询请求失败:", error);
      });
  } catch (error) {
    console.error(error);
  }

  //统计图的天气
  try {
    let params = {
      farm_id: global_var.farmid,
      mode: 3,
    };
    await Get_Issue_Static(params).then(function (res) {
      const data = res.data;
      //for (const item of data)
      //search.value.series[0].data.push(data[0]);
      console.log(data);
      issueoption.value.series[0].data = [];
      for (const item of data) {
        issueoption.value.series[0].data.push({
          name: item.type,
          value: item.count,
        });
      }
    });
    await Get_Weather(params).then(function (res) {
      const data = res.data;
      if (data.length > 0) {
        const reversed = data.slice().reverse();
        tempoption.value.xAxis.data.length = 0;
        tempoption.value.series[0].data.length = 0;
        tempoption.value.series[1].data.length = 0;
        humidityoption.value.xAxis.data.length = 0;
        humidityoption.value.series[0].data.length = 0;
        rainoption.value.xAxis.data.length = 0;
        rainoption.value.series[0].data.length = 0;
        windoption.value.xAxis.data.length = 0;
        windoption.value.series[0].data.length = 0;
        if (data.length >= 0 + 3 * 9) {
          for (let i = 0 + 3 * 9; i >= 0; i -= 3) {
            rainoption.value.xAxis.data.push(
              reversed[i].record_Date.split("T")[0]
            );
            rainoption.value.series[0].data.push(reversed[i].precipitation);
          }
        }
        for (const item of data) {
          tempoption.value.xAxis.data.push(item.record_Date.split("T")[0]);
          tempoption.value.series[0].data.push(item.high_Temp);
          tempoption.value.series[1].data.push(item.low_Temp);
          humidityoption.value.xAxis.data.push(item.record_Date.split("T")[0]);
          humidityoption.value.series[0].data.push(item.humidity);
          windoption.value.xAxis.data.push(item.record_Date.split("T")[0]);
          windoption.value.series[0].data.push(item.wind);
        }
      }
    });
  } catch (error) {
    console.error(error);
  }

  //田地最新收获
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await Get_Current_Harvest(params)
      .then(function (res) {
        const data = res.data;
        if (data.length > 0) {
          for (const item of data) {
            harvestinfo.push({
              date: item.harvest_date.split("T")[0],
              quality: item.quality,
              quantity: item.weight + "kg",
              admin: item.technologist_name,
            });
          }
        }
      })
      .catch((error) => {
        console.error("查询请求失败:", error);
      });
  } catch (error) {
    console.error(error);
  }

  //高级筛选的农场列表
  try {
    await Get_All_Farm().then(function (res) {
      const data = res.data;
      for (const item of data) {
        farmoptions.push({
          label: item.name,
          value: item.name,
        });
      }
    });
  } catch (error) {
    console.error(error);
  }

  //高级筛选的作物列表
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await Get_Crop(params).then(function (res) {
      const data = res.data;
      if (data.length > 0) {
        for (const item of data) {
          cropoptions.push({
            label: item.name,
            value: item.name,
          });
        }
      }
    });
  } catch (error) {
    console.error(error);
  }

  //当天的天气
  try {
    let params = {
      farm_id: global_var.farmid,
    };
    await Get_Todays_Weather(params)
      .then(function (res) {
        const data = res.data;
        console.log("当天天气：" + data);
        weather.天气 = data[0].weather_Info;
        weather.最高温 = data[0].high_Temp;
        weather.最低温 = data[0].low_Temp;
        weather.湿度 = data[0].humidity;
        weather.降雨量 = data[0].precipitation;
        weather.最大风速 = data[0].wind;
      })
      .catch((error) => {
        console.error("查询请求失败:", error);
      });
  } catch (error) {
    console.error(error);
  }

  //历史种植
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await find_history_crop(params)
      .then(function (res) {
        const data = res.data;
        if (data.length > 0) {
          for (const item of data) {
            historyCropData.push({
              date:
                item.start_date.split("T")[0] +
                "~" +
                item.end_date.split("T")[0],
              name: item.name,
              type: item.crop_type,
              admin: item.technologist_name,
            });
          }
        }
      })
      .catch((error) => {
        console.error("查询请求失败:", error);
      });
  } catch (error) {
    console.error(error);
  }

  //当前事项
  try {
    let params = {
      field_id: global_var.fieldid,
    };
    await GetIssuesByFieldId(params).then(function (res) {
      const data = res.data;
      if (data.length > 0) {
        for (const item of data) {
          if (item.activityId) {
            try {
              let params = {
                activity_id: item.activityId,
              };
              GetActivitiesByActivityId(params).then(function (res) {
                const innerdata = res.data;
                if (item.end_Date) {
                  //已解决
                  if (item.harvestid == 0) {
                    issueinfo.push({
                      id: item.issue_Id,
                      type: item.type,
                      state: "已解决",
                      desc: item.detail,
                      issueadmin: item.technologistName,
                      starttime: item.start_Date.replace("T", " "),
                      toolType:
                        innerdata[0].consumablesType == null
                          ? ""
                          : innerdata[0].consumablesType,
                      toolName:
                        innerdata[0].consumablesName == null
                          ? ""
                          : innerdata[0].consumablesName,
                      toolNum:
                        innerdata[0].amount == null ? "" : innerdata[0].amount,
                      equipType:
                        innerdata[0].technologistType == null
                          ? ""
                          : innerdata[0].technologistType,
                      equipName:
                        innerdata[0].equipmentName == null
                          ? ""
                          : innerdata[0].equipmentName,
                      handletime: item.address_Date.replace("T", " "),
                      handleDesc: innerdata[0].detail,
                      handleadmin: innerdata[0].technologistName,
                      endtime: item.end_Date.replace("T", " "),
                      teji: "",
                      tejiwarehouse: "",
                      yiji: "",
                      yijiwarehouse: "",
                      erji: "",
                      erjiwarehouse: "",
                      harvestid: item.harvestid,
                      toolLeft: 10086,
                    });
                  } else {
                    try {
                      let params = {
                        harvest_id: item.harvestid,
                      };
                      Get_Harvest_Info(params).then(function (res) {
                        const hardata = res.data;
                        let tempteji = "";
                        let tempyiji = "";
                        let temperji = "";
                        for (const har of hardata) {
                          if (har.quality == "特级") {
                            tempteji = har.weight;
                          } else if (har.quality == "一级") {
                            tempyiji = har.weight;
                          } else if (har.quality == "二级") {
                            temperji = har.weight;
                          }
                        }
                        issueinfo.push({
                          id: item.issue_Id,
                          type: item.type,
                          state: "已解决",
                          desc: item.detail,
                          issueadmin: item.technologistName,
                          starttime: item.start_Date.replace("T", " "),
                          toolType:
                            innerdata[0].consumablesType == null
                              ? ""
                              : innerdata[0].consumablesType,
                          toolName:
                            innerdata[0].consumablesName == null
                              ? ""
                              : innerdata[0].consumablesName,
                          toolNum:
                            innerdata[0].amount == null
                              ? ""
                              : innerdata[0].amount,
                          equipType:
                            innerdata[0].technologistType == null
                              ? ""
                              : innerdata[0].technologistType,
                          equipName:
                            innerdata[0].equipmentName == null
                              ? ""
                              : innerdata[0].equipmentName,
                          handletime: item.address_Date.replace("T", " "),
                          handleDesc: innerdata[0].detail,
                          handleadmin: innerdata[0].technologistName,
                          endtime: item.end_Date.replace("T", " "),
                          teji: tempteji,
                          tejiwarehouse: "",
                          yiji: tempyiji,
                          yijiwarehouse: "",
                          erji: temperji,
                          erjiwarehouse: "",
                          harvestid: item.harvestid,
                          toolLeft: 10086,
                        });
                      });
                    } catch (error) {
                      console.error(error);
                    }
                  }
                } else {
                  //解决中
                  issueinfo.push({
                    id: item.issue_Id,
                    type: item.type,
                    state: "解决中",
                    desc: item.detail,
                    issueadmin: item.technologistName,
                    starttime: item.start_Date.replace("T", " "),
                    toolType:
                      innerdata[0].consumablesType == null
                        ? ""
                        : innerdata[0].consumablesType,
                    toolName:
                      innerdata[0].consumablesName == null
                        ? ""
                        : innerdata[0].consumablesName,
                    toolNum: "",
                    equipType:
                      innerdata[0].technologistType == null
                        ? ""
                        : innerdata[0].technologistType,
                    equipName:
                      innerdata[0].equipmentName == null
                        ? ""
                        : innerdata[0].equipmentName,
                    handletime: item.address_Date.replace("T", " "),
                    handleDesc: "",
                    handleadmin: innerdata[0].technologistName,
                    endtime: "",
                    teji: "",
                    tejiwarehouse: "",
                    yiji: "",
                    yijiwarehouse: "",
                    erji: "",
                    erjiwarehouse: "",
                    harvestid: 0,
                    toolLeft:
                      innerdata[0].consumablesStock == null
                        ? ""
                        : innerdata[0].consumablesStock,
                  });
                }
              });
            } catch (error) {
              console.error(error);
            }
          } else {
            issueinfo.push({
              id: item.issue_Id,
              type: item.type,
              state: "待解决",
              desc: item.detail,
              issueadmin: item.technologistName,
              starttime: item.start_Date.replace("T", " "),
              toolType: "",
              toolName: "",
              toolNum: "",
              equipType: "",
              equipName: "",
              handletime: "",
              handleDesc: "",
              handleadmin: "",
              endtime: "",
              teji: "",
              tejiwarehouse: "",
              yiji: "",
              yijiwarehouse: "",
              erji: "",
              erjiwarehouse: "",
              harvestid: 0,
              toolLeft: 10086,
            });
          }
        }
      }
    });
  } catch (error) {
    console.error(error);
  }
  //获取地图需要的信息
  farmList.value.length = 0;
  try {
    let res = await Get_All_Farm();
    farmList.value = res.data;
    for (const item of farmList.value) {
      let params = {
        farm_id: item.farm_Id,
      };
      await Get_Fields_By_Farm(params).then(function (res) {
        item.fieldList = res.data;
      });
      item.farmLocation = [116, 39]; //默认坐标
      if (item.fieldList.length != 0) {
        item.farmLocation = [
          item.fieldList[0].vertex1_Longitude,
          item.fieldList[0].vertex1_Latitude,
        ];
        if (
          item.farmLocation[0] < -180 ||
          item.farmLocation[1] < -85 ||
          item.farmLocation[0] > 180 ||
          item.farmLocation[1] > 85
        ) {
          item.farmLocation = [116, 39]; //经纬度出错则改为默认坐标
        }
      }
    }
    console.log(farmList);
  } catch (error) {
    console.error(error);
  }
  initMap(); //初始化地图
  nowadmin.value = store.token.name;
  singleharvest.admin = nowadmin.value;
  finish.value = true;
});
</script>
  

<style>
#fieldpage {
  margin-left: 5%;
}

#fieldpage-loading {
  margin-left: 5%;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.search-container {
  display: flex;
  align-items: center;
}

.innerbox {
  flex-shrink: 0;
  display: flex;
  /*justify-content: center;*/
  height: 150px;
  width: 120px;
  margin: 12px;
  /*text-align: center;*/
}

.card-container {
  display: flex;
  align-items: center;
}

.dialog-footer button:first-child {
  margin-right: 10px;
}

.left-aligned-label .el-form-item__label {
  justify-content: flex-start;
}

.card-bottom-btn {
  position: relative;
}

#card-btn {
  position: absolute;
  top: 55px;
  left: 65px;
}

.two-side {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.between-side {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
}

.side-icon {
  height: 25px;
  width: 25px;
  margin-right: 10px;
}

.center-text {
  display: flex;
  justify-content: center;
  align-items: center;
}

.chart {
  height: 300px;
}

.red {
  color: red;
  background-color: lightcoral;
  border: 2px solid red;
  border-radius: 5px;
  width: 50px;
}

.orange {
  color: orange;
  background-color: khaki;
  border: 2px solid orange;
  border-radius: 5px;
  width: 50px;
}

.green {
  color: green;
  background-color: lightgreen;
  border: 2px solid green;
  border-radius: 5px;
  width: 50px;
}

.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}

.avatar {
  width: 178px;
  height: 178px;
  display: block;
}

.el-image {
  padding: 0 5px;
  width: 500px;
  height: 300px;
}

.image-slot {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  background: var(--el-fill-color-light);
  color: var(--el-text-color-secondary);
  font-size: 30px;
}

.image-slot .el-icon {
  font-size: 50px;
}
/* 地图 */
#container {
  float: left;
  width: 500px;
  height: 300px;
}
/* 隐藏高德logo  */
.amap-logo {
  display: none !important;
}
/* 隐藏高德版权  */
.amap-copyright {
  display: none !important;
}
</style>