<template>
  <div id="farmpage" v-if="finish">
    <div>
      <el-row :gutter="10">
        <el-col :span="21" :offset="2">
          <el-card class="box-card">
            <template #header>
              <div class="card-header">
                <div>
                  <span>农场信息</span><br />
                  <span>{{ farminfo.name }}</span
                  >&nbsp;&nbsp;&nbsp;
                  <span>
                    <el-icon>
                      <location-information />
                    </el-icon>
                    {{ farminfo.location }}
                  </span>
                </div>
                <div class="search-container">
                  <el-select
                    v-model="input"
                    placeholder="请选择农场"
                    style="width: 100%"
                  >
                    <el-option
                      v-for="item in farmoptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    />
                  </el-select>
                  <el-button
                    class="button"
                    text
                    @click="farminfoFormVisible = true"
                    >修改农场</el-button
                  >
                  <el-button
                    class="button"
                    text
                    @click="
                      farmFormVisible = true;
                      this.$nextTick(() => {
                        makeMapFarm();
                      });
                    "
                    >添加农场</el-button
                  >
                </div>
              </div>
            </template>
            <!-- 添加地图 -->
            <div class="two-side">
              <div id="container1"></div>
              <div id="container2"></div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
    <br />
    <div>
      <el-row :gutter="10">
        <el-col :span="21" :offset="2">
          <div>
            <el-card class="box-card">
              <template #header>
                <div class="card-header">
                  <span>田地信息</span>
                  <el-button
                    class="button"
                    text
                    @click="
                      fieldFormVisible = true;
                      this.$nextTick(() => {
                        makeMap3();
                      });
                    "
                    >添加田地</el-button
                  >
                </div>
              </template>
              <div>
                <el-table
                  :data="fieldData"
                  height="250"
                  highlight-current-row
                  @current-change="handleFieldCurrentChange"
                >
                  <el-table-column
                    property="name"
                    label="名称"
                    sortable
                    :sort-method="customSortByName"
                  />
                  <el-table-column
                    property="state"
                    label="状态"
                    sortable
                    :sort-method="customSortByState"
                  />
                  <el-table-column
                    property="crop"
                    label="作物"
                    sortable
                    :sort-method="customSortByCrop"
                  />
                  <el-table-column
                    property="soil"
                    label="土壤"
                    sortable
                    :sort-method="customSortBysoil"
                  />
                  <el-table-column
                    property="ph"
                    label="pH值"
                    sortable
                    :sort-method="customSortByPh"
                  />
                </el-table>
              </div>
            </el-card>
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
  <div
    id="farmpage-loading"
    v-else
    v-loading="!finish"
    :element-loading-svg="svg"
    class="custom-loading-svg"
    element-loading-svg-view-box="-10, -10, 50, 50"
  ></div>

  <!--新版添加农场对话框-->
  <el-scrollbar>
    <el-dialog
      v-model="farmFormVisible"
      title="添加农场"
      width="30%"
      center
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
    >
      <el-form :model="singlefarm">
        <el-form-item
          label="农场名称"
          :label-width="farmFormLabelWidth"
          class="left-aligned-label"
        >
          <el-input v-model="singlefarm.name" autocomplete="off" />
        </el-form-item>
        <el-form-item
          label="农场位置"
          :label-width="farmFormLabelWidth"
          class="left-aligned-label"
        >
          <el-input
            id="mapInput"
            v-model="singlefarm.location"
            type="text"
            style="width: 80%;"
            onfocus='this.value=""'
            placeholder="请输入地址"
          />
          <div style="width: 5%;"></div>
          <el-button type="primary" @click="searchLocation" style="width: 15%;"> 搜索 </el-button>
        </el-form-item>
        <!-- 设置地图容器 -->
        <div id="containerFarm"></div>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button
            @click="
              farmFormVisible = false;
              singlefarm.name = '';
              singlefarm.location = '';
              singlefarm.fieldName = '';
              singlefarm.soilType = '';
              singlefarm.pH = '';
              singlefarm.p1LON = '';
              singlefarm.p1LAT = '';
              singlefarm.p2LON = '';
              singlefarm.p2LAT = '';
              singlefarm.p3LON = '';
              singlefarm.p3LAT = '';
              singlefarm.p4LON = '';
              singlefarm.p4LAT = '';
            "
            >取消</el-button
          >
          <el-button
            type="primary"
            @click="
              addFarminfo();
              this.$nextTick(() => {
                makeMap3();
              });
            "
          >
            确认
          </el-button>
        </span>
      </template>
    </el-dialog>
  </el-scrollbar>

  <!--添加田地对话框-->
  <el-scrollbar>
    <el-dialog
      v-model="fieldFormVisible"
      title="添加田地"
      width="30%"
      center
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
    >
      <el-form :model="singlefield">
        <el-form-item
          label="田地名称"
          :label-width="fieldFormLabelWidth"
          class="left-aligned-label"
        >
          <el-input v-model="singlefield.fieldName" autocomplete="off" />
        </el-form-item>
        <el-form-item
          label="土壤类型"
          :label-width="fieldFormLabelWidth"
          class="left-aligned-label"
        >
          <el-select
            v-model="singlefield.soilType"
            placeholder="请选择土壤类型"
            style="width: 100%"
          >
            <el-option label="红壤" value="红壤" />
            <el-option label="棕壤" value="棕壤" />
            <el-option label="褐土" value="褐土" />
            <el-option label="黑土" value="黑土" />
            <el-option label="栗钙土" value="栗钙土" />
            <el-option label="漠土" value="漠土" />
            <el-option label="潮土" value="潮土" />
            <el-option label="湿土" value="湿土" />
            <el-option label="水稻土" value="水稻土" />
            <el-option label="盐碱土" value="盐碱土" />
            <el-option label="岩性土" value="岩性土" />
            <el-option label="高山土" value="高山土" />
          </el-select>
        </el-form-item>
        <el-form-item
          label="土壤pH值"
          :label-width="fieldFormLabelWidth"
          class="left-aligned-label"
        >
          <el-input v-model="singlefield.pH" autocomplete="off" />
        </el-form-item>
        <el-form-item
          label="田地位置"
          :label-width="farmFormLabelWidth"
          class="left-aligned-label"
        >
          <!-- map3可视化添加 -->
          <div id="container3"></div>
          <el-button type="primary" @click="openEditPolygon()">
            编辑
          </el-button>
          <el-button type="primary" @click="closeEditPolygon()">
            确定
          </el-button>
        </el-form-item>
        <el-form-item
          label="照片"
          :label-width="fieldFormLabelWidth"
          class="left-aligned-label"
        >
          <el-upload
            ref="upload"
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :http-request="httpRequestFn"
            :on-exceed="handleExceed"
          >
            <img v-if="imageUrl" :src="imageUrl" class="avatar" />
            <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
          </el-upload>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button
            @click="
              fieldFormVisible = false;
              singlefield.name = '';
              singlefield.location = '';
              singlefield.fieldName = '';
              singlefield.soilType = '';
              singlefield.pH = '';
              singlefield.p1LON = '';
              singlefield.p1LAT = '';
              singlefield.p2LON = '';
              singlefield.p2LAT = '';
              singlefield.p3LON = '';
              singlefield.p3LAT = '';
              singlefield.p4LON = '';
              singlefield.p4LAT = '';
              imageUrl = '';
            "
            v-if="!cancelbtn"
            >取消</el-button
          >
          <el-button type="primary" @click="addfieldinfo(imageUrl)">
            确认
          </el-button>
        </span>
      </template>
    </el-dialog>
  </el-scrollbar>

  <!--修改农场信息对话框-->
  <el-dialog
    v-model="farminfoFormVisible"
    title="编辑信息"
    width="30%"
    center
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    :show-close="false"
  >
    <el-form :model="singlefarminfo">
      <el-form-item label="农场名称" class="left-aligned-label">
        <el-input v-model="singlefarminfo.name" autocomplete="off" />
      </el-form-item>
      <el-form-item label="农场位置" class="left-aligned-label">
        <el-input v-model="singlefarminfo.location" autocomplete="off" />
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button
          @click="
            farminfoFormVisible = false;
            singlefarminfo.name = farminfo.name;
            singlefarminfo.location = farminfo.location;
          "
          >取消</el-button
        >
        <el-button
          type="primary"
          @click="changeFarminfo(singlefarminfo.name, singlefarminfo.location)"
        >
          确认
        </el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup >
import { ref, reactive, onMounted, watch } from "vue";
import { ElMessage } from "element-plus";
import router from "@/router";
import {
  Get_All_Farm,
  Get_Farm_Info,
  Get_Fields_By_Farm,
  Update_Farm,
  Create_Farm,
  Create_Field,
} from "@/api/FarmManagement.js";
import { Get_Filtered_Fields } from "@/api/FieldManagement.js";
import global_var from "@/utils/global_var.js";
import AMapLoader from "@amap/amap-jsapi-loader"; //引入地图
// 设置安全密钥
window._AMapSecurityConfig = {
  securityJsCode: 'bc6447c7c502a1b31195cbb29dd23899',
};

//加载
const svg = `
        <path class="path" d="
          M 30 15
          L 28 17
          M 25.61 25.61
          A 15 15, 0, 0, 1, 15 30
          A 15 15, 0, 1, 1, 27.99 7.5
          L 15 15
        " style="stroke-width: 4px; fill: rgba(0, 0, 0, 0)"/>
      `;

const finish = ref(false);
//输入框及选项按钮
const input = ref("");
const farmoptions = reactive([]);
const cancelbtn = ref(false);

//处理照片上传
const imageUrl = ref("");

const COS = require("cos-js-sdk-v5");

var cos = new COS({
 SecretId: "AKID46yc3GKBoJarz3DJNH4e9QU6XotlNkts",
 SecretKey: "qRp4ADD0qcEfwGVinrkS6hElIj6d7PUL",
});

const httpRequestFn = (res) => {
  cos.putObject(
    {
      Bucket: "dyc-1319697249", // 存储桶
      Region: "ap-shanghai", // 存储桶所在地域
      Key: res.file.name, // 文件名
      StorageClass: "STANDARD", // 上传模式
      Body: res.file, // 上传文件对象
      onProgress: (progressData) => {
        // 进度条
        console.log(JSON.stringify(progressData));
      },
    },
    (err, data) => {
      console.log(err || data);
      if (data) {
        // 上传成功
        imageUrl.value = `http://${data.Location}`;
        console.log(imageUrl.value);
      }
    }
  );
};

const upload = ref(null);
const handleExceed = (files) => {
  upload.value.clearFiles();
  const file = files[0];
  file.uid = Date.now();
  upload.value.handleStart(file);
};

//监视选择器的选项
let hasSelected = false;

watch(input, (newValue, oldValue) => {
  changeFilmView(newValue);
});
//合并监视器和点击地图点覆盖物改变农村的行为函数
const changeFilmView = (value) => {
  if (hasSelected == false) {
    hasSelected = true;
  } else {
    finish.value = false;
    console.log("新农场id:", value);
    global_var.farmid = value;
    onMountedLogic();
  }
};
const onMountedLogic = async () => {
  farmoptions.length = 0;
  fieldData.length = 0;
  global_var.fieldid = -1;
  finish.value = false;

  //农场列表
  try {
    await Get_All_Farm().then(function (res) {
      const data = res.data;
      for (const item of data) {
        farmoptions.push({
          label: item.name,
          value: item.farm_Id,
          id: item.farm_Id,
          location: item.location,
        });
      }
      if (global_var.farmid == -1) {
        global_var.farmid = data[0].farm_Id;
      }
    });
  } catch (error) {
    console.error(error);
  }

  //农场名称和位置
  try {
    let params = {
      farm_id: global_var.farmid,
    };
    await Get_Farm_Info(params).then(function (res) {
      const data = res.data;
      input.value = global_var.farmid;
      farminfo.id = global_var.farmid;
      farminfo.name = data.name;
      farminfo.location = data.location;
      singlefarminfo.name = data.name;
      singlefarminfo.location = data.location;
    });
  } catch (error) {
    console.error(error);
  }

  //田地列表（此处用田地高级搜索）
  try {
    let params = {
      farm_name: farminfo.name,
    };
    await Get_Filtered_Fields(params).then(function (res) {
      const data = res.data;
      console.log(data);
      for (const item of data) {
        fieldData.push({
          id: item.field_Id,
          name: item.name,
          state: item.status == "空" ? "空闲" : "占用",
          crop: item.cropName == null ? "无" : item.cropName,
          soil: item.soil_Type,
          ph: item.ph_Level,
        });
      }
    });
  } catch (error) {
    console.error(error);
  }

  if (global_var.fieldid == -1) {
    //获取第一块田地的id（此处接口用的返回坐标的）
    try {
      let params = {
        farm_id: farminfo.id,
      };
      await Get_Fields_By_Farm(params).then(function (res) {
        const data = res.data;
        if (data.length != 0) {
          global_var.fieldid = data[0].field_Id;
        }
      });
    } catch (error) {
      console.error(error);
    }
  }
  UpdateMap()
  finish.value = true;
};

//初始化
const farminfo = reactive({
  id: null,
  name: null,
  location: null,
});

const customSortByName = (a, b) => {
  return a.name.localeCompare(b.name);
};

const customSortByState = (a, b) => {
  return a.state.localeCompare(b.state);
};

const customSortByCrop = (a, b) => {
  return a.crop.localeCompare(b.crop);
};

const customSortBysoil = (a, b) => {
  return a.soil.localeCompare(b.soil);
};

const customSortByPh = (a, b) => {
  const floatA = parseFloat(a.ph);
  const floatB = parseFloat(b.ph);
  return floatA - floatB;
};

const fieldData = reactive([]);

const addFarminfo = () => {
  if (singlefarm.name === "" || singlefarm.location === "") {
    ElMessage.error("农场信息不完整");
    return;
  }

  farmFormVisible.value = false;

  cancelbtn.value = true;
  fieldFormVisible.value = true;
};

const addfieldinfo = async (photo) => {
  if (
    singlefield.fieldName === "" ||
    singlefield.soilType === "" ||
    singlefield.pH === "" ||
    singlefield.p1LON === "" ||
    singlefield.p1LAT === "" ||
    singlefield.p2LON === "" ||
    singlefield.p2LAT === "" ||
    singlefield.p3LON === "" ||
    singlefield.p3LAT === "" ||
    singlefield.p4LON === "" ||
    singlefield.p4LAT === "" ||
    photo === ""
  ) {
    ElMessage.error("田地信息不完整");
    return;
  }
  let newfarmid = -1;
  let newfieldid = -1;
  if (cancelbtn.value == true) {
    //农场+田地添加

    try {
      let params = {
        farmName: singlefarm.name,
        location: singlefarm.location,
      };
      await Create_Farm(params).then(function (res) {
        const data = res.data;
        newfarmid = data;
        if (data == -1) {
          ElMessage.error("农场添加失败");
          return;
        } else {
          ElMessage({
            type: "success",
            message: "农场添加成功",
          });
        }
      });
    } catch (error) {
      console.error(error);
    }

    farmoptions.push({
      label: singlefarm.name,
      value: newfarmid,
      id: newfarmid,
      location: singlefarm.location,
    });
    try {
      let params = {
        name: singlefield.fieldName,
        farm_id: newfarmid,
        soil_type: singlefield.soilType,
        ph_level: singlefield.pH,
        vertex1_latitude: singlefield.p1LAT,
        vertex1_longitude: singlefield.p1LON,
        vertex2_latitude: singlefield.p2LAT,
        vertex2_longitude: singlefield.p2LON,
        vertex3_latitude: singlefield.p3LAT,
        vertex3_longitude: singlefield.p3LON,
        vertex4_latitude: singlefield.p4LAT,
        vertex4_longitude: singlefield.p4LON,
        photo: photo,
      };
      await Create_Field(params).then(function (res) {
        const data = res.data;
        if (data == -1) {
          ElMessage.error("田地添加失败");
          return;
        } else {
          ElMessage({
            type: "success",
            message: "田地添加成功",
          });
        }
      });
    } catch (error) {
      console.error(error);
    }
    if(newfarmid!=-1){
      changeFilmView(newfarmid);//调整到新农场
      hasSelected = false
    }
  } else {
    //单田地添加

    try {
      let params = {
        name: singlefield.fieldName,
        farm_id: global_var.farmid,
        soil_type: singlefield.soilType,
        ph_level: singlefield.pH,
        vertex1_latitude: singlefield.p1LAT,
        vertex1_longitude: singlefield.p1LON,
        vertex2_latitude: singlefield.p2LAT,
        vertex2_longitude: singlefield.p2LON,
        vertex3_latitude: singlefield.p3LAT,
        vertex3_longitude: singlefield.p3LON,
        vertex4_latitude: singlefield.p4LAT,
        vertex4_longitude: singlefield.p4LON,
        photo: photo,
      };
      await Create_Field(params).then(function (res) {
        const data = res.data;
        newfieldid = data;
        if (data == -1) {
          ElMessage.error("田地添加失败");
          return;
        } else {
          ElMessage({
            type: "success",
            message: "田地添加成功",
          });
        }
      });
    } catch (error) {
      console.error(error);
    }

    fieldData.push({
      id: newfieldid,
      name: singlefield.fieldName,
      state: "空闲",
      crop: "无",
      soil: singlefield.soilType,
      ph: singlefield.pH,
    });
    UpdateMap()
  }
  fieldFormVisible.value = false;
  //清空农场输入
  singlefarm.name = "";
  singlefarm.location = "";
  //清空田地输入
  singlefield.fieldName = "";
  singlefield.soilType = "";
  singlefield.pH = "";
  singlefield.p1LON = "";
  singlefield.p1LAT = "";
  singlefield.p2LON = "";
  singlefield.p2LAT = "";
  singlefield.p3LON = "";
  singlefield.p3LAT = "";
  singlefield.p4LON = "";
  singlefield.p4LAT = "";
  imageUrl.value = "";
  cancelbtn.value = false;
};

const changeFarminfo = async (name, location) => {
  if (name === "" || location === "") {
    ElMessage.error("农场信息不完整");
    return;
  }
  farminfoFormVisible.value = false;
  farminfo.name = singlefarminfo.name;
  farminfo.location = singlefarminfo.location;
  farmoptions.length = 0;
  try {
    let params = {
      farm_id: farminfo.id,
      name: farminfo.name,
      location: farminfo.location,
    };
    await Update_Farm(params).then(function (res) {
      const data = res.data;
      console.log(data);
    });
  } catch (error) {
    console.error(error);
  }

  try {
    await Get_All_Farm().then(function (res) {
      const data = res.data;
      for (const item of data) {
        farmoptions.push({
          label: item.name,
          value: item.farm_Id,
          id: item.farm_Id,
          location: item.location,
        });
      }
    });
  } catch (error) {
    console.error(error);
  }
  
  UpdateMap()
};

const currentFieldSelection = ref("null");

const handleFieldCurrentChange = (val) => {
  if (val === null) {
    return;
  }
  currentFieldSelection.value = val;
  global_var.fieldid = currentFieldSelection.value.id;
  router.push({ path: "/fieldmanagement" });
};

//对话框信息
const farmFormVisible = ref(false);
const farmFormLabelWidth = "80px";
const singlefarm = reactive({
  name: "",
  location: "",
  fieldName: "",
  soilType: "",
  pH: "",
  p1LON: "",
  p1LAT: "",
  p2LON: "",
  p2LAT: "",
  p3LON: "",
  p3LAT: "",
  p4LON: "",
  p4LAT: "",
});

const fieldFormVisible = ref(false);
const fieldFormLabelWidth = "80px";
const singlefield = reactive({
  fieldName: "",
  soilType: "",
  pH: "",
  p1LON: "",
  p1LAT: "",
  p2LON: "",
  p2LAT: "",
  p3LON: "",
  p3LAT: "",
  p4LON: "",
  p4LAT: "",
});

const farminfoFormVisible = ref(false);

const singlefarminfo = reactive({
  name: farminfo.name,
  location: farminfo.location,
});

//地图
//地图变量信息
const farmList = ref([]); //地图需要的信息初始化
const markers = ref([]); //点覆盖物用于标记地图1上农场位置
const polygons = ref([[]]); //多边形覆盖物用于展示地图2上农田信息
const polygonsText = ref([[]]); //用于展示地图2上农田名字文本框
let AMap = null;
let map1 = null;
let map2 = null;
let map3 = null;
let mapFarm = null;
let auto = null;
let singlefarmMarker = null;
let placeSearch = null;
let singlefarmMarkerLocation = [113.65553, 34.748764];
let polygonEditor = null; //map3中添加田地时候的多边形编辑器

//地图用到的函数
//获取复数个点坐标中心位置
const getPointsCenter = (points) => {
  var point_num = points.length; //坐标点个数
  var X = 0,
    Y = 0,
    Z = 0;
  for (let i = 0; i < points.length; i++) {
    let point = points[i];
    X += point[0];
    Y += point[1];
  }
  X = X / point_num;
  Y = Y / point_num;
  return [X, Y];
};
//添加农场时为了准确定位需要使用的地图
const makeMapFarm = () => {
  mapFarm = new AMap.Map("containerFarm", {
    //设置地图容器id
    viewMode: "2D", //  是否为3D地图模式
    zoom: 13, // 初始化地图级别
    center: singlefarmMarkerLocation, //中心点坐标  郑州
    resizeEnable: true,
  });
  mapFarm.addControl(new AMap.Scale()); //比例尺
  mapFarm.setStatus({ zoomEnable: true }); //控制地图是否可放大
  mapFarm.setStatus({ dragEnable: true, keyboardEnable: true }); //控制地图是否可以平移

  // 初始化marker
  setMarker();
  // 初始化逆地理编码
  InverseGeography();

  // 地图点击事件
  mapFarm.on("click", (ev) => {
    if (singlefarmMarker) {
      mapFarm.remove(singlefarmMarker);
      singlefarmMarkerLocation = [ev.lnglat.lng, ev.lnglat.lat];
      console.log(singlefarmMarkerLocation);
      setMarker(); // 设置marker
      InverseGeography(); // 逆地理编码
    }
  });
};
//地理编码方法
const searchLocation = () => {
  var geocoder = new AMap.Geocoder({
    city: "", //城市设默认：“全国”
  });
  geocoder.getLocation(singlefarm.location, function (status, result) {
    if (status === "complete" && result.geocodes.length) {
      var lnglat = result.geocodes[0].location;
      if (singlefarmMarker) {
        mapFarm.remove(singlefarmMarker);
        singlefarmMarkerLocation = [lnglat.lng, lnglat.lat];
        console.log(singlefarmMarkerLocation);
        setMarker(); // 设置marker
      }
    } else {
      log.error("根据地址查询位置失败");
    }
  });
};
// 创建marker方法
const setMarker = () => {
  // 创建一个 Marker 实例：
  singlefarmMarker = new AMap.Marker({
    position: new AMap.LngLat(
      singlefarmMarkerLocation[0],
      singlefarmMarkerLocation[1]
    ), // 经纬度对象，也可以是经纬度构成的一维数组[116.39, 39.9]
    //title: '北京' // marker的鼠标滑过提示
  });

  // 将创建的点标记添加到已有的地图实例：
  mapFarm.add(singlefarmMarker);
  mapFarm.setFitView(singlefarmMarker);

  // 移除已创建的 marker
  // map.remove(marker);
};
// 逆地理编码方法
const InverseGeography = () => {
  var geocoder = new AMap.Geocoder({
    // city 指定进行编码查询的城市，支持传入城市名、adcode 和 citycode
    city: "",
  });
  geocoder.getAddress(singlefarmMarkerLocation, function (status, result) {
    if (status === "complete" && result.info === "OK") {
      // result为对应的地理位置详细信息
      singlefarm.location = result.regeocode.formattedAddress;
      console.log(singlefarm.location);
    }
    console.log(status);
  });
};

//当田地可视化时候加载地图3
const makeMap3 = () => {
  //第三张地图
  map3 = new AMap.Map("container3", {
    //设置地图容器id
    viewMode: "2D", //是否为3D地图模式
    zoom: 11, //初始化地图级别
    center: [116.400274, 39.905812], //初始化地图中心点位置
  });
  //卫星图
  var weixing3 = new AMap.TileLayer.Satellite({
    zIndex: 10,
  });
  map3.add(weixing3);
  map3.addControl(new AMap.Scale()); //比例尺
  map3.setStatus({ zoomEnable: true }); //控制地图是否可放大
  map3.setStatus({ dragEnable: true, keyboardEnable: true }); //控制地图是否可以平移

  let center;
  if (cancelbtn.value == true) {
    center = singlefarmMarkerLocation;
  } else {
    for (let i = 0; i < farmList.value.length; i++) {
      if (farmList.value[i].farm_Id == global_var.farmid) {
        const tempPolygonsText = ref([]);
        const tempPolygons = ref([]);
        center = farmList.value[i].farmLocation;

        //复制原图农田过来
        for (const item of polygons.value[i]) {
          tempPolygons.value.push(
            new AMap.Polygon({
              path: item.getPath(),
              strokeColor: "#FF33FF",
              strokeWeight: 6,
              strokeOpacity: 0.2,
              fillOpacity: 0.4,
              fillColor: "#1791fc",
              zIndex: 40,
              bubble: true,
            })
          );
        }
        for (const item of polygonsText.value[i]) {
          tempPolygonsText.value.push(
            new AMap.Text({
              text: item.getText(),
              anchor: "center", // 设置文本标记锚点
              cursor: "default",
              clickable: false,
              style: {
                padding: ".3rem .5rem",
                "margin-bottom": "1rem",
                "border-radius": ".25rem",
                background: "transparent",
                width: "5rem",
                "border-width": 0,
                "text-align": "center",
                "font-size": "1px",
                color: "white",
              },
              position: item.getPosition(),
            })
          );
        }
        map3.add(tempPolygons.value);
        map3.add(tempPolygonsText.value);
        break;
      }
    }
  }
  let polygon = new AMap.Polygon({
    path: [
      [center[0] - 0.002, center[1]],
      [center[0], center[1]],
      [center[0], center[1] + 0.002],
      [center[0] - 0.002, center[1] + 0.002],
    ],
    strokeColor: "#FF33FF",
    strokeWeight: 6,
    strokeOpacity: 0.2,
    fillOpacity: 0.4,
    fillColor: "#1791fc",
    zIndex: 60,
    bubble: true,
  });
  map3.add(polygon);
  map3.setFitView([polygon]);
  polygonEditor = new AMap.PolygonEditor(map3, polygon);
};
const openEditPolygon = () => {
  polygonEditor.open();
};
const closeEditPolygon = () => {
  polygonEditor.close();
  let polygon = polygonEditor.getTarget();
  let path = polygon.getPath();
  singlefield.p1LON = path[0].lng;
  singlefield.p1LAT = path[0].lat;
  singlefield.p2LON = path[1].lng;
  singlefield.p2LAT = path[1].lat;
  singlefield.p3LON = path[2].lng;
  singlefield.p3LAT = path[2].lat;
  singlefield.p4LON = path[3].lng;
  singlefield.p4LAT = path[3].lat;
  console.log(singlefield);
};

//添加一个农场
const addFarmInMap = (data) => {
  //添加点覆盖物
  markers.value.push(
    new AMap.Marker({
      position: data.farmLocation, //i号农场的1号田的第一个坐标（1号田对应序号0，以此类推）
    })
  );
  markers.value[markers.value.length - 1].setLabel({
    offset: new AMap.Pixel(0, 0), //设置文本标注偏移量
    content: data.name, //设置文本标注内容
    direction: "top", //设置文本标注方位
  });
  //点覆盖物触发的事件
  //单击点覆盖物
  markers.value[markers.value.length - 1].on("click", () => {
    changeFilmView(data.farm_Id);
    hasSelected = false
  });
  map1.add(markers.value[markers.value.length - 1]);

  //添加多边形覆盖物
  polygons.value[polygons.value.length] = new Array();
  polygonsText.value[polygonsText.value.length] = new Array();
};
//添加一个农田
const addFieldInMap = (farmIdNum, data) => {
  //添加多边形覆盖物
  for (let i = 0; i < farmList.value.length; i++) {
    if (farmList.value[i].farm_Id == farmIdNum) {
      let tempLocationArr = [
        [data.vertex1_Longitude, data.vertex1_Latitude],
        [data.vertex2_Longitude, data.vertex2_Latitude],
        [data.vertex3_Longitude, data.vertex3_Latitude],
        [data.vertex4_Longitude, data.vertex4_Latitude],
      ];
      polygons.value[i].push(
        new AMap.Polygon({
          path: tempLocationArr,
          strokeColor: "#FF33FF",
          strokeWeight: 6,
          strokeOpacity: 0.2,
          fillOpacity: 0.4,
          fillColor: "#1791fc",
          zIndex: 50,
          bubble: true,
        })
      );
      var tmp_center = getPointsCenter(tempLocationArr);
      polygonsText.value[i].push(
        new AMap.Text({
          text: data.name,
          anchor: "center", // 设置文本标记锚点
          cursor: "default",
          style: {
            padding: ".3rem .5rem",
            "margin-bottom": "1rem",
            "border-radius": ".25rem",
            background: "transparent",
            width: "5rem",
            "border-width": 0,
            "text-align": "center",
            "font-size": "10px",
            color: "white",
          },
          position: tmp_center,
        })
      );
      //多边形覆盖物触发的事件
      let j = polygons.value[i].length - 1;
      // 双击
      polygons.value[i][j].on("dblclick", () => {});
      //单击
      polygons.value[i][j].on("click", () => {
        global_var.farmid = farmList.value[i].farm_Id;
        global_var.fieldid = farmList.value[i].fieldList[j].field_Id;
        router.push({ path: "/fieldmanagement" });
      });

      // 鼠标移入更改样式
      polygons.value[i][j].on("mouseover", () => {
        polygons.value[i][j].setOptions({
          fillOpacity: 0.7,
          fillColor: "#7bccc4",
        });
      });

      // 鼠标移出恢复样式
      polygons.value[i][j].on("mouseout", () => {
        polygons.value[i][j].setOptions({
          fillOpacity: 0.4,
          fillColor: "#1791fc",
        });
      });
      //单击(Text)
      polygonsText.value[i][polygonsText.value[i].length - 1].on(
        "click",
        () => {
          global_var.farmid = farmList.value[i].farm_Id;
          global_var.fieldid = farmList.value[i].fieldList[j].field_Id;
          router.push({ path: "/fieldmanagement" });
        }
      );
      // 鼠标移入更改样式(Text)
      polygonsText.value[i][polygonsText.value[i].length - 1].on(
        "mouseover",
        () => {
          polygons.value[i][j].setOptions({
            fillOpacity: 0.7,
            fillColor: "#7bccc4",
          });
        }
      );
      // 鼠标移出恢复样式(Text)
      polygonsText.value[i][polygonsText.value[i].length - 1].on(
        "mouseout",
        () => {
          polygons.value[i][j].setOptions({
            fillOpacity: 0.4,
            fillColor: "#1791fc",
          });
        }
      );
      map2.add([polygons.value[i][j]]);
      map2.add([polygonsText.value[i][polygonsText.value[i].length - 1]]);
      break;
    }
  }
};
const redIcon=ref(null);
const blueIcon=ref(null);

//地图初始化
const initMap = () => {
  markers.value.length = 0;
  polygons.value.length = 0;
  polygonsText.value.length = 0;
  AMapLoader.load({
    key: "48a10a5361d2ac9096e427d84fa9fede", //此处填入我们注册账号后获取的Key
    version: "2.0", //指定要加载的 JSAPI 的版本，缺省时默认为 1.4.15
    plugins: [
      "AMap.Polygon",
      "AMap.PolyEditor",
      "AMap.PolygonEditor",
      "AMap.Scale",
      "AMap.PolygonEditor",
      "AMap.ToolBar",
      "AMap.PlaceSearch",
      "AMap.AutoComplete",
      "AMap.Geocoder",
    ], //需要使用的的插件列表，如比例尺'AMap.Scale'等
  })
    .then((myMap) => {
      AMap = myMap;
      //第一张地图
      map1 = new AMap.Map("container1", {
        //设置地图容器id
        viewMode: "2D", //是否为3D地图模式
        zoom: 3, //初始化地图级别
        center: [105.57141, 32.820837], //初始化地图中心点位置
        resizeEnable: true,
      });
      map1.addControl(new AMap.Scale()); //比例尺
      map1.setStatus({ zoomEnable: true }); //控制地图是否可放大
      map1.setStatus({ dragEnable: true, keyboardEnable: false }); //控制地图是否可以平移
      map1.setStatus({ scrollWheel: true, doubleClickZoom: false }); //控制地图是否可以通过鼠标滚轮或双击缩放
      map1.addControl(new AMap.ToolBar()); // 在图面添加工具条控件, 工具条控件只有缩放功能

      //第二张地图
      map2 = new AMap.Map("container2", {
        //设置地图容器id
        viewMode: "2D", //是否为3D地图模式
        zoom: 8.8, //初始化地图级别
        center: [116.400274, 39.905812], //初始化地图中心点位置
      });
      //卫星图
      var weixing2 = new AMap.TileLayer.Satellite({
        zIndex: 10,
      });
      map2.add(weixing2);
      map2.addControl(new AMap.Scale()); //比例尺
      map2.setStatus({ zoomEnable: true }); //控制地图是否可放大
      map2.setStatus({ dragEnable: false, keyboardEnable: false }); //控制地图是否可以平移
      map2.setStatus({ scrollWheel: false, doubleClickZoom: false }); //控制地图是否可以通过鼠标滚轮或双击缩

      //同级位置添加相关代码即可

      //制作点覆盖物图标
      redIcon.value=new AMap.Icon({
        image:"//a.amap.com/jsapi_demos/static/demo-center/icons/poi-marker-red.png",
        imageSize: new AMap.Size (20, 25),
        size: new AMap.Size (20, 25),

      })

      blueIcon.value=new AMap.Icon({
        image:"//a.amap.com/jsapi_demos/static/demo-center/icons/poi-marker-default.png",
        imageSize: new AMap.Size (20, 25),
        size: new AMap.Size (20, 25),

      })

      //添加农场对应的点覆盖物和多边形覆盖物
      for (const item of farmList.value) {
        addFarmInMap(item);
        for (const temp of item.fieldList) {
          addFieldInMap(item.farm_Id, temp);
        }
      }
      for (const item of markers.value) {//设定除选定农场外的图标
        item.setIcon(
          blueIcon.value
        );
      }
      
      map1.setFitView(null,true); // 缩放地图到合适的视野级别
      for (let i = 0; i < farmList.value.length; i++) {
        if (farmList.value[i].farm_Id == global_var.farmid) {//设定除选定农场图标
          markers.value[i].setIcon(
            redIcon.value
          );
          map2.setFitView(polygons.value[i], true);
        }
      }
    })
    .catch((e) => {
      console.log(e);
    });
};
const UpdateMap=async()=>{
  //获取地图需要的信息
  farmList.value.length=0
  try {
    let res = await Get_All_Farm();
    farmList.value = res.data;
    for (const item of farmList.value) {
      let params = {
        farm_id: item.farm_Id,
      };
      await Get_Fields_By_Farm(params).then(function (res) {
        item.fieldList = res.data;
      });
      item.farmLocation = [116, 39]; //默认坐标
      if (item.fieldList.length != 0) {
        item.farmLocation = [
          item.fieldList[0].vertex1_Longitude,
          item.fieldList[0].vertex1_Latitude,
        ];
        if (
          item.farmLocation[0] < -180 ||
          item.farmLocation[1] < -85 ||
          item.farmLocation[0] > 180 ||
          item.farmLocation[1] > 85
        ) {
          item.farmLocation = [116, 39]; //经纬度出错则改为默认坐标
        }
      }
    }
    console.log(farmList);
  } catch (error) {
    console.error(error);
  }
  initMap(); //初始化地图
}
onMounted(async () => {
  //农场列表
  try {
    await Get_All_Farm().then(function (res) {
      const data = res.data;
      for (const item of data) {
        farmoptions.push({
          label: item.name,
          value: item.farm_Id,
          id: item.farm_Id,
          location: item.location,
        });
      }
      if (global_var.farmid == -1) {
        global_var.farmid = data[0].farm_Id;
      }
    });
  } catch (error) {
    console.error(error);
  }

  //农场名称和位置
  try {
    let params = {
      farm_id: global_var.farmid,
    };
    await Get_Farm_Info(params).then(function (res) {
      const data = res.data;
      input.value = global_var.farmid;
      farminfo.id = global_var.farmid;
      farminfo.name = data.name;
      farminfo.location = data.location;
      singlefarminfo.name = data.name;
      singlefarminfo.location = data.location;
    });
  } catch (error) {
    console.error(error);
  }

  //田地列表（此处接口用的田地高级搜索）
  try {
    let params = {
      farm_name: farminfo.name,
    };
    await Get_Filtered_Fields(params).then(function (res) {
      const data = res.data;
      console.log(data);
      for (const item of data) {
        fieldData.push({
          id: item.field_Id,
          name: item.name,
          state: item.status == "空" ? "空闲" : "占用",
          crop: item.cropName == null ? "无" : item.cropName,
          soil: item.soil_Type,
          ph: item.ph_Level,
        });
      }
    });
  } catch (error) {
    console.error(error);
  }

  if (global_var.fieldid == -1) {
    //获取第一块田地的id（此处接口用的返回坐标的）
    try {
      let params = {
        farm_id: farminfo.id,
      };
      await Get_Fields_By_Farm(params).then(function (res) {
        const data = res.data;
        if (data.length != 0) {
          global_var.fieldid = data[0].field_Id;
        }
      });
    } catch (error) {
      console.error(error);
    }
  }
  UpdateMap()
  finish.value = true;
});
</script>
  

<style>
#farmpage {
  margin-left: 5%;
}

#farmpage-loading {
  margin-left: 5%;
}
#container1 {
  width: 600px;
  height: 370px;
  margin: 20px auto;
}
#container2 {
  width: 600px;
  height: 370px;
  margin: 20px auto;
}
#container3 {
  width: 95%;
  height: 300px;
  margin: 20px auto;
}
#containerFarm {
  width: 80%;
  height: 300px;
  margin: 20px auto;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.search-container {
  display: flex;
  align-items: center;
}

.inner-card {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}

.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
.two-side {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
/* 隐藏高德logo  */
.amap-logo {
  display: none !important;
}

/* 隐藏高德版权  */
.amap-copyright {
  display: none !important;
}
</style>