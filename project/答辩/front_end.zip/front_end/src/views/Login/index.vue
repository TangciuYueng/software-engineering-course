<template>
  <div id="loginpage">
    <br /><br />
    <img
      src="../../assets/logoGreen.png"
      style="height: 120px; display: block; margin: 0 auto;"
    />
    <br /><br /><br />
    <div>
      <div id="admin">
        <div class="pos" v-loading="loading">
          <h3 class="adminh1">员工登录</h3>
          <el-form
            :model="form"
            status-icon
            :rules="rules"
            ref="formRef"
            label-width="100px"
          >
            <el-form-item prop="id" label="用户" style="margin-bottom: 20px">
              <el-input v-model="form.id" />
            </el-form-item>
            <el-form-item
              prop="password"
              label="密码"
              style="margin-bottom: 20px"
            >
              <el-input v-model="form.password" type="password" />
            </el-form-item>
            <el-form-item
              prop="agree"
              label-width="52px"
              style="margin-bottom: 20px"
            >
              <el-checkbox size="small" v-model="form.agree">
                我已同意隐私条款
              </el-checkbox>
            </el-form-item>
          </el-form>
          <el-button size="large" class="subBtn2" @click="doLogin"
            >点击登录</el-button
          >
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { login } from "@/api/login.js";
import { ref } from "vue";
import { ElMessage } from "element-plus";
import "element-plus/theme-chalk/el-message.css";
import { useRouter } from "vue-router";
import Axios from "axios";
import useUserStore2 from "@/store/uss";

import { storeToRefs } from "pinia";

Axios.defaults.baseURL = "/api";

//这样解构的属性将保持响应性
const store = useUserStore2();

//1.准备表单对象
const form = ref({
  id: "",
  password: "",
  agree: true,
});

//2.规则对象
const rules = {
  id: [{ required: true, message: "ID不能为空", trigger: "blur" }],
  password: [
    { required: true, message: "密码不能为空", trigger: "blur" },
    { min: 6, max: 16, message: "密码长度应为6-16", trigger: "blur" },
  ],
  agree: [
    {
      validator: (rule, value, callback) => {
        console.log(value);

        if (value) {
          callback();
        } else {
          callback(new Error("请勾选协议!"));
        }
      },
    },
  ],
};

//3.获取form实例 对整个登录表单都做校验
const formRef = ref(null);
//路由跳转
const router = useRouter();

//doLogin 函数 掌管登录的逻辑
const doLogin = () => {
  //校验的格式
  formRef.value.validate(async (valid) => {
    console.log(valid);
    //加密
    var keys = "XXXXXXXXXXXXX";
    if (valid) {
      //login才会进行
      let params = {
        id: form.value.id,
        // password:AES.encrypt(form.value.password, keys),
        password: form.value.password,
        mode: 1,
      };

      // pinia存储 ，暂时不知道怎么获取pinia数据
      store.loadUserList(params);

      //登录逻辑
      login(params).then(function (res) {
        if (res.data !== -1) {
          //成功登录提示
          console.log("登录成功");
          console.log( store.token.name);
          ElMessage({ type: "success", message: "登录成功" });
          if(store.token.identity == 1)
            router.replace({ path: "/farmmanagement" });
          else
            router.replace({ path: "/warehousemanagement" });
        } else {
          //失败
          console.log(res);
          ElMessage({ type: "error", message: "登录失败" });
          console.log("登录失败");
        }
      });
    }
  });
};
</script>

<style scoped lang='scss'>
#loginpage {
  background-image: url("../../assets/bgi.jpg");
  background-size: cover;
  height: 100vh;
}

.subBtn2 {
  background: #0c8649;
  width: 400px;
  margin-left: 52px;
  color: #fff;
}

* {
  padding: 0;
  margin: 0;
}

#admin {
  width: 500px;
  height: 280px;
  border-radius: 10%;
  background-color: #fff;
  margin: 0 auto;
  position: absolute;
  left: 0;
  right: 0;
}

.adminh1 {
  margin: 20px 0;
  text-align: center;
  margin-left: 45px;
}

.pos {
  width: 450px;
  height: 350px;
}
</style>@/store/uss