<template>
  <div>
    <p>字符串: {{ inputString }}</p>
    <p>字符串长度: {{ stringLength }}</p>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';

// 使用 ref 创建一个响应式数据
const inputString = ref('你好？？？??');

// 使用 computed 计算字符串长度
const stringLength = computed(() => inputString.value.length);
</script>

