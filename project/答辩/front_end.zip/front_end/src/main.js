import 'element-plus/dist/index.css';
import ElementPlus from 'element-plus';
import {createApp} from 'vue';

import App from './App.vue';
import router from './router';
import store from './store';

import { createPinia } from 'pinia'
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate'

import * as ElementPlusIconsVue from '@element-plus/icons-vue'

//import '@/styles/common.scss'

const app = createApp(App);

const pinia = createPinia()
pinia.use(piniaPluginPersistedstate)

// 使用 for...of 循环注册 Element Plus 的图标组件
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component);
}

// 注册 Vue Router 和 Vuex Store
app.use(router).use(store).use(ElementPlus).use(pinia).mount('#app');