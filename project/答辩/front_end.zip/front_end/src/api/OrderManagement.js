import request from '@/utils/request'

export function distribute(params) {
  /*登陆 */
  return request({
    url: '/Bill/adddelivery',
    method: 'put',
    params:{
        deliverynumber:params.deliverynumber,
        subbillid:params.subbillid
    }
  })
}

export function getbill() {
  /*登陆 */
  return request({
    url: '/Bill/allinfo',
    method: 'get',
  })
}

export function getservice(params) {
  /*登陆 */
  return request({
    url: '/Service/allinfo',
    method: 'get',
    params:{id:params.id}
  })
}

export function getp(params) {
  /*登陆 */
  return request({
    url: '/Bill/GetTrackingInfo',
    method: 'get',
    params:{subbillid:params.subbillid}
  })
}



export function postreply(params) {
  /*登陆 */
  return request({
    url: '/Service/complete',
    method: 'post',
    params:{
      serviceid:params.serviceid,
      result:params.result,
      salespersonid:params.salespersonid
    }
  })
}

export function login(params) {
  /*登陆 */
  return request({
    url: '/Login/Get',
    method: 'get',
    params: {
      user_id: params.user_id,
      password: params.password
    }
  })
}