import request from '@/utils/request'

export function Get_All_Farm() {
  /*获取所有农场 */
  return request({
    url: '/FarmManagement/Get_All_Farm',
    method: 'get',
  })
}

export function Get_Fields_By_Farm(params) {
  /*获取某农场的田地 */
  return request({
    url: '/FarmManagement/Get_Fields_By_Farm',
    method: 'get',
    params: {farm_id: params.farm_id}
  })
}

export function Get_Farm_Info(params) {
  /*获取某农场名称和位置 */
  return request({
    url: '/FarmManagement/Get_Farm_Info',
    method: 'get',
    params: {farm_id: params.farm_id}
  })
}

export function Update_Farm(params = {}) {
  /* 编辑农场信息 */
  const requestParams = {
    url: '/FarmManagement/Update_Farm',
    method: 'put',
    params: {...params}
  };

  return request(requestParams);
}

export function Create_Farm(params) {
  /*添加新农场 */
  return request({
    url: '/FarmManagement/Create_Farm',
    method: 'put',
    params: {farmName: params.farmName, location: params.location}
  })
}

export function Create_Field(params) {
  /*添加新田地 */
  return request({
    url: '/FarmManagement/Create_Field',
    method: 'put',
    params: {
      name: params.name,
      farm_id: params.farm_id,
      soil_type: params.soil_type,
      ph_level: params.ph_level,
      vertex1_latitude: params.vertex1_latitude,
      vertex1_longitude: params.vertex1_longitude,
      vertex2_latitude: params.vertex2_latitude,
      vertex2_longitude: params.vertex2_longitude,
      vertex3_latitude: params.vertex3_latitude,
      vertex3_longitude: params.vertex3_longitude,
      vertex4_latitude: params.vertex4_latitude,
      vertex4_longitude: params.vertex4_longitude,
      photo: params.photo,
    }
  })
}