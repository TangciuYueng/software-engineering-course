import request from '@/utils/request';

export function createWarehouse(params) {
    return request({
        url: '/WarehouseManagement/WarehouseCreate',
        method: 'post',
        params: {
            farmName: params.farmName,
            warehouseName: params.warehouseName,
        },
    });
}

export function equipmentMaintenanceHistory(params) {
    return request({
        url: '/Asset/EquipmentMaintenanceHistory',
        method: 'get',
        params: {
            equipment_Id: params.equipment_id,
        }
    });
}



export function FarmConsuable(params) {
    return request({
        url: '/Asset/FarmConsumable',
        method: 'get',
        params: {
            farm_Id: params.farm_Id,
        }
    });
}


export function FarmEquipment(params) {
    return request({
        url: '/Asset/FarmEquipment',
        method: 'get',
        params: {
            farm_Id: params.farm_Id
        }
    });
}

export function filter(params) {
    return request(
        {
            url: '/WarehouseManagement/HighLevelSearch',
            method: 'get',
            params: {
                farmName: params.farmName,
                warehouseName: params.warehouseName,
                name: params.name,
                type: params.Type,
                quality: params.quality,
            }

        }
    )
}

export function getAllFarm() {
    return request({
        url: '/FarmManagement/Get_All_Farm',
        method: 'get',
    });
}

export function insertConsumables(params) {
    return request({
        url: '/Asset/InsertConsumables',
        method: 'post',
        params: {

            name: params.name,
            unit: params.unit,
            stock: params.stock,
            type: params.type,
            farm_id: params.farm_id,
        }
    });
}

export function insertEquipment(params) {
    return request({
        url: '/Asset/InsertEquipment',
        method: 'post',
        params: {

            name: params.name,
            type: params.type,
            farm_id: params.farm_id,
        }
    });
}

export function insertMaintenance(params) {
    return request({
        url: '/Asset/InsertMaintenance',
        method: 'post',
        params: {
            technologist_id: params.technologist_id,
            equipment_id: params.equipment_id,
            maintenance_Date: params.maintenance_date,
            detail: params.detail,
            cost: params.cost,
        }
    });
}

export function login(params) {
    /*登陆 */
    return request({
        url: '/Login/Get',
        method: 'get',
        params: {
            user_id: params.user_id,
            password: params.password
        }
    })
}

export function ModifyConsumables(params) {
    return request({
        url: '/Asset/ModifyConsumables',
        method: 'put',
        params: {
            consumables_id: params.consumables_Id,
            name: params.name,
            unit: params.unit,
            stock: params.stock,
        }
    });
}

export function ModifyEquipment(params) {
    return request({
        url: '/Asset/ModifyEquipment',
        method: 'put',
        params: {
            equipment_id: params.equipment_id,
            name: params.name,
            type: params.type,
        }
    });
}


export function ShelfHistory(params) {
    return request({
        url: '/WarehouseManagement/ShelfHistory',
        method: 'get',
        params: {
            wares_Id: params.wares_Id
        }
    });
}

export function wareConsume(params) {
    return request({
        url: '/WarehouseManagement/WareConsume',
        method: 'post',
        params: {
            wares_id: params.wares_id,
            weight: params.weight,
        },
    });
}

export function WaresHistory(params) {
    return request({
        url: '/WarehouseManagement/WaresHistory',
        method: 'get',
        params: {
            wares_Id: params.wares_id
        },
    });
}

export function WaresOnShelf(params) {
    return request({
        url: '/WarehouseManagement/WaresOnShelf',
        method: 'put',
        params: {
            wares_Id: params.wares_id,
            weight: params.weight,
            salesperson_id: params.salesperson_id
        },
    });
}

export function GetFarmWarehouse(){
    return request({
        url:'/WarehouseManagement/GetFarmWarehouse',
        method:'get',
    })
}