import request from '@/utils/request'

export function Get_Filtered_Fields(params = {}) {
  /* 高级筛选田地 */
  const requestParams = {
    url: '/FieldManagement/GetFilteredFields',
    method: 'get',
    params: {...params}
  };

  return request(requestParams);
}

export function Get_Farm_Fields(params) {
  /*获取农场的某田地的全部信息 */
  return request({
    url: 'FieldManagement/Get_Farm_Fields',
    method: 'get',
    params: {field_id: params.field_id}
  })
}

export function Find_Current_Crop(params) {
  /*获取当前田地种植作物的信息 */
  return request({
    url: '/FieldManagement/Find_Current_Crop',
    method: 'get',
    params: {field_id: params.field_id}
  })
}


export function Get_Issue_Static(params){
  /*获取当前农场的事项信息 */
  return request(
    {
      url: '/WarehouseManagement/IssueStatic',
      method: 'get',
      params: {farm_id: params.farm_id, timespan: params.mode}
    }
  )
}

export function Get_Weather(params) {
  /*获取当前农场的天气信息 */
  return request({
    url: '/FieldManagement/Get_Weather',
    method: 'get',
    params: {farm_id: params.farm_id, mode: params.mode}
  })
}

export function Get_Current_Harvest(params) {
  /*获取当前田地种植作物的信息 */
  return request({
    url: '/FieldManagement/Get_Current_Harvest',
    method: 'get',
    params: {field_id: params.field_id}
  })
}

export function Get_History_Harvest(params) {
  /*获取当前田地种植作物的信息 */
  return request({
    url: '/FieldManagement/Get_History_Harvest',
    method: 'get',
    params: {field_id: params.field_id}
  })
}

export function Update_Field(params = {}) {
  /* 编辑农场信息 */
  const requestParams = {
    url: '/FieldManagement/Update_Field',
    method: 'put',
    params: {...params}
  };

  return request(requestParams);
}

export function find_appropriate_crop(params) {
  /*获取某田地推荐种植作物的信息 */
  return request({
    url: '/FieldManagement/find_appropriate_crop',
    method: 'get',
    params: {field_id: params.field_id}
  })
}

export function Get_Crop(params) {
  /*获取所有已经种植作物的名单信息 */
  return request({
    url: '/FieldManagement/Get_Crop',
    method: 'get',
    params: {field_id: params.field_id}
  })
}

export function Get_Todays_Weather(params) {
  /*获取当天天气信息 */
  return request({
    url: 'FieldManagement/Get_Todays_Weather',
    method: 'get',
    params: {farm_id: params.farm_id}
  })
}

export function find_history_crop(params) {
  /*获取某田地历史种植作物 */
  return request({
    url: '/FieldManagement/find_history_crop',
    method: 'get',
    params: {field_id: params.field_id}
  })
}

export function create_planting_and_issue(params) {
  /*为空田地种植作物 */
  return request({
    url: '/FieldManagement/CreatePlantingAndIssue',
    method: 'put',
    params: {
      field_id: params.field_id,
      crop_id: params.crop_id,
      dateString: params.dateString,
      technologist_id: params.technologist_id,
    }
  })
}

export function CreateNewCropAndGetId(params) {
  /*为空田地种植作物 */
  return request({
    url: '/FieldManagement/CreateNewCropAndGetId',
    method: 'put',
    params: {
      name: params.name,
      cropType: params.cropType,
      soilType: params.soilType,
      lowPh: params.lowPh,
      highPh: params.highPh,
    }
  })
}

export function Create_Issue(params) {
  /*创建新事项 */
  return request({
    url: '/FieldManagement/Create_Issue',
    method: 'put',
    params: {
      type: params.type,
      dateString: params.dateString,
      technologist_id: params.technologist_id,
      planting_id: params.planting_id,
      detail: params.detail,
    }
  })
}

export function Get_Free_Equipment(params) {
  /*获取推荐的设备 */
  return request({
    url: '/FieldManagement/Get_Free_Equipment',
    method: 'get',
    params: {issue_id: params.issue_id}
  })
}

export function Get_Free_Consumables(params) {
  /*获取推荐的消耗物 */
  return request({
    url: '/FieldManagement/Get_Free_Consumables',
    method: 'get',
    params: {issue_id: params.issue_id}
  })
}

export async function GetIssuesByFieldId(params) {
  /*获取田地当前种植的事项 */
  return request({
    url: '/FieldManagement/GetIssuesByFieldId',
    method: 'get',
    params: {field_id: params.field_id}
  })
}

export function GetActivitiesByActivityId(params) {
  /*获取田地当前种植的事项 */
  return request({
    url: '/FieldManagement/GetActivitiesByActivityId',
    method: 'get',
    params: {activity_id: params.activity_id}
  })
}

export function Solve_Issue_By_Equipment(params = {}) {
  /* 待解决->解决中 */
  const requestParams = {
    url: '/FieldManagement/Solve_Issue_By_Equipment',
    method: 'put',
    params: {...params}
  };

  return request(requestParams);
}

export function Solve_Issue_By_Consumable(params = {}) {
  /* 解决中->已解决 */
  const requestParams = {
    url: '/FieldManagement/Solve_Issue_By_Consumables',
    method: 'put',
    params: {...params}
  };

  return request(requestParams);
}

export function Find_Appropriate_Warehouse(params) {
  /*获取收获的仓库信息 */
  return request({
    url: '/FieldManagement/Find_Appropriate_Warehouse',
    method: 'get',
    params: {harvest_id: params.harvest_id}
  })
}

export function Insert_Harvest_Info_And_Update_Wares(params = {}) {
  /* 插入收获信息 */
  const requestParams = {
    url: '/FieldManagement/Insert_Harvest_Info_And_Update_Wares',
    method: 'put',
    params: {...params}
  };

  return request(requestParams);
}

export function Get_Harvest_Info(params) {
  /*获取某次收获信息 */
  return request({
    url: '/FieldManagement/Get_Harvest_Info',
    method: 'get',
    params: {harvest_id: params.harvest_id}
  })
}

export function Check_Harvest_Status(params) {
  /*完成收获 */
  return request({
    url: '/FieldManagement/Check_Harvest_Status',
    method: 'put',
    params: {
      planting_id: params.planting_id,
      dateString: params.dateString,
    }
  })
}