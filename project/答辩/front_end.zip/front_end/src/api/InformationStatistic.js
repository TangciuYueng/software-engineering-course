import request from '@/utils/request'

export function Count_Provinces() {
  /* 农场分布省份统计 */
  return request({
    url: '/Statistics/CountProvinces',
    method: 'get',
  });

}


export function Product_Rank(params) {
  /* 保质期预警排行榜 */
  return request({
    url: '/Bill/productssale',
    method: 'get',
    params: {mode: params.mode}
  });

}

export function Bill_Service(params) {
  /* 收获统计图 */
  return request({
    url: '/Bill/allbill',
    method: 'get',
    params: {mode: params.mode}
  });

}

export function Product_Quality(params) {
  /* 商品分等级销量扇形图 */
  return request({
    url: '/Bill/qualitysale',
    method: 'get',
    params: {
              mode: params.mode,
            }
  });

}

