package org.qianmo.field.service.impl;

import org.qianmo.field.dto.FieldRequest;
import org.qianmo.field.dto.FilterRequest;
import org.qianmo.field.mapper.CropMapper;
import org.qianmo.field.mapper.FieldMapper;
import org.qianmo.field.model.Field;
import org.qianmo.field.service.FieldService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FieldServiceImpl implements FieldService {

    @Autowired
    private FieldMapper fieldMapper;
    @Autowired
    private CropMapper cropMapper;

    public Integer addField(FieldRequest request) {
        try {
            Field field = Field.builder().status(request.getStatus()).name(request.getName()).farmId(request.getFarmId())
                    .soilType(request.getSoilType()).phLevel(request.getPhLevel()).vertex1Latitude(request.getVertex1Latitude())
                    .vertex1Longitude(request.getVertex1Longitude()).vertex2Latitude(request.getVertex2Latitude())
                    .vertex2Longitude(request.getVertex2Longitude()).vertex3Latitude(request.getVertex3Latitude())
                    .vertex3Longitude(request.getVertex3Longitude()).vertex4Latitude(request.getVertex4Latitude())
                    .vertex4Longitude(request.getVertex4Longitude()).photo(request.getPhoto()).build();
            this.fieldMapper.addField(field);
            return field.getFieldId();
        } catch (Exception var3) {
            return null;
        }
    }

    @Override
    public List<Field> getFilteredFields(FilterRequest request) {
        try {
            if (request == null) {
                return new ArrayList<>();
            }
            Integer farmId = request.getFarmId();   // 怎么会没有农场Id
            String status = request.getStatus();
            String soilType = request.getSoilType();
            Double minPh = request.getMinPh();
            Double maxPh = request.getMaxPh();
            List<Field> fields = fieldMapper.getFilteredFields(farmId, status, soilType, minPh, maxPh);
            // 检查 cropName
            String cropName = request.getCropName();
            if (cropName == null) {
                return fields;
            }
            List<Integer> fieldIds = fields.stream()
                    .map(Field::getFieldId)
                    .collect(Collectors.toList());
            List<Integer> filteredFieldIds = cropMapper.getFieldIdByCurrentCrop(cropName, fieldIds);
            List<Field> filteredFields = fields.stream()
                    .filter(field -> filteredFieldIds.contains(field.getFieldId()))
                    .collect(Collectors.toList());
            return filteredFields;
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    @Override
    public List<Field> getFieldByFarmId(int farmId) {
        try {
            List<Field> fields = fieldMapper.getFieldByFarmId(farmId);
            return fields;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    @Override
    public Integer updateField(Field field) {
        try {
            fieldMapper.updateField(field);
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Integer updateStatus(int fieldId, String status) {
        try {
            fieldMapper.updateStatus(fieldId, status);
            return 0;
        } catch (Exception e) {
            return null;
        }
    }


}
