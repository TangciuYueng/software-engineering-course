package org.qianmo.field.controller;

import jakarta.annotation.Resource;
import org.qianmo.field.dto.FieldRequest;
import org.qianmo.field.dto.FilterRequest;
import org.qianmo.field.model.Field;
import org.qianmo.field.service.FieldService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/field")
public class FieldController {
    @Resource
    private FieldService fieldService;

    // 获取所有的farm信息
    @PostMapping("/addField")
    public ResponseEntity<?> addField(@RequestBody FieldRequest request) {
        Integer newId;
        newId = fieldService.addField(request);
        if (newId != null) {
            return ResponseEntity.ok(newId);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }
    @GetMapping("/filter")
    public ResponseEntity<List<Field>> getFilteredFields(@RequestBody(required = false) FilterRequest request) {
        List<Field> fields = fieldService.getFilteredFields(request);
        return ResponseEntity.ok(fields);
    }
    @GetMapping("/farm/{farmId}")
    public ResponseEntity<List<Field>> getFieldByFarmId(@PathVariable("farmId") int farmId) {
        List<Field> fields = fieldService.getFieldByFarmId(farmId);
        return ResponseEntity.ok(fields);
    }

    @PutMapping
    public ResponseEntity<Integer> updateField(@RequestBody Field field) {
        Integer res = fieldService.updateField(field);
        if (res != null) {
            return ResponseEntity.ok(0);
        } else {
            return ResponseEntity.badRequest().body(-1);
        }
    }
    @PutMapping("/{fieldId}/status/{status}")
    public ResponseEntity<Integer> updateFieldStatus(@PathVariable("fieldId") int fieldId, @PathVariable("status") String status) {
        Integer res = fieldService.updateStatus(fieldId, status);
        if (res != null) {
            return ResponseEntity.ok(0);
        } else {
            return ResponseEntity.badRequest().body(-1);
        }
    }
}
