package org.qianmo.field.controller;

import org.qianmo.field.dto.CropRequest;
import org.qianmo.field.dto.CropResp;
import org.qianmo.field.dto.HistoryCropDTO;
import org.qianmo.field.model.Crop;
import org.qianmo.field.service.CropService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.w3c.dom.ls.LSInput;

import java.util.List;

@RestController
@RequestMapping("/api/crop")
public class CropController {
    @Autowired
    private CropService cropService;

    @GetMapping("/appropriate/field/{fieldId}")
    public ResponseEntity<List<Crop>> getApproriateCrop(@PathVariable("fieldId") int fieldId) {
        List<Crop> crops = cropService.getAppropriateCrop(fieldId);
        return ResponseEntity.ok(crops);
    }

    @GetMapping("/field/{fieldId}")
    public ResponseEntity<List<Crop>> getCropByFieldId(@PathVariable("fieldId") int fieldId) {
        List<Crop> crops = cropService.getCropByFieldId(fieldId);
        return ResponseEntity.ok(crops);
    }

    @GetMapping("/history/field/{fieldId}")
    public ResponseEntity<List<HistoryCropDTO>> getHistoryCropByFieldId(@PathVariable("fieldId") int fieldId) {
        List<HistoryCropDTO> historyCropDTOS = cropService.getHistoryCropByFieldId(fieldId);
        return ResponseEntity.ok(historyCropDTOS);
    }

    @PostMapping
    public ResponseEntity<?> addCrop(@RequestBody CropRequest request) {
        Integer newId = cropService.addCrop(request);
        if (newId != null) {
            return ResponseEntity.ok(newId);
        } else {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/name/crop_type")
    public ResponseEntity<List<Integer>> getIds(@RequestParam(value = "name", required = false) String name,
                                                @RequestParam(value = "cropType", required = false) String cropType) {
        List<Integer> ids = cropService.getIds(name, cropType);
        if (ids != null && ids.size() != 0) {
            return ResponseEntity.ok((ids));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/name/planting")
    public ResponseEntity<List<CropResp>> getCropByPlantingId(@RequestParam(value = "plantingIds") List<Integer> plantingIds) {
        List<CropResp> cropResps = cropService.getCropByPlantingId(plantingIds);
        if (cropResps != null && cropResps.size() != 0) {
            return ResponseEntity.ok(cropResps);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
