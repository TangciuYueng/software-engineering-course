package org.qianmo.field.service;

import org.qianmo.field.dto.CropRequest;
import org.qianmo.field.dto.CropResp;
import org.qianmo.field.dto.HistoryCropDTO;
import org.qianmo.field.model.Crop;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface CropService {
    List<Crop> getAppropriateCrop(int fieldId);

    List<Crop> getCropByFieldId(int fieldId);

    List<HistoryCropDTO> getHistoryCropByFieldId(int fieldId);

    Integer addCrop(CropRequest request);

    List<Integer> getIds(String name, String cropType);

    List<CropResp> getCropByPlantingId(List<Integer> plantingIds);
}
