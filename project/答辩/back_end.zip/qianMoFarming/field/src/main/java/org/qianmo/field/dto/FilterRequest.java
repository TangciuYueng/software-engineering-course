package org.qianmo.field.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FilterRequest {
    private Integer farmId;
    private String status;
    private String cropName;
    private String soilType;
    private Double minPh;
    private Double maxPh;
}
