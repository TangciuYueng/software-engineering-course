package org.qianmo.field.service;

import org.qianmo.field.dto.FieldRequest;
import org.qianmo.field.dto.FilterRequest;

import org.qianmo.field.model.Field;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface FieldService {
    Integer addField(FieldRequest request);

    List<Field> getFilteredFields(FilterRequest request);

    List<Field> getFieldByFarmId(int farmId);

    Integer updateField(Field field);

    Integer updateStatus(int fieldId, String status);
}
