package org.qianmo.field.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FieldInfo {
    private String farmname;
    private String fieldname;
    private String status;
    private double phLevel;
    private int field_id;
    private String soil_type;
    private String cropname;
}
