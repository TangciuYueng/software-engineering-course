package org.qianmo.field.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.field.dto.CropResp;
import org.qianmo.field.dto.HistoryCropDTO;
import org.qianmo.field.model.Crop;

import java.util.List;

@Mapper
public interface CropMapper {
    List<Integer> getFieldIdByCurrentCrop(@Param("cropName") String cropName, @Param("fieldIds") List<Integer> fieldIds);

    List<Crop> getAppropriateCrop(@Param("fieldId") int fieldId);

    List<Crop> getCropByFieldId(@Param("fieldId") int fieldId);

    List<HistoryCropDTO> getHistoryCropByFieldId(int fieldId);

    void addCrop(Crop crop);

    List<Integer> getIdsByNameAndCropType(@Param("name") String name, @Param("cropType") String cropType);

    List<CropResp> getCropByPlantingId(@Param("plantingIds") List<Integer> plantingIds);
}
