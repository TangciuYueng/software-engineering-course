package org.qianmo.field.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Crop {
    private int cropId;
    private String name;
    private String cropType;
    private String soilType;
    private double highPh;
    private double lowPh;
}
