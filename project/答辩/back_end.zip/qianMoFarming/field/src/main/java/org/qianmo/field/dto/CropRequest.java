package org.qianmo.field.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CropRequest {
    private String name;
    private String cropType;
    private String soilType;
    private double lowPh;
    private double highPh;
}
