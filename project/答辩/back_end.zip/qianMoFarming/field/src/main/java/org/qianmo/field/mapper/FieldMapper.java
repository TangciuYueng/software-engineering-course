package org.qianmo.field.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.field.model.Field;

import java.util.List;

@Mapper
public interface FieldMapper {

    void addField(Field field);

    List<Field> getFilteredFields(@Param("farmId") Integer farmId, @Param("status") String status, @Param("soilType") String soilType, @Param("minPh") Double minPh, @Param("maxPh") Double maxPh);

    int getFarmIdByName(String farmName);

    List<Field> getFieldByFarmId(int farmId);

    void updateField(Field field);

    void updateStatus(@Param("fieldId") int fieldId, @Param("status") String status);
}
