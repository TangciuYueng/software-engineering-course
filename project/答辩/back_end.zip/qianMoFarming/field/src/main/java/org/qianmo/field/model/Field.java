package org.qianmo.field.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Field {
    private int fieldId;
    private String status;
    private String name;
    private int farmId;
    private String soilType;
    private double phLevel;
    private double vertex1Latitude;
    private double vertex1Longitude;
    private double vertex2Latitude;
    private double vertex2Longitude;
    private double vertex3Latitude;
    private double vertex3Longitude;
    private double vertex4Latitude;
    private double vertex4Longitude;
    private String photo;
}