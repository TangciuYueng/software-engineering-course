package org.qianmo.field.service.impl;

import org.qianmo.field.dto.CropRequest;
import org.qianmo.field.dto.CropResp;
import org.qianmo.field.dto.HistoryCropDTO;
import org.qianmo.field.mapper.CropMapper;
import org.qianmo.field.model.Crop;
import org.qianmo.field.service.CropService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CropServiceImpl implements CropService {
    @Autowired
    private CropMapper cropMapper;

    @Override
    public List<Crop> getAppropriateCrop(int fieldId) {
        try {
            List<Crop> crops = cropMapper.getAppropriateCrop(fieldId);
            System.out.println(fieldId);
            return crops;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    @Override
    public List<Crop> getCropByFieldId(int fieldId) {
        try {
            List<Crop> crops = cropMapper.getCropByFieldId(fieldId);
            return crops;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    @Override
    public List<HistoryCropDTO> getHistoryCropByFieldId(int fieldId) {
        try {
            List<HistoryCropDTO> historyCropDTOS = cropMapper.getHistoryCropByFieldId(fieldId);
            return historyCropDTOS;
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    @Override
    public Integer addCrop(CropRequest request) {
        try {
            Crop crop = Crop.builder()
                    .name(request.getName())
                    .cropType(request.getCropType())
                    .soilType(request.getSoilType())
                    .highPh(request.getHighPh())
                    .lowPh(request.getLowPh())
                    .build();
            cropMapper.addCrop(crop);
            return crop.getCropId();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<Integer> getIds(String name, String cropType) {
        try {
            List<Integer> ids = cropMapper.getIdsByNameAndCropType(name, cropType);
            return ids;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<CropResp> getCropByPlantingId(List<Integer> plantingIds) {
        try {
            if (plantingIds.size() == 0) {
                throw new IllegalArgumentException("no planting id");
            }
            List<CropResp> cropResps = cropMapper.getCropByPlantingId(plantingIds);
            return cropResps;
        } catch (Exception e) {
            return null;
        }
    }
}
