package org.qianmo.gateway.filter;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class RoleBasedAuthFilter extends AbstractGatewayFilterFactory<RoleBasedAuthFilter.Config> {

    public RoleBasedAuthFilter() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            // 获取用户角色信息
            String userRole = exchange.getRequest().getHeaders().getFirst("X-User-Role");

            // 根据角色信息进行授权判断
            if ("sales".equals(userRole) && config.isSales()) {
                // 继续请求链
                return chain.filter(exchange);
            } else if ("tech".equals(userRole) && config.isTech()) {
                // 继续请求链
                return chain.filter(exchange);
            } else {
                // 拒绝请求
                exchange.getResponse().setStatusCode(HttpStatus.FORBIDDEN);
                return exchange.getResponse().setComplete();
            }
        };
    }
    public static class Config {
        private boolean sales;
        private boolean tech;

        // Getter and Setter
        public boolean isSales() {
            return sales;
        }

        public void setSales(boolean sales) {
            this.sales = sales;
        }

        public boolean isTech() {
            return tech;
        }

        public void setTech(boolean tech) {
            this.tech = tech;
        }
    }

}