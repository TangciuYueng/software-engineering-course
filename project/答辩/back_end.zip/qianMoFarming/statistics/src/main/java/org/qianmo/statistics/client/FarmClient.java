package org.qianmo.statistics.client;

import org.qianmo.farm.dto.FarmInfo;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

public interface FarmClient {
    @GetMapping("/api/farm/getFarm/{page}")
    public FarmInfo getFarm(@PathVariable("page") int page);
}
