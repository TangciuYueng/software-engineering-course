package org.qianmo.statistics.client;

import org.qianmo.warehouse.model.Wares;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

public interface WarehouseClient {
    @GetMapping("/api/wares/getMostWares")
    public ResponseEntity<List<Wares>> getMostWares ();
    @GetMapping("/api/wares/getEarliestWares")
    public ResponseEntity<List<Wares>> getEarliestWares ();
}
