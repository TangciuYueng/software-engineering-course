package org.qianmo.statistics.client;

import org.qianmo.planting.dto.HarvestStatistics;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

public interface PlantingClient {
    @GetMapping("/api/harvest/statistics/farm/crop")
    public ResponseEntity<HarvestStatistics> getHarvestStatistics(@RequestParam(value = "farmId", required = false) int farmId,
                                                                  @RequestParam(value = "cropId", required = false) int cropId,
                                                                  @RequestParam(value = "timeMode", required = false) int timeMode);
}
