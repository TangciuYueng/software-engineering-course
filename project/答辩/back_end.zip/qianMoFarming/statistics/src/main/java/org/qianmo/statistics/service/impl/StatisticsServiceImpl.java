package org.qianmo.statistics.service.impl;

import org.qianmo.farm.dto.FarmInfo;
import org.qianmo.farm.model.Farm;
import org.qianmo.planting.dto.HarvestStatistics;
import org.qianmo.statistics.dto.FarmCount;
import org.qianmo.statistics.dto.harvestQuality;
import org.qianmo.statistics.dto.WaresRank;
import org.qianmo.statistics.dto.waresQuality;
import org.qianmo.statistics.service.StatisticsService;
import org.qianmo.warehouse.model.Wares;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.qianmo.statistics.client.FarmClient;
import org.qianmo.statistics.client.PlantingClient;
import org.qianmo.statistics.client.WarehouseClient;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class StatisticsServiceImpl implements StatisticsService {

    @Autowired
    private FarmClient farmClient;
    @Autowired
    private PlantingClient plantingClient;
    @Autowired
    private WarehouseClient warehouseClient;
    @Override
    public List<FarmCount> getFarmDistribution() {

        FarmInfo farms=farmClient.getFarm(1);
        List<FarmCount> farmDtoList = new ArrayList<>();

        for (Farm farm : farms.getFarms()) {
            FarmCount farmDto = FarmCount.builder()
                    .num(1)
                    .province(farm.toString())
                    .build();

            farmDtoList.add(farmDto);
        }
        return farmDtoList;
    }

    @Override
    public List<harvestQuality> getHarvestQuality() {

        //调用PlantingClient 的 getHarvestStatistics 方法并获取 ResponseEntity
        ResponseEntity<HarvestStatistics> response = plantingClient.getHarvestStatistics(0, 0, 0);

        //检查响应状态
        harvestQuality harvests = null;
        List<harvestQuality> harvestQualities = null;
        if (response.getStatusCode().is2xxSuccessful()) {
            harvestQualities = new ArrayList<>();
            //如果请求成功，获取并返回HarvestStatistics 数据
            HarvestStatistics harvestStatistics = response.getBody();
            harvests = harvestQuality.builder().harvestDate(LocalDateTime.parse(""))
                    .sales(response.getBody().getSpecialGradeCount())
                    .build();
            harvestQualities.add(harvests);
            return harvestQualities;
        }
        else{
            return null;
        }
    }

    @Override
    public List<waresQuality> getWaresQuality() {
        ResponseEntity<List<Wares>> response = warehouseClient.getMostWares();

        //检查响应状态
        waresQuality wares = null;
        List<waresQuality> waresQualities = null;
        if (response.getStatusCode().is2xxSuccessful()) {
            List<Wares> waresList = response.getBody();

            for (Wares ware : waresList) {
                waresQuality quality=waresQuality.builder().quality("特级").num((int)(ware.getStock()))
                .build();
                waresQualities.add(quality);
            }

            return waresQualities;

        }
        else{
            return null;
        }
    }

    @Override
    public List<WaresRank> getWaresRank() {

        ResponseEntity<List<Wares>> response = warehouseClient.getEarliestWares();

        //检查响应状态
        WaresRank wares = null;
        List<WaresRank> waresDTOS = null;
        if (response.getStatusCode().is2xxSuccessful()) {
            List<Wares> waresList = response.getBody();

            for (Wares ware : waresList) {
                WaresRank quality= WaresRank.builder().rank(1).stock((int)(ware.getStock()))
                        .build();
                waresDTOS.add(quality);
            }

            return waresDTOS;

        }
        else{
            return null;
        }
    }
}