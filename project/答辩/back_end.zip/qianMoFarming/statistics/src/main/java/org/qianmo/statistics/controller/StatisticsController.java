package org.qianmo.statistics.controller;

import org.qianmo.statistics.dto.FarmCount;
import org.qianmo.statistics.dto.harvestQuality;
import org.qianmo.statistics.dto.WaresRank;
import org.qianmo.statistics.dto.waresQuality;
import org.qianmo.statistics.service.StatisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/statistics")
public class StatisticsController {
    @Autowired
    private StatisticsService statisticsService;
    @GetMapping("/farm_distribution")
    public ResponseEntity<?> farmStatistics(){
        List<FarmCount> farmDTOS=statisticsService.getFarmDistribution();
        if(farmDTOS.isEmpty())
            return ResponseEntity.notFound().build();
        else {
            return ResponseEntity.ok(farmDTOS);
        }

    };

    @GetMapping("/expiring_rank")
    public ResponseEntity<?> waresExpiringStatistics(){
        List<WaresRank> waresDTOS=statisticsService.getWaresRank();
        if(waresDTOS.isEmpty())
            return ResponseEntity.notFound().build();
        else {
            return ResponseEntity.ok(waresDTOS);
        }

    };

    @GetMapping("/harvest_quality")
    public ResponseEntity<?> harvestStatistics(){
        List<harvestQuality> harvestQualities=statisticsService.getHarvestQuality();
        if(harvestQualities.isEmpty())
            return ResponseEntity.notFound().build();
        else {
            return ResponseEntity.ok(harvestQualities);
        }

    };

    @GetMapping("/wares_quality")
    public ResponseEntity<?> waresQualityStatistics(){
        List<waresQuality> waresDTOS=statisticsService.getWaresQuality();
        if(waresDTOS.isEmpty())
            return ResponseEntity.notFound().build();
        else {
            return ResponseEntity.ok(waresDTOS);
        }

    };

}
