package org.qianmo.statistics.service;

import org.springframework.stereotype.Service;

import java.util.List;
import org.qianmo.statistics.dto.*;
@Service
public interface StatisticsService {

    List<FarmCount> getFarmDistribution();
    List<harvestQuality> getHarvestQuality();
    List<waresQuality> getWaresQuality();
    List<WaresRank> getWaresRank();
    //List<ShelfHistory> getShelfHistory(int waresId);

    //Integer addShelf(ShelfRequest request);
}