package org.qianmo.planting.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Consumables {
    private int consumablesId;
    private String name;
    private String type;
    private int stock;
    private String unit;
    private int farmId;
}
