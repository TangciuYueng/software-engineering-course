package org.qianmo.planting.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Issue {
    private int issueId;
    private String type;
    private LocalDateTime startDate;
    private LocalDateTime addressDate;
    private LocalDateTime endDate;
    private int plantingId;
    private String detail;
    private int employeeId;
}
