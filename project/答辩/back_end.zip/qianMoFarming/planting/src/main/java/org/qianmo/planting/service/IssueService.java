package org.qianmo.planting.service;

import org.qianmo.planting.common.Page;
import org.qianmo.planting.dto.IssueDTO;
import org.qianmo.planting.dto.IssueRequest;
import org.springframework.stereotype.Service;

@Service
public interface IssueService {
    Page<IssueDTO> getIssuesByFieldId(int fieldId, int page, int size);

    Integer addIssue(IssueRequest request);
}
