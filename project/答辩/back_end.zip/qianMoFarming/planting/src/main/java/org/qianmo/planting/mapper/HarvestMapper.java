package org.qianmo.planting.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.planting.model.Harvest;

import java.util.List;

@Mapper
public interface HarvestMapper {
    List<Harvest> getHarvestsByPlantingId(@Param("plantingIds") List<Integer> plantingIds);

    Harvest getHarvestById(@Param("harvestId") int harvestId);

    List<Integer> getStatisticsIds(@Param("farmId") int farmId, @Param("cropId") int cropId, @Param("timeMode") int timeMode);
}
