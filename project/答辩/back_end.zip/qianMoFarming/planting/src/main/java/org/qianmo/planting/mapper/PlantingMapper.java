package org.qianmo.planting.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.planting.dto.FarmIdAndCropId;
import org.qianmo.planting.model.Planting;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface PlantingMapper {
    void addPlanting(Planting planting);

    List<Integer> getCurrentPlantingIdByFieldId(int fieldId);

    List<Integer> getHistoryPlantingIdByFieldId(int fieldId);

    FarmIdAndCropId getFarmIdAndCropId(int plantingId);

    void updateEndDate(@Param("plantingId") int plantingId, @Param("endDate") LocalDateTime endDate);

    int getFieldIdByPlantingId(int plantingId);
}
