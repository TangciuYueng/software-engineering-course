package org.qianmo.planting.service;

import org.qianmo.planting.dto.ActivityDTO;
import org.qianmo.planting.dto.SolveIssueByEquipmentRequest;
import org.springframework.stereotype.Service;

@Service
public interface ActivityService {
    ActivityDTO getActivityById(int activityId);

    Integer solveIssueByEquipment(SolveIssueByEquipmentRequest request);
}
