package org.qianmo.planting.controller;

import org.qianmo.planting.dto.ActivityDTO;
import org.qianmo.planting.dto.SolveIssueByEquipmentRequest;
import org.qianmo.planting.service.ActivityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/activity")
public class ActivityController {

    @Autowired
    private ActivityService activityService;

    @GetMapping("/{activityId}")
    public ResponseEntity<?> getActivityById(@PathVariable("activityId") int activityId) {
        ActivityDTO activityDTO = activityService.getActivityById(activityId);
        if (activityDTO != null) {
            return ResponseEntity.ok(activityDTO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/by_equipment")
    public ResponseEntity<?> solveIssueByEquipment(@RequestBody SolveIssueByEquipmentRequest request) {
        Integer stock = activityService.solveIssueByEquipment(request);
        if (stock != null) {
            return ResponseEntity.ok(stock);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }
}
