package org.qianmo.planting.controller;

import org.apache.ibatis.annotations.Param;
import org.qianmo.planting.dto.HarvestHistoryRespInfo;
import org.qianmo.planting.dto.HarvestRespInfo;
import org.qianmo.planting.dto.HarvestStatistics;
import org.qianmo.planting.service.HarvestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/harvest")
public class HarvestController {
    @Autowired
    private HarvestService harvestService;

    @GetMapping("/current/field/{fieldId}")
    public ResponseEntity<?> getCurrentHarvest(@PathVariable("fieldId") int fieldId) {
        List<HarvestRespInfo> harvestInfos = harvestService.getCurrentHarvest(fieldId);
        if (harvestInfos != null && harvestInfos.size() != 0) {
            return ResponseEntity.ok(harvestInfos);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/info/{harvestId}")
    public ResponseEntity<?> getHarvestInfo(@PathVariable("harvestId") int harvestId) {
        List<HarvestRespInfo> harvestRespInfos = harvestService.getHarvestInfo(harvestId);
        if (harvestRespInfos != null && harvestRespInfos.size() != 0) {
            return ResponseEntity.ok(harvestRespInfos);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/history/field/{fieldId}")
    public ResponseEntity<?> getHistoryHavest(@PathVariable("fieldId") int fieldId) {
        List<HarvestHistoryRespInfo> harvestInfos = harvestService.getHistoryHarvest(fieldId);
        if (harvestInfos != null && harvestInfos.size() != 0) {
            return ResponseEntity.ok(harvestInfos);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/statistics/farm/crop")
    public ResponseEntity<HarvestStatistics> getHarvestStatistics(@RequestParam(value = "farmId", required = false) int farmId,
                                                                  @RequestParam(value = "cropId", required = false) int cropId,
                                                                  @RequestParam(value = "timeMode", required = false) int timeMode) {
        HarvestStatistics statistics = harvestService.getHarvestStatistics(farmId, cropId, timeMode);
        if (statistics != null) {
            return ResponseEntity.ok(statistics);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/finish")
    // 我觉得这函数名得改
    public ResponseEntity<Integer> checkHarvestStatus(@RequestParam("plantingId") int plantingId,
                                                    @RequestParam("endDate") LocalDateTime endDate) {
        Integer res = harvestService.checkHarvestStatus(plantingId, endDate);
        if (res != null && res == 0) {
            return ResponseEntity.ok(res);
        } else {
            return ResponseEntity.badRequest().body(-1);
        }
    }
}
