package org.qianmo.planting.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CropResp {
    private int cropId;
    private String name;
    private int plantingId;
}
