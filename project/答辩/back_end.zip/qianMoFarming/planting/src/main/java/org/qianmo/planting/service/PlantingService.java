package org.qianmo.planting.service;

import org.qianmo.planting.dto.FarmIdAndCropId;
import org.qianmo.planting.dto.PlantingRequest;
import org.qianmo.planting.dto.PlantingResponse;
import org.springframework.stereotype.Service;

@Service
public interface PlantingService {
    PlantingResponse addPlantingAndIssue(PlantingRequest request);

    FarmIdAndCropId getFarmIdAndCropId(int plantingId);
}
