package org.qianmo.planting.controller;

import org.qianmo.planting.dto.FarmIdAndCropId;
import org.qianmo.planting.dto.PlantingRequest;
import org.qianmo.planting.dto.PlantingResponse;
import org.qianmo.planting.service.PlantingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/planting")
public class PlantingController {
    @Autowired
    private PlantingService plantingService;

    @PutMapping
    public ResponseEntity<?> initPlanting(@RequestBody PlantingRequest request) {
        PlantingResponse response = plantingService.addPlantingAndIssue(request);
        if (request != null) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/get_farm_id_and_crop_id/{plantingId}")
    public ResponseEntity<FarmIdAndCropId> getFarmIdAndCropId(@PathVariable("plantingId") int plantingId) {
        FarmIdAndCropId id = plantingService.getFarmIdAndCropId(plantingId);
        if (id != null) {
            return ResponseEntity.ok(id);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
