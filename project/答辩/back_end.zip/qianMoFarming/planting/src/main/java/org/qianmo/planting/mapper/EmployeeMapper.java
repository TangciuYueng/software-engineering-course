package org.qianmo.planting.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.planting.model.Employee;

import java.util.List;

@Mapper
public interface EmployeeMapper {
    List<Employee> getEmployeesById(@Param("employeeIds") List<Integer> employeeIds);

    Employee getEmployeeById(int employeeId);
}
