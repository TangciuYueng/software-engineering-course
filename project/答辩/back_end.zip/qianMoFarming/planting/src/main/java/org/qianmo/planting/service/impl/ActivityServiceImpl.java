package org.qianmo.planting.service.impl;

import org.qianmo.planting.dto.ActivityDTO;
import org.qianmo.planting.dto.SolveIssueByEquipmentRequest;
import org.qianmo.planting.mapper.*;
import org.qianmo.planting.model.Activity;
import org.qianmo.planting.model.Consumables;
import org.qianmo.planting.model.Employee;
import org.qianmo.planting.model.Issue;
import org.qianmo.planting.mapper.*;
import org.qianmo.planting.service.ActivityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.webjars.NotFoundException;

@Service
public class ActivityServiceImpl implements ActivityService {
    @Autowired
    private ActivityMapper activityMapper;
    @Autowired
    private EquipmentMapper equipmentMapper;
    @Autowired
    private ConsumablesMapper consumablesMapper;
    @Autowired
    private EmployeeMapper employeeMapper;
    @Autowired
    private IssueMapper issueMapper;

    @Override
    public ActivityDTO getActivityById(int activityId) {
        try {
            Activity activity = activityMapper.getActivityById(activityId);
            String equipmentName = equipmentMapper.getEquipmentById(activity.getEquipmentId()).getName();
            Consumables consumables = consumablesMapper.getConsumablesById(activity.getConsumablesId());
            Employee employee = employeeMapper.getEmployeeById(activity.getEmployeeId());

            // 查不到对应的 activity
            if (activity == null) {
                throw new NotFoundException("no activity");
            }

            ActivityDTO.ActivityDTOBuilder builder = ActivityDTO.builder()
                    .activityId(activityId)
                    .issueId(activity.getIssueId())
                    .equipmentName(equipmentName)
                    .detail(activity.getDetail())
                    .amount(activity.getAmount())
                    .employeeName(employee.getName())
                    .employeeType(employee.getType());
            // 可能没有对应的 consumables
            if (consumables != null) {
                builder.consumablesName(consumables.getName())
                        .consumablesType(consumables.getType())
                        .consumablesStock(consumables.getStock());
            }
            return builder.build();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    @Transactional
    public Integer solveIssueByEquipment(SolveIssueByEquipmentRequest request) {
        try {
            Activity activity = Activity.builder()
                    .issueId(request.getIssueId())
                    .employeeId(request.getEmployeeId())
                    .equipmentId(request.getEquipmentId())
                    .consumablesId(request.getConsumablesId())
                    .build();
            // 新增 activity
            activityMapper.addActivity(activity);
            // 更新 issue
            Issue issue = Issue.builder()
                    .issueId(request.getIssueId())
                    .addressDate(request.getTime())
                    .build();
            issueMapper.updateIssue(issue);
            // 查询 consumables 的 stock
            if (request.getConsumablesId() != null) {
                Consumables consumables = consumablesMapper.getConsumablesById(request.getConsumablesId());
                return consumables.getStock();
            } else {
                return -1;
            }
        } catch (Exception e) {
            return null;
        }
    }
}
