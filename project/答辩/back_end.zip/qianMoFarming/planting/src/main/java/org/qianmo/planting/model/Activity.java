package org.qianmo.planting.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Activity {
    private int activityId;
    private int issueId;
    private int equipmentId;
    private int consumablesId;
    private String detail;
    private int amount;
    private int employeeId;
}
