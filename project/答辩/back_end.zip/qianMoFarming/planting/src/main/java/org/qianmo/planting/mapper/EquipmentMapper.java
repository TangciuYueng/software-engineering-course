package org.qianmo.planting.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.qianmo.planting.model.Equipment;

@Mapper
public interface EquipmentMapper {
    Equipment getEquipmentById(int equipmentId);
}
