package org.qianmo.planting.service.impl;

import org.qianmo.planting.client.FieldClient;
import org.qianmo.planting.dto.FarmIdAndCropId;
import org.qianmo.planting.dto.PlantingRequest;
import org.qianmo.planting.dto.PlantingResponse;
import org.qianmo.planting.mapper.IssueMapper;
import org.qianmo.planting.mapper.PlantingMapper;
import org.qianmo.planting.model.Issue;
import org.qianmo.planting.model.Planting;
import org.qianmo.planting.service.PlantingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PlantingServieImpl implements PlantingService {
    @Autowired
    private PlantingMapper plantingMapper;

    @Autowired
    private IssueMapper issueMapper;

    @Autowired
    private FieldClient fieldClient;

    @Override
    @Transactional
    public PlantingResponse addPlantingAndIssue(PlantingRequest request) {
        try {
            // 更新 field 状态
            fieldClient.updateFieldStatus(request.getFieldId(), "非空");
            // 新增 planting 记录
            Planting planting = Planting.builder()
                    .fieldId(request.getFieldId())
                    .cropId(request.getCropId())
                    .employeeId(request.getEmployeeId())
                    .build();
            plantingMapper.addPlanting(planting);
            // 新增 issue 记录
            Issue issue = Issue.builder()
                    .type("待种植")
                    .detail("待种植")
                    .plantingId(planting.getPlantingId())       // 自增返回 id 的
                    .employeeId(request.getEmployeeId())
                    .build();
            issueMapper.addIssue(issue);
            // 构造返回值
            PlantingResponse response = PlantingResponse.builder()
                    .plantingId(planting.getPlantingId())
                    .issueId(issue.getIssueId())
                    .build();
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public FarmIdAndCropId getFarmIdAndCropId(int plantingId) {
        try {
            FarmIdAndCropId id = plantingMapper.getFarmIdAndCropId(plantingId);
            return id;
        } catch (Exception e) {
            return null;
        }
    }
}
