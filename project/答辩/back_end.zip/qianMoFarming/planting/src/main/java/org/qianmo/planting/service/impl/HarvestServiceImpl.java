package org.qianmo.planting.service.impl;

import org.qianmo.planting.client.FieldClient;
import org.qianmo.planting.dto.CropResp;
import org.qianmo.planting.dto.HarvestHistoryRespInfo;
import org.qianmo.planting.dto.HarvestRespInfo;
import org.qianmo.planting.dto.HarvestStatistics;
import org.qianmo.planting.mapper.*;
import org.qianmo.planting.model.*;
import org.qianmo.planting.service.HarvestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.webjars.NotFoundException;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class HarvestServiceImpl implements HarvestService {

    @Autowired
    private HarvestMapper harvestMapper;
    @Autowired
    private PlantingMapper plantingMapper;
    @Autowired
    private HarvestInfoMapper harvestInfoMapper;
    @Autowired
    private EmployeeMapper employeeMapper;
    @Autowired
    private IssueMapper issueMapper;
    @Autowired
    private FieldClient fieldClient;

    @Override
    public List<HarvestRespInfo> getCurrentHarvest(int fieldId) {
        try {
            // 找到该田地未结束的种植活动 id
            List<Integer> plantingIds = plantingMapper.getCurrentPlantingIdByFieldId(fieldId);
            if (plantingIds == null || plantingIds.size() == 0) {
                throw new NotFoundException("no planting");
            }
            // 找到 plantingId 对应的 harvests
            List<Harvest> harvests = harvestMapper.getHarvestsByPlantingId(plantingIds);
            if (harvests == null || harvests.size() == 0) {
                throw new NotFoundException("no harvest");
            }
            List<Integer> harvestIds = harvests.stream()
                    .map(Harvest::getHarvestId)
                    .collect(Collectors.toList());
            List<Integer> employeeIds = harvests.stream()
                    .map(Harvest::getEmployeeId)
                    .collect(Collectors.toList());
            // 找到 harvest 对应的 harvestInfo
            List<HarvestInfo> harvestInfos = harvestInfoMapper.getHarvestInfoByHarvestId(harvestIds);
            // 找到 harvest 的处理员工
            List<Employee> employees = employeeMapper.getEmployeesById(employeeIds);

            Map<Integer, String> idToName = employees.stream()
                    .collect(Collectors.toMap(Employee::getEmployeeId, Employee::getName));
            Map<Integer, HarvestRespInfo> harvestRespInfoMap = new HashMap<>();

            for (Harvest harvest: harvests) {
                harvestRespInfoMap.put(harvest.getHarvestId(), HarvestRespInfo.builder()
                        .harvestDate(harvest.getHarvestDate())
                        .employeeName(idToName.get(harvest.getEmployeeId()))
                        .build());
            }
            for (HarvestInfo harvestInfo: harvestInfos) {
                HarvestRespInfo harvestRespInfo = harvestRespInfoMap.get(harvestInfo.getHarvestId());
                if (harvestRespInfo != null) {
                    harvestRespInfo.setQuality(harvestInfo.getQuality());
                    harvestRespInfo.setWeight(harvestInfo.getWeight());
                }
            }
            return harvestRespInfoMap.values().stream().toList();
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    @Override
    public List<HarvestRespInfo> getHarvestInfo(int harvestId) {
        try {
            Harvest harvest = harvestMapper.getHarvestById(harvestId);
            List<HarvestInfo> harvestInfos = harvestInfoMapper.getHarvestInfoByHarvestId(Arrays.asList(harvestId));
            List<Employee> employees = employeeMapper.getEmployeesById(Arrays.asList(harvest.getEmployeeId()));
            Map<Integer, String> idToName = employees.stream()
                    .collect(Collectors.toMap(Employee::getEmployeeId, Employee::getName));

            List<HarvestRespInfo> harvestRespInfos = harvestInfos.stream()
                    .map(harvestInfo -> HarvestRespInfo.builder()
                            .harvestDate(harvest.getHarvestDate())
                            .weight(harvestInfo.getWeight())
                            .quality(harvestInfo.getQuality())
                            .employeeName(idToName.get(harvest.getEmployeeId()))
                            .build()).collect(Collectors.toList());
            return harvestRespInfos;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    @Override
    public List<HarvestHistoryRespInfo> getHistoryHarvest(int fieldId) {
        try {
            // 找到该田地结束的种植活动 id
            List<Integer> plantingIds = plantingMapper.getHistoryPlantingIdByFieldId(fieldId);
            if (plantingIds == null || plantingIds.size() == 0) {
                throw new NotFoundException("no planting");
            }
            // 找到 plantingId 对应的 harvests
            List<Harvest> harvests = harvestMapper.getHarvestsByPlantingId(plantingIds);
            if (harvests == null || harvests.size() == 0) {
                throw new NotFoundException("no harvest");
            }
            // 找到 plantingId 对应的 cropName
            List<CropResp> cropResps = fieldClient.getCropByPlantingId(plantingIds).getBody();
            Map<Integer, String> plantingIdToCropName = cropResps.stream()
                    .collect(Collectors.toMap(CropResp::getPlantingId, CropResp::getName));

            List<Integer> harvestIds = harvests.stream()
                    .map(Harvest::getHarvestId)
                    .collect(Collectors.toList());
            List<Integer> employeeIds = harvests.stream()
                    .map(Harvest::getEmployeeId)
                    .collect(Collectors.toList());
            // 找到 harvest 对应的 harvestInfo
            List<HarvestInfo> harvestInfos = harvestInfoMapper.getHarvestInfoByHarvestId(harvestIds);
            // 找到 harvest 的处理员工
            List<Employee> employees = employeeMapper.getEmployeesById(employeeIds);
            Map<Integer, String> idToName = employees.stream()
                    .collect(Collectors.toMap(Employee::getEmployeeId, Employee::getName));

            Map<Integer, HarvestHistoryRespInfo> harvestRespInfoMap = new HashMap<>();
            for (Harvest harvest: harvests) {
                harvestRespInfoMap.put(harvest.getHarvestId(), HarvestHistoryRespInfo.builder()
                        .harvestDate(harvest.getHarvestDate())
                        .employeeName(idToName.get(harvest.getEmployeeId()))
                        .cropName(plantingIdToCropName.get(harvest.getPlantingId()))
                        .build());
            }
            for (HarvestInfo harvestInfo: harvestInfos) {
                HarvestHistoryRespInfo harvestRespInfo = harvestRespInfoMap.get(harvestInfo.getHarvestId());
                if (harvestRespInfo != null) {
                    harvestRespInfo.setQuality(harvestInfo.getQuality());
                    harvestRespInfo.setWeight(harvestInfo.getWeight());
                }
            }
            return harvestRespInfoMap.values().stream().toList();
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    @Override
    public HarvestStatistics getHarvestStatistics(int farmId, int cropId, int timeMode) {
        try {
            List<Integer> harvestIds = harvestMapper.getStatisticsIds(farmId, cropId, timeMode);
            System.out.println(harvestIds);
            if (harvestIds == null || harvestIds.size() == 0) {
                throw new NotFoundException("no data");
            }
            List<QualityAndWeight> qualityAndWeights = harvestInfoMapper.getStatisticsByHarvestId(harvestIds);
            System.out.println(qualityAndWeights);
            HarvestStatistics statistics = getHarvestStatistics(qualityAndWeights);
            return statistics;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    @Transactional
    public Integer checkHarvestStatus(int plantingId, LocalDateTime endDate) {
        try {
            List<Issue> issues = issueMapper.getUnfinishedIssueByPlantingId(plantingId);
            // 有事项未解决
            if (issues != null && issues.size() > 0) {
                return null;
            }
            // 获得对应 fieldId
            int fieldId = plantingMapper.getFieldIdByPlantingId(plantingId);
            // 更新 planting endDate
            plantingMapper.updateEndDate(plantingId, endDate);
            // 更新 field status
            Integer res = fieldClient.updateFieldStatus(fieldId, "空").getBody();
            if (res == null || res != 0) {
                return null;
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static HarvestStatistics getHarvestStatistics(List<QualityAndWeight> qualityAndWeights) {
        HarvestStatistics statistics = new HarvestStatistics();
        for (QualityAndWeight qualityAndWeight: qualityAndWeights) {
            if (qualityAndWeight.getQuality().equals("特级")) {
                statistics.setSpecialGradeCount(qualityAndWeight.getWeight());
            } else if (qualityAndWeight.getQuality().equals("一级")) {
                statistics.setFirstGradeCount(qualityAndWeight.getWeight());
            } else {
                statistics.setSecondGradeCount(qualityAndWeight.getWeight());
            }
        }
        return statistics;
    }
}
