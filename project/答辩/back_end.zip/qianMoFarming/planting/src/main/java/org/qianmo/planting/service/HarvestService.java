package org.qianmo.planting.service;

import org.qianmo.planting.dto.HarvestHistoryRespInfo;
import org.qianmo.planting.dto.HarvestRespInfo;
import org.qianmo.planting.dto.HarvestStatistics;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public interface HarvestService {
    List<HarvestRespInfo> getCurrentHarvest(int fieldId);

    List<HarvestRespInfo> getHarvestInfo(int harvestId);

    List<HarvestHistoryRespInfo> getHistoryHarvest(int fieldId);

    HarvestStatistics getHarvestStatistics(int farmId, int cropId, int timeMode);

    Integer checkHarvestStatus(int plantingId, LocalDateTime endDate);
}
