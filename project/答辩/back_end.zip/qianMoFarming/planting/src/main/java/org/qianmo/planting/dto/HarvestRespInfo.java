package org.qianmo.planting.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HarvestRespInfo {
    private LocalDateTime harvestDate;
    private String quality;
    private Integer weight;
    private String employeeName;
}
