package org.qianmo.planting.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.qianmo.planting.model.Consumables;

@Mapper
public interface ConsumablesMapper {

    Consumables getConsumablesById(int consumablesId);
}
