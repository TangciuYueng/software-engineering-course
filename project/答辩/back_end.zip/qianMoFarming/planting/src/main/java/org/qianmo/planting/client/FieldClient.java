package org.qianmo.planting.client;

import org.qianmo.planting.dto.CropResp;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(value = "field-service")
public interface FieldClient {
    @PutMapping("/api/field/{fieldId}/status/{status}")
    ResponseEntity<Integer> updateFieldStatus(@PathVariable("fieldId") int fieldId, @PathVariable("status") String status);
    @GetMapping("/api/crop/name/planting")
    ResponseEntity<List<CropResp>> getCropByPlantingId(@RequestParam(value = "plantingIds") List<Integer> plantingIds);
}