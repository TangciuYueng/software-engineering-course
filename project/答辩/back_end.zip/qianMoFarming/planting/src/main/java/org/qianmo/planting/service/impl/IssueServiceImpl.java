package org.qianmo.planting.service.impl;

import org.qianmo.planting.common.Page;
import org.qianmo.planting.dto.IssueDTO;
import org.qianmo.planting.dto.IssueRequest;
import org.qianmo.planting.mapper.EmployeeMapper;
import org.qianmo.planting.mapper.HarvestMapper;
import org.qianmo.planting.mapper.IssueMapper;
import org.qianmo.planting.model.Employee;
import org.qianmo.planting.model.Harvest;
import org.qianmo.planting.model.Issue;
import org.qianmo.planting.service.IssueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.webjars.NotFoundException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class IssueServiceImpl implements IssueService {
    private static final String UNHARVEST = "待收获";
    @Autowired
    private IssueMapper issueMapper;
    @Autowired
    private EmployeeMapper employeeMapper;
    @Autowired
    private HarvestMapper harvestMapper;

    @Override
    public Page<IssueDTO> getIssuesByFieldId(int fieldId, int page, int size) {
        try {
            int startIndex = (page - 1) * size;
            // 首先通过 fieldId 找到对应的未完成的 planting 对应的 issue
            List<Issue> unfinishedIssue = issueMapper.getUnfinishedIssueByFieldId(fieldId, startIndex, size);
            // 查找总数量
            int IssueCount = issueMapper.getUnfinishedIssueCountByFieldId(fieldId);
            // 构造总页数
            int total = (int) Math.ceil((double) IssueCount / size);
            // 没有就不用继续查询
            if (IssueCount == 0) {
                throw new NotFoundException("no unfinished issue");
            }
            // 获得对应的 employeeId
            List<Integer> employeeIds = unfinishedIssue.stream()
                    .map(Issue::getEmployeeId)
                    .collect(Collectors.toList());
            // 获得 issues 涉及到的员工
            List<Employee> employees = employeeMapper.getEmployeesById(employeeIds);
            Map<Integer, String> idToName = employees.stream()
                    .collect(Collectors.toMap(Employee::getEmployeeId, Employee::getName));
            // 获得 类型为 未收获 的 plantingId
            List<Integer> plantingIds = unfinishedIssue.stream()
                    .filter(issue -> issue.getType().equals(UNHARVEST))
                    .map(Issue::getPlantingId)
                    .collect(Collectors.toList());
            List<Harvest> harvests;
            if (!plantingIds.isEmpty()) {
                // 获得 未收获 issue 对应的 harvestId
                harvests = harvestMapper.getHarvestsByPlantingId(plantingIds);
            } else {
                harvests = null;
            }
            // 构造 IssueDTO 列表
            List<IssueDTO> issueDTOS = unfinishedIssue.stream()
                    .map(issue -> IssueDTO.builder()
                            .issueId(issue.getIssueId())
                            .type(issue.getType())
                            .startDate(issue.getStartDate())
                            .addressDate(issue.getAddressDate())
                            .endDate(issue.getEndDate())
                            .plantingId(issue.getPlantingId())
                            .detail(issue.getDetail())
                            .employeeName(idToName.get(issue.getEmployeeId()))
                            .harvestId(getHarvestId(issue, harvests))
                            .build())
                    .collect(Collectors.toList());
            // 构造返回类型
            Page<IssueDTO> result = Page.<IssueDTO>builder()
                    .page(page)
                    .size(size)
                    .data(issueDTOS)
                    .total(total)
                    .build();
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Integer addIssue(IssueRequest request) {
        try {
            Issue issue = Issue.builder()
                    .type(request.getType())
                    .employeeId(request.getEmployeeId())
                    .plantingId(request.getPlantingId())
                    .detail(request.getDetail())
                    .build();
            issueMapper.addIssue(issue);
            return issue.getIssueId();
        } catch (Exception e) {
            return null;
        }
    }

    private int getHarvestId(Issue issue, List<Harvest> harvests) {
        if (issue.getType().equals(UNHARVEST)) {
            return harvests.stream()
                    .filter(harvest -> harvest.getPlantingId() == issue.getPlantingId())
                    .map(Harvest::getHarvestId)
                    .findFirst()
                    .orElse(0);
        } else {
            return 0;
        }
    }
}
