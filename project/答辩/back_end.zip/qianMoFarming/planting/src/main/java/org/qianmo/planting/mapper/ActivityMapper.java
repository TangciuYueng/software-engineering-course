package org.qianmo.planting.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.qianmo.planting.model.Activity;

@Mapper
public interface ActivityMapper {
    Activity getActivityById(int activityId);

    void addActivity(Activity activity);
}
