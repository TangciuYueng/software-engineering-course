package org.qianmo.planting.controller;

import org.qianmo.planting.common.Page;
import org.qianmo.planting.dto.IssueDTO;
import org.qianmo.planting.dto.IssueRequest;
import org.qianmo.planting.service.IssueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/issue")
public class IssueController {
    @Autowired
    private IssueService issueService;

    @GetMapping("/field/{filedId}")
    public ResponseEntity<?> getIssuesByFieldId(
            @PathVariable("filedId") int fieldId,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        Page<IssueDTO> issuePage = issueService.getIssuesByFieldId(fieldId, page, size);
        if (issuePage != null) {
            return ResponseEntity.ok(issuePage);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<?> addIssue(@RequestBody IssueRequest request) {
        Integer newId = issueService.addIssue(request);
        if (newId != null) {
            return ResponseEntity.ok(newId);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }
}
