package org.qianmo.planting.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HarvestInfo {
    private int harvestInfoId;
    private String quality;
    private int weight;
    private int harvestId;
}
