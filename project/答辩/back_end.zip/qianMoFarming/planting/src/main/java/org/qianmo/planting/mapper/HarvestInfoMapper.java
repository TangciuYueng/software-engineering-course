package org.qianmo.planting.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.planting.model.HarvestInfo;
import org.qianmo.planting.model.QualityAndWeight;

import java.util.List;

@Mapper
public interface HarvestInfoMapper {
    List<HarvestInfo> getHarvestInfoByHarvestId(@Param("harvestIds") List<Integer> harvestIds);

    List<QualityAndWeight> getStatisticsByHarvestId(@Param("harvestIds") List<Integer> harvestIds);
}
