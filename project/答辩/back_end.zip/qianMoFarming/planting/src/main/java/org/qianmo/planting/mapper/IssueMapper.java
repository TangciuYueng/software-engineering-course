package org.qianmo.planting.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.planting.model.Issue;

import java.util.List;

@Mapper
public interface IssueMapper {
    List<Issue> getUnfinishedIssueByFieldId(@Param("fieldId") int fieldId, @Param("startIndex") int startIndex, @Param("size") int size);

    int getUnfinishedIssueCountByFieldId(int fieldId);

    void addIssue(Issue issue);

    void updateIssue(Issue issue);

    List<Issue> getUnfinishedIssueByPlantingId(int plantingId);
}
