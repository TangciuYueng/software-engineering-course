package org.qianmo.planting.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ActivityDTO {
    private int activityId;
    private int issueId;
    private String equipmentName;
    private String consumablesName;
    private double consumablesStock;
    private String consumablesType;
    private String detail;
    private int amount;
    private String employeeName;
    private int employeeType;
    private String type;
}
