package org.qianmo.asset.service.impl;

import org.qianmo.asset.common.Page;
import org.qianmo.asset.dto.ConsumablesDTO;
import org.qianmo.asset.dto.ConsumablesRequest;
import org.qianmo.asset.mapper.ConsumablesMapper;
import org.qianmo.asset.model.Consumables;
import org.qianmo.asset.model.Equipment;
import org.qianmo.asset.service.ConsumablesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ConsumablesServiceImpl implements ConsumablesService {
    @Autowired
    private ConsumablesMapper consumablesMapper;
    @Override
    public Page<Consumables> getConsumables(int farmId, int page, int size) {
        try {
            int startIndex = (page - 1) * size;
            List<Consumables> consumablesList = consumablesMapper.getConsumables(farmId, startIndex, page);
            int count = consumablesMapper.getConsumablesCount(farmId);
            int total = (int) Math.ceil((double) count / size);
            Page<Consumables> result = Page.<Consumables>builder()
                    .page(page)
                    .size(size)
                    .data(consumablesList)
                    .total(total)
                    .build();
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Integer addConsumables(ConsumablesRequest request) {
        try {
            Consumables consumables = Consumables.builder()
                    .type(request.getType())
                    .name(request.getName())
                    .unit(request.getUnit())
                    .stock(request.getStock())
                    .farmId(request.getFarmId())
                    .build();
            consumablesMapper.addConsumables(consumables);
            return consumables.getConsumablesId();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Equipment> getAppropriateConsumables(int farmId, String type) {
        return null;
    }

    @Override
    public void editConsumables(ConsumablesDTO consumablesDTO) {

        consumablesMapper.updateConsumables(consumablesDTO);
    }
}
