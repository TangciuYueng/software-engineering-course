package org.qianmo.asset.service;

import org.qianmo.asset.common.Page;
import org.qianmo.asset.dto.EquipmentRequest;
import org.qianmo.asset.dto.MaintainRequest;
import org.qianmo.asset.model.Equipment;
import org.qianmo.asset.model.Maintenance;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface EquipmentService {
    Page<Equipment> getEquipment(int farmId, int page, int size);
    void useEquipment(int equipmentId);
    void freeEquipment(int equipmentId);
    void maintainEquipment(MaintainRequest maintainRequest);
    void discardEquipment(int equipmentId);
    List<Maintenance> getMaintenanceHistory(int equipmentId);
    List<Equipment> getAppropriateEquipment(int farmId,String type);//找到合适的equipment type是比如挖掘机
    Integer addEquipment(EquipmentRequest request);
}
