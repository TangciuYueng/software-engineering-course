package org.qianmo.asset.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.qianmo.asset.model.Equipment;

import java.time.LocalDateTime;
import java.util.List;
@Mapper
public interface EquipmentMapper {
    List<Equipment> getEquipment(int farmId, int startIndex, int page);
    int getEquipmentCount(int farmId);

    void addEquipment(Equipment equipment);

    void updateEquipmentStatus(int equipmentId,String status);
//    void useEquipment(int equipmentId);
//
//    void freeEquipment(int equipmentId);
//
//    void maintainEquipment(int equipmentId);



    void discardEquipment(int equipmentId, LocalDateTime now);
}
