package org.qianmo.asset.controller;

import org.qianmo.asset.common.Page;
import org.qianmo.asset.dto.EquipmentRequest;
import org.qianmo.asset.dto.MaintainRequest;
import org.qianmo.asset.model.Equipment;
import org.qianmo.asset.model.Maintenance;
import org.qianmo.asset.service.EquipmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/equipment")
public class EquipmentController {
    @Autowired
    private EquipmentService equipmentService;


    @GetMapping("maintenance/{equipmentId}")
    public ResponseEntity<?> getEquipmentMaintenance(@PathVariable int equipmentId) {
        List<Maintenance> maintenance = equipmentService.getMaintenanceHistory(equipmentId);
        if(maintenance!=null)
            return ResponseEntity.ok(maintenance);
        else
            return ResponseEntity.status(500).build();
    }
    @PostMapping("/add_maintenance")
    public ResponseEntity<String> addMaintenance(@RequestBody MaintainRequest maintainRequest) {
        equipmentService.maintainEquipment(maintainRequest);
        return ResponseEntity.ok("Maintenance record added successfully!");
    }

    @PostMapping("add_equipment/farm/{farmId}")
    public ResponseEntity<?> addEquipment(@PathVariable("farmId") int farmId,
                                            @RequestBody EquipmentRequest request) {
        Integer newId = equipmentService.addEquipment(request);
        if (newId != null) {
            return ResponseEntity.ok(newId);
        } else {
            return ResponseEntity.status(500).build();
        }
    }

    @GetMapping("get_info/farm/{farmId}")
    public ResponseEntity<?> getEquipment(@PathVariable("farmId") int farmId,
                                            @RequestParam(defaultValue = "1") int page,
                                            @RequestParam(defaultValue = "10") int size) {
        Page<Equipment> equipmentDTOS = equipmentService.getEquipment(farmId, page, size);
        if (equipmentDTOS != null) {
            return ResponseEntity.ok(equipmentDTOS);
        } else {
            return ResponseEntity.status(500).build();
        }
    }
    @PostMapping("/use/{equipmentId}")
    public ResponseEntity<String> useEquipment(@PathVariable int equipmentId) {
        equipmentService.useEquipment(equipmentId);
        return ResponseEntity.ok("Equipment is in use!");
    }

    @PostMapping("/free/{equipmentId}")
    public ResponseEntity<String> freeEquipment(@PathVariable int equipmentId) {
        equipmentService.freeEquipment(equipmentId);
        return ResponseEntity.ok("Equipment is free!");
    }

    @PostMapping("/discard/{equipmentId}")
    public ResponseEntity<String> discardEquipment(@PathVariable int equipmentId) {
        equipmentService.discardEquipment(equipmentId);
        return ResponseEntity.ok("Equipment is discarded!");
    }

}
