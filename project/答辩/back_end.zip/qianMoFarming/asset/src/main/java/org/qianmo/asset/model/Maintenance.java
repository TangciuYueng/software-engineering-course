package org.qianmo.asset.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Maintenance {
    private int maintenanceId;
    private int employeeId;
    private int equipmentId;
    private String detail;
    private LocalDateTime maintenanceDate;
    private double cost;

}
