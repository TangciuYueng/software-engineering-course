package org.qianmo.asset.controller;

import io.swagger.v3.oas.annotations.Operation;
import org.qianmo.asset.common.Page;
import org.qianmo.asset.dto.ConsumablesRequest;
import org.qianmo.asset.dto.ConsumablesDTO;
import org.qianmo.asset.model.Consumables;
import org.qianmo.asset.service.ConsumablesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/consumables")
public class ConsumablesController {
    @Autowired
    private ConsumablesService consumablesService;

    // @Operation(summary = "普通body请求")
    @GetMapping("/farm/{farmId}")
    public ResponseEntity<?> getConsumables(@PathVariable("farmId") int farmId,
                                            @RequestParam(defaultValue = "1") int page,
                                            @RequestParam(defaultValue = "10") int size) {
        Page<Consumables> consumablesDTOS = consumablesService.getConsumables(farmId, page, size);
        if (consumablesDTOS != null) {
            return ResponseEntity.ok(consumablesDTOS);
        } else {
            return ResponseEntity.status(500).build();
        }
    }
    @PostMapping("/farm/{farmId}")
    public ResponseEntity<?> addConsumables(@PathVariable("farmId") int farmId,
                                            @RequestBody ConsumablesRequest request) {
        Integer newId = consumablesService.addConsumables(request);
        if (newId != null) {
            return ResponseEntity.ok(newId);
        } else {
            return ResponseEntity.status(500).build();
        }
    }

    @PostMapping("/consumables_edit/{consumablesId}")
    public ResponseEntity<?> editConsumables(@PathVariable("consumablesId") int consumablesIdI,
                                             @RequestBody ConsumablesDTO consumablesDTO) {
        consumablesService.editConsumables(consumablesDTO);
        return ResponseEntity.ok("Consumables edited successfully!");

    }


}
