package org.qianmo.asset.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.qianmo.asset.model.Maintenance;

import java.util.List;

@Mapper
public interface MaintenanceMapper {

    void addMaintenance(Maintenance maintenance);

    List<Maintenance> getEquipmentMaintenance(int equipmentId);
}
