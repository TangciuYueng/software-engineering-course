package org.qianmo.asset.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConsumablesRequest {
    private String name;
    private String type;
    private int stock;
    private String unit;
    private int farmId;
}
