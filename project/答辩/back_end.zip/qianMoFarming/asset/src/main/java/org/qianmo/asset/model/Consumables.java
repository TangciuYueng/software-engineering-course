package org.qianmo.asset.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Consumables {
    private int consumablesId;
    private String name;
    private String type;
    private int stock;
    private String unit;
    private int farmId;
}
