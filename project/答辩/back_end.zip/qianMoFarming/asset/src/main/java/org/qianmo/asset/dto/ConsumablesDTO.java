package org.qianmo.asset.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConsumablesDTO {
    private int consumablesId;
    private String name;
    private int stock;
    private String unit;
}
