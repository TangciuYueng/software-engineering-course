package org.qianmo.asset.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Employee {
    private int employeeId;
    private String name;
    private String password;
    private String phoneNumber;
    private String apiKey;
    private int type;
}
