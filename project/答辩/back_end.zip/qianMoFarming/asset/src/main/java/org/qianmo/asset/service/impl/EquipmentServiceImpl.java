package org.qianmo.asset.service.impl;

import org.qianmo.asset.common.Page;
import org.qianmo.asset.dto.EquipmentRequest;
import org.qianmo.asset.dto.MaintainRequest;
import org.qianmo.asset.model.Equipment;
import org.qianmo.asset.model.Maintenance;
import org.qianmo.asset.service.EquipmentService;
import org.qianmo.asset.mapper.EquipmentMapper;
import org.qianmo.asset.mapper.MaintenanceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

@Service
public class EquipmentServiceImpl implements EquipmentService {
    @Autowired
    private EquipmentMapper equipmentMapper;
    @Autowired
    private MaintenanceMapper maintenanceMapper;
    @Override
    public Page<Equipment> getEquipment(int farmId, int page, int size)
    {
        try {
            int startIndex = (page - 1) * size;
            List<Equipment> equipmentList = equipmentMapper.getEquipment(farmId, startIndex, page);
            int count = equipmentMapper.getEquipmentCount(farmId);
            int total = (int) Math.ceil((double) count / size);
            Page<Equipment> result = Page.<Equipment>builder()
                    .page(page)
                    .size(size)
                    .data(equipmentList)
                    .total(total)
                    .build();
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    @Override
    public Integer addEquipment(EquipmentRequest request)
    {
        try {
            Equipment equipment = Equipment.builder()
                    .type(request.getType())
                    .name(request.getName())
                    .startDate(LocalDateTime.now(ZoneId.of("Asia/Shanghai")))
                    .endDate(LocalDateTime.parse("null"))
                    .status("空闲")
                    .farmId(request.getFarmId())
                    .build();
            equipmentMapper.addEquipment(equipment);
            return equipment.getEquipmentId();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    @Override
    public void useEquipment(int equipmentId)
    {
        equipmentMapper.updateEquipmentStatus(equipmentId,"使用");
    }

    @Override
    public void freeEquipment(int equipmentId)
    {
        equipmentMapper.updateEquipmentStatus(equipmentId,"空闲");
    }

    @Override
    public void maintainEquipment(MaintainRequest maintainRequest)
    {

        Maintenance maintenance=Maintenance.builder()
                        .equipmentId(maintainRequest.getEquipmentId())
                        .maintenanceDate(maintainRequest.getStartDate())
                        .detail(maintainRequest.getDetail())
                        .cost(maintainRequest.getCost())
                        .employeeId(maintainRequest.getEmployeeId())
                        .build();
        maintenanceMapper.addMaintenance(maintenance);
    }


    @Override
    public void discardEquipment(int equipmentId)
    {
        equipmentMapper.discardEquipment(equipmentId,(LocalDateTime.now(ZoneId.of("Asia/Shanghai"))));
    }

    @Override
    public List<Maintenance> getMaintenanceHistory(int equipmentId) {
        return maintenanceMapper.getEquipmentMaintenance(equipmentId);
    }

    @Override
    public List<Equipment> getAppropriateEquipment(int farmId, String type) {
        return null;
    }


}
