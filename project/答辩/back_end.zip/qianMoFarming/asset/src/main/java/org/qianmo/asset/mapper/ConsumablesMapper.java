package org.qianmo.asset.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.asset.dto.ConsumablesDTO;
import org.qianmo.asset.model.Consumables;

import java.util.List;

@Mapper
public interface ConsumablesMapper {
    List<Consumables> getConsumables(@Param("farmId") int farmId, @Param("startIndex") int startIndex, @Param("size") int size);

    int getConsumablesCount(int farmId);

    void addConsumables(Consumables consumables);

    void updateConsumables(ConsumablesDTO consumablesDTO);
}
