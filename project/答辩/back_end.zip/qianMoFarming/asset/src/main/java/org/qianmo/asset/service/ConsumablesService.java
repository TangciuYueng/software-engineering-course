package org.qianmo.asset.service;

import org.qianmo.asset.common.Page;
import org.qianmo.asset.dto.ConsumablesDTO;
import org.qianmo.asset.dto.ConsumablesRequest;
import org.qianmo.asset.model.Consumables;
import org.qianmo.asset.model.Equipment;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ConsumablesService {
    Page<Consumables> getConsumables(int farmId, int page, int size);

    Integer addConsumables(ConsumablesRequest request);
    List<Equipment> getAppropriateConsumables(int farmId, String type);
    void editConsumables(ConsumablesDTO consumablesDTO);
}
