package org.qianmo.farm.service;

import org.qianmo.farm.dto.FarmDTO;
import org.qianmo.farm.dto.FarmInfo;
import org.qianmo.farm.dto.FarmRequest;
import org.qianmo.farm.model.Farm;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public interface FarmService {
    FarmInfo getFarm(int page);

    List<Farm> getFarmInfo(int farmId);

    Integer addFarm(FarmRequest request);

    Integer updateFarm(FarmDTO farmDTO);

    Integer NameToId(String farmName);
}
