package org.qianmo.farm.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Weather {
    private int farmId;
    private LocalDateTime recordDate;
    private int highTemp;
    private int lowTemp;
    private double precipitation;
    private int humidity;
    private int wind;
    private String weather;
}
