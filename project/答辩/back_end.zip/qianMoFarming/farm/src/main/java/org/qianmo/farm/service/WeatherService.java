package org.qianmo.farm.service;

import org.qianmo.farm.model.Weather;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.util.List;

@Service
public interface WeatherService {
    List<Weather> getWeather(int farmId, int mode);
}
