package org.qianmo.farm.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.qianmo.farm.mapper.FarmMapper;
import org.qianmo.farm.mapper.WeatherMapper;
import org.qianmo.farm.model.Farm;
import org.qianmo.farm.model.Weather;
import org.qianmo.farm.service.WeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class WeatherServiceImpl implements WeatherService {
    @Autowired
    private WeatherMapper weatherMapper;
    @Autowired
    private FarmMapper farmMapper;

    @Override
    public List<Weather> getWeather(int farmId, int mode) {
        try {
            // 获取当前时间
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime startDate;
            switch (mode) {
                case 0: // 当前一个月
                    startDate = now.minusMonths(1);
                    break;
                case 1: // 当前一季度
                    startDate = now.minusMonths(3);
                    break;
                case 2: // 当前半年
                    startDate = now.minusMonths(6);
                    break;
                case 3: // 当前一年
                    startDate = now.minusYears(1);
                    break;
                default:
                    startDate = now;
                    break;
            }
            List<Weather> weatherList = weatherMapper.getWeather(farmId, startDate, now);
            return weatherList;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private String  getWeatherData(String city) {
        try {
            // 通过外部 API 获取今天的天气
            String apiUrl = "https://www.mxnzp.com/api/weather/current/";
            String apiKey = "pqjcdnrexf0ioqrc";
            String apiSecret = "UNWMYYDufaAn9tmDumKyedwi7B79XMzT";

            StringBuilder apiUrlBuilder = new StringBuilder(apiUrl)
                    .append(city)
                    .append("?app_id=").append(apiKey)
                    .append("&app_secret=").append(apiSecret);

            URL url = new URL(apiUrlBuilder.toString());
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("GET");

            // 请求是否成功
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                    StringBuilder response = new StringBuilder();
                    String inputLine;

                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }

                    return String.valueOf(response);
                }
            } else {
                throw new RuntimeException("Failed to fetch weather data. HTTP error code: " + responseCode);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    // 每天凌晨 0 点执行
    @Scheduled(cron = "0 0 0 * * ?")
    private void getWeatherToday() {
        try {
            int pageSize = 10;  // 设置每页大小，根据实际情况调整
            int currentPage = 1;

            // 分页获取农场信息
            List<Farm> farms;
            do {
                farms = farmMapper.getFarmByPage(currentPage, pageSize);

                // 遍历每个农场
                for (Farm farm : farms) {
                    // 获取农场的位置
                    String city = farm.getLocation();

                    // 调用 getWeatherData 方法获取天气数据
                    String data = getWeatherData(city);

                    // 解析天气数据（根据实际响应结构进行修改）
                    Weather weather = parseWeatherData(data); // 实现此方法以解析天气数据

                    // 将天气数据添加到数据库
                    if (weather != null) {
                        weather.setFarmId(farm.getFarmId());
                        weather.setRecordDate(LocalDateTime.now());
                        weatherMapper.addWeather(weather);
                    }
                }

                currentPage++;
            } while (!farms.isEmpty());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Weather parseWeatherData(String data) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(data, Weather.class);
    }

}
