package org.qianmo.farm.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.farm.model.Weather;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface WeatherMapper {
    List<Weather> getWeather(@Param("farmId") int farmId, @Param("startDate") LocalDateTime startDate, @Param("now") LocalDateTime now);

    void addWeather(Weather weather);
}
