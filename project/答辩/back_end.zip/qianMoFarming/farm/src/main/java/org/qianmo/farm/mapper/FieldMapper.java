package org.qianmo.farm.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.farm.model.Field;

import java.util.List;

@Mapper
public interface FieldMapper {
    List<Field> getFieldByFarmId(int farmId);
}
