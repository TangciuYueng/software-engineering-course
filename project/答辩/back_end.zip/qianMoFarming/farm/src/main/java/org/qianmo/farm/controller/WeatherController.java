package org.qianmo.farm.controller;

import org.qianmo.farm.model.Weather;
import org.qianmo.farm.service.WeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/weather")
public class WeatherController {
    @Autowired
    private WeatherService weatherService;
    // 通过农场 Id 获取天气信息
    @GetMapping("/farm/{farmId}/{mode}")
    public ResponseEntity<?> getWeather(@PathVariable("farmId") int farmId,
                                        @PathVariable("mode") int mode) {
        List<Weather> weatherList = weatherService.getWeather(farmId, mode);
        if (weatherList != null) {
            return ResponseEntity.ok(weatherList);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }
}
