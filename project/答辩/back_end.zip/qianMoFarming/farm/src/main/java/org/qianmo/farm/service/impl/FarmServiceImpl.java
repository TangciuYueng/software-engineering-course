package org.qianmo.farm.service.impl;

import org.qianmo.farm.dto.FarmInfo;
import org.qianmo.farm.dto.FarmDTO;
import org.qianmo.farm.dto.FarmRequest;
import org.qianmo.farm.mapper.FarmMapper;
import org.qianmo.farm.model.Farm;
import org.qianmo.farm.service.FarmService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FarmServiceImpl implements FarmService {

    private static final int PAGE_SIZE = 5;
    @Autowired
    private FarmMapper farmMapper;

    @Override
    public FarmInfo getFarm(int page) {
        int startIndex = (page - 1) * PAGE_SIZE;
        List<Farm> farms = farmMapper.getFarmByPage(startIndex, PAGE_SIZE);
        int farmCount = farmMapper.getFarmCount();
        int totalPage = (int) Math.ceil((double) farmCount / PAGE_SIZE);
        FarmInfo farmInfo = FarmInfo.builder()
                .farms(farms)
                .page(page)
                .totalPage(totalPage)
                .build();
        return farmInfo;
    }
    public List<Farm> getFarmInfo(int farmId) {
        List<Farm> farms = farmMapper.getFarmById(farmId);
        return farms;
    }


    public Integer addFarm(FarmRequest request) {
        try {
            Farm farm = Farm.builder().name(request.getName()).location(request.getLocation()).build();
            this.farmMapper.addFarm(farm);
            return farm.getFarmId();
        } catch (Exception var3) {
            return null;
        }
    }

    public Integer updateFarm(FarmDTO farmDTO) {
        try {
            Farm farm=Farm.builder().farmId(farmDTO.getFarm_id()).name(farmDTO.getName()).location(farmDTO.getLocation()).build();
            this.farmMapper.updateFarm(farm);
            return farm.getFarmId();
        } catch (Exception var3) {
            return null;
        }
    }

    @Override
    public Integer NameToId(String farmName) {
        try {
            // 限制只获取一条记录的 id
            Integer id = farmMapper.getIdByName(farmName);
            return id;
        } catch (Exception e) {
            return null;
        }
    }
}
