package org.qianmo.farm.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.farm.model.Farm;

import java.util.List;

@Mapper
public interface FarmMapper {
    List<Farm> getFarmByPage(@Param("startIndex") int startIndex, @Param("pageSize") int pageSize);

    List<Farm> getFarmById(@Param("farmId") int farm_id);
    int getFarmCount();
    void addFarm(Farm farm);

    void updateFarm(Farm farm);

    Integer getIdByName(String farmName);
}
