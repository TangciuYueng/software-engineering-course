package org.qianmo.farm.controller;

import jakarta.annotation.Resource;
import org.qianmo.farm.model.Field;
import org.qianmo.farm.service.FieldService;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("/api/field")
public class FieldController {
    @Resource
    private FieldService fieldService;

    // 获取农场中的对应所有田地
    @GetMapping("farm/{farmId}")
    public List<Field> getFieldByFarmId(@PathVariable("farmId") int farmId) {
        return fieldService.getFieldByFarmId(farmId);
    }


}
