package org.qianmo.farm.service;
import org.qianmo.farm.model.Field;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public interface FieldService {
    List<Field> getFieldByFarmId(int farmId);

}
