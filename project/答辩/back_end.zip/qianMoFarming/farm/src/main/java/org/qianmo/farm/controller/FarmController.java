package org.qianmo.farm.controller;

import org.qianmo.farm.dto.FarmDTO;
import org.qianmo.farm.dto.FarmInfo;
import org.qianmo.farm.dto.FarmRequest;
import org.qianmo.farm.model.Farm;
import org.qianmo.farm.service.FarmService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/api/farm")
public class FarmController {
    @Autowired
    private FarmService farmService;

    // 获取所有的farm信息
    @GetMapping("/getFarm/{page}")
    public FarmInfo getFarm(@PathVariable("page") int page) {
        return farmService.getFarm(page);
    }

    @GetMapping("/getFarmInfo/{farmId}")
    public List<Farm> getFarmInfo(@PathVariable("farmId") int farmId) {
        return farmService.getFarmInfo(farmId);
    }

    @PostMapping("/addFarm")
    public ResponseEntity<?> addFarm(@RequestBody FarmRequest request) {
        Integer newId;
        newId = farmService.addFarm(request);
        if (newId != null) {
            return ResponseEntity.ok(newId);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }
    @PutMapping("/updateFarm")
    public ResponseEntity<?> updateFarm(@RequestBody FarmDTO farmDTO) {
        Integer newId;
        newId = farmService.updateFarm(farmDTO);
        if (newId != null) {
            return ResponseEntity.ok(newId);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/{farmName}/to_id")
    public ResponseEntity<Integer> farmNameToId(@PathVariable("farmName") String farmName) {
        Integer id = farmService.NameToId(farmName);
        if (id != null && id > 0) {
            return ResponseEntity.ok(id);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
