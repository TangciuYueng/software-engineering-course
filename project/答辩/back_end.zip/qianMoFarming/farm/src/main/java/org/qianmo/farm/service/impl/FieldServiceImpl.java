package org.qianmo.farm.service.impl;

import org.qianmo.farm.mapper.FieldMapper;
import org.qianmo.farm.model.Field;
import org.qianmo.farm.service.FieldService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FieldServiceImpl implements FieldService{

    @Autowired
    private FieldMapper fieldMapper;

    @Override
    public List<Field> getFieldByFarmId(int farmId) {
        List<Field> fields = fieldMapper.getFieldByFarmId(farmId);
        return fields;
    }




}
