package org.qianmo.login.service;

import org.springframework.stereotype.Service;
import org.qianmo.login.dto.SmsInfo;

@Service
public interface EditCodeService {
    void editPassword(String newPassword,int employeeId);

    String getPhoneNumber(int employeeId);

    SmsInfo sendSmsCode(String phone) throws Exception;

}
