package org.qianmo.login.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface EditPasswordMapper {
    void editPassword(@Param("employeeId")int employeeId,
                         @Param("password")String newPassword);

    String getPhoneNumber(@Param("employeeId")int employeeId);
}
