 package org.qianmo.login.controller;

 import org.qianmo.login.service.LoginService;
 import org.qianmo.login.dto.LoginRequest;


 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.web.bind.annotation.GetMapping;
 import org.springframework.web.bind.annotation.RequestMapping;
 import org.springframework.web.bind.annotation.RestController;
 import org.springframework.http.ResponseEntity;
 import org.springframework.web.bind.annotation.*;

 @RestController
 @RequestMapping("/api/login")

 public class LoginController {
     @Autowired
     private LoginService loginService;

     @PostMapping("/login")
     public ResponseEntity<Boolean> checkPermission(@RequestBody LoginRequest loginRequest) {
         Boolean loginOrNot=loginService.checkPermission(loginRequest);
         if (loginOrNot!=null) {
             return ResponseEntity.ok(loginOrNot);
         } else {
             return ResponseEntity.notFound().build();
         }
   }
 }
