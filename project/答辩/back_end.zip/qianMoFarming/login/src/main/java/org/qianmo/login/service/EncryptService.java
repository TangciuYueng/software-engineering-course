package org.qianmo.login.service;

import org.springframework.stereotype.Service;

/**
 * This interface is for encrypting password;
 *      We finally choose the simplest way to encrypt: MD5
 *
 */

@Service
public interface EncryptService {
    String encryptPassword(String pwd);
}
