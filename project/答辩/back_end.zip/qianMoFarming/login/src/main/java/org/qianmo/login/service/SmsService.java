package org.qianmo.login.service;

import org.springframework.stereotype.Service;

/**
 *  This interface is used for SMS, which means Short Message Service
 */
import org.springframework.stereotype.Service;

@Service
public interface SmsService {
    boolean sendSmsCode(String code, String phone) throws Exception;
}
