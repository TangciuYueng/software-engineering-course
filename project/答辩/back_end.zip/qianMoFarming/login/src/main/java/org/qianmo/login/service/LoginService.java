package org.qianmo.login.service;

import org.qianmo.login.dto.LoginRequest;
import org.springframework.stereotype.Service;

/**
 *  Here is the simplest login function:
 *      just examine if the employeeId and the password is satisfied.
 */
@Service
public interface LoginService {
    Boolean checkPermission(LoginRequest loginRequest);
}
