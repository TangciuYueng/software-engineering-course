package org.qianmo.login.controller;


import org.qianmo.login.dto.LoginRequest;
import org.qianmo.login.dto.SmsInfo;
import org.qianmo.login.dto.EmployeeIdRequest;
import org.qianmo.login.service.EditCodeService;


import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/edit")
public class EditCodeController {
    @Autowired
    private EditCodeService editCodeService;

    @PostMapping("/edit")
    public ResponseEntity<Boolean> editPassword(@RequestBody LoginRequest loginRequest) {
        editCodeService.editPassword(loginRequest.getPassword(),loginRequest.getEmployeeId());
        return ResponseEntity.ok(true);
    }

    @PostMapping("/sms")
    public ResponseEntity<?> sendSmsCode(@RequestBody EmployeeIdRequest employeeIdRequest) {
        try {
            String phone = editCodeService.getPhoneNumber(employeeIdRequest.getEmployeeId());
            SmsInfo smsInfo = editCodeService.sendSmsCode(phone);
            return new ResponseEntity<>(smsInfo, HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("send sms code failed", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
