package org.qianmo.login.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Employee {
    int employeeId;
    String name;
    String password;
    String phoneNumber;
    String apiKey;
    int type;
}
