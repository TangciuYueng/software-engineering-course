package org.qianmo.login.service.impl;

import org.qianmo.login.service.EncryptService;
import org.springframework.stereotype.Service;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;

@Service
public class EncryptServiceImpl implements EncryptService{

    private static String encrypt(String input) {
        try {
            // 获取 MD5 加密对象
            MessageDigest md = MessageDigest.getInstance("MD5");

            // 将输入转换为字节数组并进行加密
            byte[] messageDigest = md.digest(input.getBytes());

            // 将字节数组转换为十六进制字符串
            StringBuilder hexString = new StringBuilder();
            for (byte b : messageDigest) {
                hexString.append(String.format("%02x", b));
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            // 处理异常
            e.printStackTrace();
            return null;
        }
    }


    @Override
    public String encryptPassword(String pwd) {
        return encrypt(pwd);
    }
}
