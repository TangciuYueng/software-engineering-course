package org.qianmo.login.service.impl;

import org.qianmo.login.dto.LoginRequest;
import org.qianmo.login.service.EncryptService;
import org.qianmo.login.service.LoginService;
import org.qianmo.login.mapper.LoginMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class LoginServiceImpl implements LoginService{
    @Autowired
    private LoginMapper loginMapper;
    @Autowired
    EncryptService encryptService;


    @Override
    public Boolean checkPermission(LoginRequest loginRequest){
        // Here needs to encrypt the password
        String encryptedPassword=encryptService.encryptPassword(loginRequest.getPassword());

        // check the ID and the password
        if(loginMapper.checkPermission(loginRequest.getEmployeeId(),encryptedPassword)){
            return true;
        }
        else {
            return false;
        }

        //return loginMapper.checkPermission(loginRequest.getEmployeeId(),loginRequest.getPassword());
    }

}
