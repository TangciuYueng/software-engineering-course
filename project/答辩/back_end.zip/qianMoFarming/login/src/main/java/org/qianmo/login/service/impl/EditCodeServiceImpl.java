package org.qianmo.login.service.impl;

import org.qianmo.login.dto.SmsInfo;
import org.qianmo.login.mapper.EditPasswordMapper;
import org.qianmo.login.service.EncryptService;
import org.qianmo.login.service.EditCodeService;
import org.qianmo.login.service.SmsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.ThreadLocalRandom;

@Service
public class EditCodeServiceImpl implements EditCodeService {
    @Autowired
    private EncryptService encryptService;
    @Autowired
    private EditPasswordMapper editPasswordMapper;
    @Autowired
    private SmsService smsService;
    // 更适合并发环境的随机数生成器
    private final static ThreadLocalRandom generator = ThreadLocalRandom.current();


    @Override
    public void editPassword(String newPassword,int employeeId) {
        newPassword=encryptService.encryptPassword(newPassword);
        editPasswordMapper.editPassword(employeeId,newPassword);
    }

    @Override
    public String getPhoneNumber(int employeeId){
        return editPasswordMapper.getPhoneNumber(employeeId);
    }
    @Override
    public SmsInfo sendSmsCode(String phone) throws Exception {
        String code = getCode();
        boolean ifSend = smsService.sendSmsCode(code, phone);
        return new SmsInfo(ifSend ? code : null, ifSend);
    //return null;
    }



    private static String getCode() {
        int code = generator.nextInt(899999) + 100000;
        return String.valueOf(code);
    }
}
