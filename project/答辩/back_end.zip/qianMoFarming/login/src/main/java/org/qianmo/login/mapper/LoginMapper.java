package org.qianmo.login.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface LoginMapper {
    Boolean checkPermission(@Param("employeeId")int employeeId,
                            @Param("password") String password);
}

