package org.qianmo.warehouse.service;
import org.qianmo.warehouse.dto.ShelfHistory;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface ShelfService {

    List<ShelfHistory> getShelfHistory(int waresId);

    //Integer addShelf(ShelfRequest request);
}