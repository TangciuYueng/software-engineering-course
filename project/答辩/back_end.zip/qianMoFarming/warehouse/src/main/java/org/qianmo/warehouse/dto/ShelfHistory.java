package org.qianmo.warehouse.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ShelfHistory {
    private int shelfId;
    private String name;
    private int amount;
    private LocalDateTime shelfDate;

}
