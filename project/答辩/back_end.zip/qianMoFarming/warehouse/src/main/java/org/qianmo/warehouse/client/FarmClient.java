package org.qianmo.warehouse.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.List;
@FeignClient(value = "farm-service")
public interface FarmClient {
    @GetMapping("/api/farm/{farmName}/to_id")
    ResponseEntity<Integer> farmNameToId(@PathVariable("farmName") String farmName);
}



