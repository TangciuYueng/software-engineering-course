package org.qianmo.warehouse.service.impl;
import org.qianmo.warehouse.client.FarmClient;
import org.qianmo.warehouse.dto.WarehouseRequest;
import org.qianmo.warehouse.mapper.WarehouseMapper;
import org.qianmo.warehouse.model.*;
import org.springframework.http.ResponseEntity;
import org.qianmo.warehouse.service.WarehouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static ch.qos.logback.core.util.StatusPrinter.print;


@Service
public class WarehouseServiceImpl implements WarehouseService{

    @Autowired
    private WarehouseMapper warehouseMapper;
    @Autowired
    private FarmClient farmclient;
    @Override
    @Transactional
    public Integer addWarehouse(WarehouseRequest request) {

        ResponseEntity<Integer> responseEntity = farmclient.farmNameToId(request.getFarmName());
        if (responseEntity != null && responseEntity.getBody() != null) {
            int farmId= responseEntity.getBody();
            Warehouse warehouse=Warehouse.builder()
                    .name(request.getWarehouseName())
                    .farmId(farmId)
                    .build();
            warehouseMapper.addWarehouse(warehouse);
            System.out.print("today");
            return 1;


        } else {
            // 处理响应为null的情况，可以抛出异常或者进行其他处理
            // 比如抛出自定义异常：
            return null;
        }

    }

    @Override
    public List<Warehouse> getAllWarehouse() {

        return warehouseMapper.findAllWarehouse();
    }

}
