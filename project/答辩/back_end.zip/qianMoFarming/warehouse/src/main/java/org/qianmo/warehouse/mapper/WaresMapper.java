package org.qianmo.warehouse.mapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
//import org.qianmo.warehouse.model.Shelf;
import org.qianmo.warehouse.model.Wares;
import org.qianmo.warehouse.dto.WaresDTO;

import java.util.List;

@Mapper
public interface WaresMapper {
    //检查某种作物是否在这个农场，返回特级/一级/二级可以存的粮仓list（若以前存过 仍存在那里；若没有，返回农场所有的粮仓）
//    List<List<Integer>> checkWares(int cropId, int farmId);
    //返回某种品质的庄稼在某个农场中 存储着的对应的所有 WaresId 一般为一个
    List<Integer> checkWaresInDetail(@Param("cropId")int cropId, @Param("farmId")int farmId,@Param("quality")String quality);
//    int checkWaresInWarehouse(int cropId,int warehouseId);
    void addWares(Wares wares);
    void updateWares(@Param("waresId")int waresId,@Param("weight")int weight);

    Wares getWaresById(int waresId);
    List<Wares> getWaresByFarm(@Param("farmId") int farmId);
    //返回库存最多的Wares
    List<Wares> findMostWares();
    //返回前十名
    List<Wares> findEarliestWares();
    //需要一个cropId farmId harvest_date quality weight 的表
    //返回的是最早入库时间的有多少存量
    int updateEarliestDate(int waresId);

    //找到一个农场里的所有wares
    List<Wares> findWares(int warehouseId);
    //([FromQuery] string farmName = null, [FromQuery] string WarehouseName = null,
    //            [FromQuery] string quality = null, [FromQuery] string type = null, [FromQuery] string name = null)
    // farmName->farmId->WarehouseId WarehouseName->WarehouseId type/name->cropId quality
    //    farm,  warehouse         ,       warehouse,           planting(maybe field)
    List<Wares> searchWares(@Param("warehouseId") int warehouseId,
                            @Param("quality") String quality,
                            @Param("cropId") int cropId);

    List<WaresDTO> highLevelSearch(
            @Param("farmName") String farmName,
            @Param("warehouseName") String warehouseName,
            @Param("quality") String quality,
            @Param("type") String type,
            @Param("name") String name
    );

    String getWaresName(
            @Param("waresId") int waresId
    );

    String getWaresType(
            @Param("waresId") int waresId
    );
    //存入粮仓 [cropId,farmId,warehouseId,amount]
    //新建wares [ware]
    //更改updatewares[waresid amount]
    //检查有无wares [cropId,farmId,warehouseId] [返回waresId]
    //更改wares【waresId weight】// 减少wares[waresid weight]
    //新建wareshistory[wareshistory]
    //搜索wares

    //
}
