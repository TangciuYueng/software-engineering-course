package org.qianmo.warehouse.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class WaresHistory {
    private int waresId;
    private String type;
    private LocalDateTime changeDate;
    private double amount;
}
