package org.qianmo.warehouse.service.impl;
import org.qianmo.warehouse.dto.*;
import org.qianmo.warehouse.model.*;
import org.qianmo.warehouse.mapper.WaresMapper;
import org.qianmo.warehouse.mapper.ProductMapper;
import org.qianmo.warehouse.mapper.ShelfMapper;
import org.qianmo.warehouse.mapper.WaresHistoryMapper;
import org.qianmo.warehouse.service.WaresService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.time.ZoneId;

import org.springframework.transaction.annotation.Transactional;
import org.webjars.NotFoundException;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class WaresServiceImpl implements WaresService {

    @Autowired
    private WaresMapper waresMapper;

    @Autowired
    private ProductMapper productMapper;
    @Autowired
    private ShelfMapper shelfMapper;

    @Autowired
    private WaresHistoryMapper waresHistoryMapper;
    @Override
    public List<WaresDTO> highLevelSearch(String farmName, String warehouseName, String quality, String type, String name) {
        return waresMapper.highLevelSearch(farmName, warehouseName, quality, type, name);
    }
    @Override
    public WaresDetail getWaresById(int waresId)
    {
        try{
            Wares wares=waresMapper.getWaresById(waresId);
            System.out.println(wares.getWaresId());
            if (wares.getWaresId() == 0){
                throw new NotFoundException("no wares");
            }
            WaresDetail.WaresDetailBuilder builder=WaresDetail.builder()
                    .stock(wares.getStock())
                    .cropId(wares.getCropId())
                    .earliest_date(wares.getEarliestDate())
                    .warehouseId(wares.getWarehouseId())
                    .waresId(wares.getWaresId())
                    .weight(wares.getWeight())
                    .quality(wares.getQuality());
            System.out.println(builder.build().getWaresId());
            return builder.build();

        } catch (Exception e) {
            return null;
        }
    }
    @Override
    public int waresChange(WaresHistoryDTO request)
    {
        int sign=1;
        waresMapper.updateWares(request.getWaresId(), (int) request.getAmount());
        return sign;
    }

    @Override
    public List<Wares> findEarliestWares() {
        return waresMapper.findEarliestWares();
    }
    @Override
    public List<Wares> findMostWares() {
        return waresMapper.findMostWares();
    }

    @Override
    public String getWaresName(int waresId)
    {
        return waresMapper.getWaresName(waresId);
    }
    @Override
    public String getWaresType(int waresId)
    {
        return waresMapper.getWaresType(waresId);
    }
    @Override
    public WaresDetail waresOnShelf(ShelfRequest request)
    {
        //check if wares have enough weight to complete the task
        WaresDetail waresDetail=getWaresById(request.getWaresId());
        double stock=waresDetail.getStock();
        double weight=waresDetail.getWeight();
        int newStock= request.getAmount();
        if(newStock>weight|| newStock < 0||newStock==stock)
        {

            return null;
        }

        int amount=(int)(newStock-stock);//变化量
        System.out.println("amount");
        String cropName=getWaresName(request.getWaresId());
        String cropType=getWaresType(request.getWaresId());
        if(cropName==null)
            return null;
        int productId=productMapper.findProduct(cropName,waresDetail.getQuality());
        System.out.println(productId);
        if (productId==0)
        {
            //新建
            Product product= Product.builder()
                    .stock(request.getAmount())
                    .name(cropName)
                    .quality(waresDetail.getQuality())
                    .photo(null)
                    .detail(null)
                    .price(0)
                    .type(cropType)
                    .build();
            productId=product.getProductId();
            productMapper.addProduct(product);
        }
        else{
            productMapper.updateProduct(productId,amount);
        }
        Shelf shelf=Shelf.builder()
                .amount(amount)
                .waresId(request.getWaresId())
                .employeeId(request.getEmployeeId())
                .productId(productId)
                .shelfDate(LocalDateTime.now(ZoneId.of("Asia/Shanghai")))
                .build();
        shelfMapper.addShelf(shelf);
        waresMapper.updateWares(request.getWaresId(),request.getAmount());
        //还要更新earliest_date
        waresDetail.setStock(newStock);
        return waresDetail;
        //check if wares already have corresponding product
        //if not, create a new product
        //Otherwise,update product

        //create shelf

        //update wares' stock
        //calculate and update wares' earliest_date

        //Integer ans= shelfService.addshelf(request);
    }
    @Override
    @Transactional
    public List<WaresHistoryDTO> getWaresHistory(int waresId)
    {
        System.out.println("1 " );
        List<WaresHistory> waresHistories=waresHistoryMapper.WaresHistory(waresId);
        //        System.out.println("WaresHistory - Amount: " );
        //        for (WaresHistory waresHistory : waresHistories) {
        //            System.out.println("WaresHistory - Amount: " + waresHistory.getAmount());
        //            System.out.println("WaresHistory - Type: " + waresHistory.getType());
        //            System.out.println("WaresHistory - Change Date: " + waresHistory.getChangeDate());
        //            System.out.println("WaresHistory - Wares ID: " + waresHistory.getWaresId());
        //            System.out.println("--------------");
        //        }

        List<WaresHistoryDTO> waresHistoryDTOS=waresHistories.stream()
                .map(waresHistory ->WaresHistoryDTO.builder()
                        .amount(waresHistory.getAmount())
                        .type(waresHistory.getType())
                        .changeDate(waresHistory.getChangeDate())
                        .waresId(waresHistory.getWaresId())
                        .build()).collect(Collectors.toList());
        return waresHistoryDTOS;
    }

    @Override
    public List<Wares> getWaresByFarm(int farmId) {
        List<Wares> wares= waresMapper.getWaresByFarm(farmId);
        return wares;
    }

    ;

}
