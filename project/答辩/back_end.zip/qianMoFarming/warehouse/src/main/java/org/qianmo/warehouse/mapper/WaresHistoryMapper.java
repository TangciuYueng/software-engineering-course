package org.qianmo.warehouse.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.warehouse.model.WaresHistory;

import java.util.List;

@Mapper
public interface WaresHistoryMapper {
    void addWaresHistory(WaresHistory waresHistory);
    List<WaresHistory> WaresHistory(int waresId);

}
