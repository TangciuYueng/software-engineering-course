package org.qianmo.warehouse.service;
import org.qianmo.warehouse.dto.ShelfRequest;
import org.qianmo.warehouse.dto.WaresDTO;
import org.qianmo.warehouse.dto.WaresDetail;
import org.qianmo.warehouse.dto.WaresHistoryDTO;
import org.qianmo.warehouse.model.Wares;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface WaresService {
    List<WaresDTO> highLevelSearch(String farmName, String warehouseName, String quality, String type, String name);
    WaresDetail getWaresById(int waresId);
    String getWaresName(int waresId);
    String getWaresType(int waresId);
    WaresDetail waresOnShelf(ShelfRequest request);
    int waresChange(WaresHistoryDTO request);
    List<Wares> findEarliestWares();
    List<Wares> findMostWares();
    List<WaresHistoryDTO> getWaresHistory(int waresId);
    List<Wares> getWaresByFarm(int farmId);
}
