package org.qianmo.warehouse.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Wares {
    private int waresId;
    private LocalDateTime earliestDate;
    private int warehouseId;
    private int cropId;
    private String quality;
    private double weight;
    private double stock;
}
