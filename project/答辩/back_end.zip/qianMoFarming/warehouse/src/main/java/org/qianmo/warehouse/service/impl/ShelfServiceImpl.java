package org.qianmo.warehouse.service.impl;
import org.qianmo.warehouse.dto.*;
import org.qianmo.warehouse.mapper.*;
import org.qianmo.warehouse.model.*;
import org.qianmo.warehouse.service.ShelfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ShelfServiceImpl implements ShelfService {
    @Autowired
    private ShelfMapper shelfMapper;
    @Autowired
    private EmployeeMapper employeeMapper;


    @Override
    public List<ShelfHistory> getShelfHistory(int waresId) {
        List<Shelf> shelves = shelfMapper.ShelfHistory(waresId);
        /*
        List<WaresHistoryDTO> waresHistoryDTOS=waresHistories.stream()
                .map(waresHistory ->WaresHistoryDTO.builder()
                        .amount(waresHistory.getAmount())
                        .type(waresHistory.getType())
                        .changeDate(waresHistory.getChangeDate())
                        .waresId(waresHistory.getWaresId())
                        .build()).collect(Collectors.toList());*/
        List<ShelfHistory> shelfHistories = shelves.stream()
                .map(shelf -> ShelfHistory.builder()
                        .amount(shelf.getAmount())
                        .shelfId(shelf.getShelfId())
                        .name(employeeMapper.getEmployeeById(shelf.getEmployeeId()).getName())
                        .shelfDate(shelf.getShelfDate())
                        .build()).collect(Collectors.toList());
        return shelfHistories;
    }
}

