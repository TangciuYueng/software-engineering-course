package org.qianmo.warehouse.mapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import org.qianmo.warehouse.model.Warehouse;
@Mapper
public interface WarehouseMapper {
    //找到一个农场所有的粮仓
    List<Integer> findWarehouseByFarm(@Param("farmId") Integer farmId);
    List<Integer> findWarehouseByWares(@Param("waresId") Integer waresId);
    List<Integer> findWarehouseByName(@Param("warehouseName") String warehouseName);
    void addWarehouse(Warehouse warehouse);
    List<Warehouse> findAllWarehouse();
    //Find_Appropriate_Warehouse [cropId, farmId]【返回三个list（warehouse）】
}
