package org.qianmo.warehouse.controller;

import org.qianmo.warehouse.dto.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.qianmo.warehouse.service.ShelfService;

import org.qianmo.warehouse.service.WaresService;
import org.qianmo.warehouse.service.ProductService;

import java.util.List;
@RestController
@RequestMapping("/api/shelf")
public class ShelfController {

    @Autowired
    private ShelfService shelfService;
    @Autowired
    private WaresService waresService;
    @Autowired
    private ProductService productService;

    @PutMapping("/on_shelf")
    public ResponseEntity<?> waresOnShelf(@RequestBody ShelfRequest request) {

        WaresDetail waresDetail=waresService.waresOnShelf(request);
        if(waresDetail!=null) {
            return ResponseEntity.ok(waresDetail);
        }else{
            return ResponseEntity.badRequest().build();
        }

    }
    @GetMapping("/shelf_history/{waresId}")
    public ResponseEntity<?> getShelfHistory (@PathVariable("waresId") int waresId) {
        List<ShelfHistory> shelfHistory=shelfService.getShelfHistory(waresId);
        if(shelfHistory!=null) {
            return ResponseEntity.ok(shelfHistory);
        }else{
            return ResponseEntity.notFound().build();
        }
    }
}



