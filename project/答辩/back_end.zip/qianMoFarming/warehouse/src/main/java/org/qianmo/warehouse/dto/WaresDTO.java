package org.qianmo.warehouse.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class WaresDTO {
    private int waresId;
    private String farmName;
    private String warehouseName;
    private String cropName;
    private String cropType;
    private String quality;
    private double weight;
    private double stock;
    private LocalDateTime  earliestDate;
}
