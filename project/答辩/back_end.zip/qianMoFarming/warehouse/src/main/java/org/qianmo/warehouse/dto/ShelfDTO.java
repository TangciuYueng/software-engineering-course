package org.qianmo.warehouse.dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShelfDTO {
    private int shelfId;
    private int employeeId;
    private String name;
    private LocalDateTime shelfDate;
    private int amount;
    private int waresId;
    private int productId;
}
