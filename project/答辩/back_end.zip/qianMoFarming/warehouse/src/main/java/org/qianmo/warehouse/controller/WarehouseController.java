package org.qianmo.warehouse.controller;

import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.qianmo.warehouse.model.Warehouse;
import org.qianmo.warehouse.dto.WaresDTO;
import org.qianmo.warehouse.dto.WarehouseRequest;
import org.qianmo.warehouse.service.WarehouseService;
import java.time.LocalDateTime;
import java.util.List;

import static ch.qos.logback.core.util.StatusPrinter.print;

@RestController
@RequestMapping("/api/warehouse")
public class WarehouseController {

    @Autowired
    private WarehouseService warehouseService;

    @PutMapping("/add_warehouse")
    public ResponseEntity<String> addWarehouse(@RequestBody WarehouseRequest request) {


        Integer ans= warehouseService.addWarehouse(request);
        if (ans != null) {
            return ResponseEntity.ok("0");
        } else {
            return ResponseEntity.ok("1");
        }
    }

    @GetMapping("/get_all_warehouse")
    public ResponseEntity<?>  getAllWarehouse () {

        List<Warehouse> warehouses=warehouseService.getAllWarehouse();
        return ResponseEntity.ok(warehouses);
    }

}


