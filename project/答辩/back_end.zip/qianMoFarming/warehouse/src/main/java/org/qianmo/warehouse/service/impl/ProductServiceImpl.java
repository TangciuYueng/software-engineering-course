package org.qianmo.warehouse.service.impl;
import org.qianmo.warehouse.dto.WaresDTO;
import org.qianmo.warehouse.mapper.ProductMapper;
import org.qianmo.warehouse.mapper.WaresMapper;
import org.qianmo.warehouse.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.webjars.NotFoundException;

import java.util.List;
@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductMapper productMapper;
    @Override
    @Transactional
    public int findProduct(String cropName,String quality) {
        System.out.print("1"+cropName);

        return productMapper.findProduct(cropName,quality);
    }

}
