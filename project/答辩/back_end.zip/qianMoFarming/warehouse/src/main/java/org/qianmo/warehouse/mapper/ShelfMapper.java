package org.qianmo.warehouse.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.warehouse.model.Shelf;
import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface ShelfMapper {
    void addShelf(Shelf shelf);
    List<Shelf> ShelfHistory(int waresId);
}
