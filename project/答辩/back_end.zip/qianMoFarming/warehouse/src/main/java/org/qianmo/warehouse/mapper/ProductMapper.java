package org.qianmo.warehouse.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.qianmo.warehouse.model.Product;

@Mapper
public interface ProductMapper {
    //新建product
    void addProduct(Product product);
    //需要cropId->cropName的
    int findProduct(@Param("cropName") String cropName, @Param("quality") String quality);
    //amount为变化量
    void updateProduct(@Param("productId")int productId,@Param("amount")int amount);

}
