package org.qianmo.warehouse.controller;
import org.qianmo.warehouse.model.Wares;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.qianmo.warehouse.dto.WaresDTO;
import org.qianmo.warehouse.dto.WaresHistoryDTO;
import org.qianmo.warehouse.service.WaresService;
import java.util.List;

@RestController
@RequestMapping("/api/wares")
public class WaresController {

    @Autowired
    private WaresService waresService;

    @GetMapping("/high_level_search")
    public ResponseEntity<List<WaresDTO>> highLevelSearch(
            @RequestParam(required = false) String farmName,
            @RequestParam(required = false) String warehouseName,
            @RequestParam(required = false) String quality,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String name) {
        List<WaresDTO> response = waresService.highLevelSearch(farmName, warehouseName, quality, type, name);
        if (response != null) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/wares_history/{waresId}")
    public ResponseEntity<?>  getWaresHistory (@PathVariable("waresId") int waresId) {
        List<WaresHistoryDTO> waresHistory=waresService.getWaresHistory(waresId);
        if(waresHistory!=null) {
            return ResponseEntity.ok(waresHistory);
        }else{
            return ResponseEntity.notFound().build();
        }

    }


    @GetMapping("/wares_change/{waresId}")
    public ResponseEntity<?>  changeWares (@PathVariable("waresId") int waresId,
                                           @RequestBody WaresHistoryDTO request) {

        int response=waresService.waresChange(request);
        if (response>0){
            return ResponseEntity.ok("change successfully");
        }
        else
            return ResponseEntity.notFound().build();
    }



    //得到所有农场临期存量最多的wares 前十
    @GetMapping("/getMostWares")
    public ResponseEntity<List<Wares>>  getMostWares () {
        List<Wares> wares=waresService.findMostWares();
        if(wares.isEmpty())
            return ResponseEntity.notFound().build();
        else
            return ResponseEntity.ok(wares);
    }

    //得到所有农场存储时间最早的wares
    @GetMapping("/getEarliestWares")
    public ResponseEntity<List<Wares>>  getEarliestWares () {
        List<Wares> wares=waresService.findEarliestWares();
        if(wares.isEmpty())
            return ResponseEntity.notFound().build();
        else
            return ResponseEntity.ok(wares);
    }

    @GetMapping("/get_farm_wares/{farmId}")
    public ResponseEntity<?>  getWaresByFarm (@PathVariable("farmId") int farmId) {
        List<Wares> wares=waresService.getWaresByFarm(farmId);
        if(wares.isEmpty())
            return ResponseEntity.notFound().build();
        else
            return ResponseEntity.ok(wares);
    }
}

