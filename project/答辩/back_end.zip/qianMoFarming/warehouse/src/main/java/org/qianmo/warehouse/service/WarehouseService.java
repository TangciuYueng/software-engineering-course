package org.qianmo.warehouse.service;
import org.qianmo.warehouse.dto.WarehouseRequest;
import org.qianmo.warehouse.model.Warehouse;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface WarehouseService {
    Integer addWarehouse(WarehouseRequest request);
    List<Warehouse> getAllWarehouse();
}
