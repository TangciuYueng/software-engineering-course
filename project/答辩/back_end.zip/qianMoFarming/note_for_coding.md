第一级
controller
暴露给用户 调用DTO service
（1）定api（路由） 前端网页访问 可分为整体的/分页的/单一函数的
（2）类中实例化service
（3）类中定义函数 函数里实例化dto 返回查询的值/错误
（4）函数里实例化 使用service的函数对其赋值

第二级
service
（1）定义interface类（实体及函数的定义）
（2）函数定义中，可实例化dto的类作为输入的变量

serviceImpl
调用DTO model mapper
（1）service的实现类
（2）类中实例化mapper
（3）类的函数中，使用mapper实例化model，使用mapper更新数据库的表，使用model实例化dto（返回表）

dto(数据传输对象)
定义和controller中的某个/几个函数有关的所有变量相关的类
DTO通常是在 Java 代码中定义和使用的，而在 XML 文件中，主要配置 SQL 映射和结果集映射。
（封装暴露给前端的类，service与controller的传输，我们这里相当于VO视图对象与dto合二为一）

第三级
mapper（DAO数据访问对象）
定义interface类（函数的定义）（封装对数据库的访问）

resource/mapper
访问数据库，实现mapper类

model
将数据库的表转化成实体类

以上按照自上而下排列 （分级为三级仅代表个人观点）
coding一般建议从下至上来实现 